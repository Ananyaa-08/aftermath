## 12. Training plan

The transition model exists to make cheap, calibrated predictions that let the router skip strong verification safely. It is adopted only if it beats simpler alternatives on validation data (REQ-TRAIN-005, gate G-M7). If B5 (independent NLI), B6 (direct LLM) or the B10 pipeline is as good at lower total cost, the model is dropped and the finding reported (plan Section 10).

### 12.1 Input serialization (`tser-v1`)

One example per (claim, update). Segments, in order, each prefixed by a marker token added to the tokenizer vocabulary:

```
[Q] question text
[SCOPE] ROLLING_CURRENT | FIXED_TIME 2026-02-01 | FIXED_VERSION
[CLAIM] claim text
[OLD] old support passage(s) with the changed span wrapped as [DEL] ... [/DEL]
[NEW] aligned successor passage(s) with the changed span wrapped as [INS] ... [/INS]
[SURV] surviving support passage(s) (other groups)
[EVID] retrieved new evidence passages, each prefixed by [T1]/[T2]/[T3] authority tier and [NA] if not applicable
[FEAT] numeric_change=1 date_change=0 negation_change=0 qualifier_change=0 kind=MODIFIED
```

Empty segments keep their marker followed by `[NONE]`.

### 12.2 Context selection and truncation

Encoder maximum 512 tokens. Per-segment budgets (tokens): `Q` 40, `SCOPE` 8, `CLAIM` 64, `OLD` 112, `NEW` 112, `SURV` 64, `EVID` 96, `FEAT` 16. Unused budget is redistributed to `NEW`, then `OLD`, then `EVID`. Passages are truncated to a window centred on the change span (for `OLD`/`NEW`) or on the highest-overlap sentence with the claim (others). A `truncated` flag per segment is logged; the share of truncated examples is reported. If serialization drops a must-keep item (9.5 step 8) rather than windowing it, the prediction is flagged `input_incomplete` and the router must escalate it (8.10).

### 12.3 Label space

Four classes: the post-update claim status. Prior status is an input (`[PRIOR] SUPPORTED`), always `SUPPORTED` in the primary track and variable in the mixed-quality track. Derived `p_changed = 1 - p(prior status)`.

Labels provided by existing data:

| Source | Provides | Missing |
|---|---|---|
| VitaminC | `SUPPORTED` / `CONTRADICTED` / `INSUFFICIENT_SUPPORT` for claim vs single evidence sentence; contrastive pairs | Questions, scope, authority tiers, `UNRESOLVED_CONFLICT`, multi-passage support |
| HoH, DynaQuest | Before/after values of facts | Claim-level status labels; unaffected controls; all must be annotated |
| FRUIT | Updated articles with evidence | Status labels entirely |
| Fixtures and synthetic interventions | Status by construction for software tests | Natural distribution; never used for empirical claims |

All `UNRESOLVED_CONFLICT`, scope-dependent and multi-passage labels require AFTERMATH annotation.

### 12.4 Models compared

- **Paired cross-encoder (default)**: one encoder over the full `tser-v1` input, linear head to 4 classes.
- **Independent classifier (B5 analogue for training)**: the same encoder applied twice, to `[CLAIM]+[OLD]` and to `[CLAIM]+[NEW]+[SURV]+[EVID]`, with a deterministic rule combining the two 3-way NLI outputs plus tiers through `resolve_claim_status`. This isolates the value of joint encoding (H-3).
- **Small instruction model with parameter-efficient tuning**: only if the pilot error analysis shows scope or multi-passage reasoning is the dominant error source (EVIDENCE-GATED, U-023).

Initial model-selection criteria for the encoder backbone (model to be pinned, U-010): an NLI-pretrained cross-encoder with a license permitting research use and redistribution of fine-tuned weights, at most about 500M parameters (fits a single modest GPU at batch 16 with 512 tokens and mixed precision), English, available locally with a fixed revision hash. Candidates are evaluated zero-shot on the validation split first; the best two are fine-tuned.

### 12.5 Losses, hard negatives and imbalance

- **Status loss**: weighted cross-entropy, class weights `w_c = (1 / sqrt(n_c)) / mean_k(1 / sqrt(n_k))` from the training split.
- **Contrastive objective** (minimal pairs only, defined from labelled data, never from embedding similarity): a minimal pair `(x_a, x_b)` shares the claim and old support and differs only in the update. With predicted distributions `p_a`, `p_b` and gold labels `y_a`, `y_b`:
  - if `y_a == y_b` (both meaning-preserving or both unrelated): `L_pair = JS(p_a || p_b)`;
  - if `y_a != y_b`: `L_pair = max(0, m - JS(p_a || p_b))` with margin `m = 0.2` (JS in nats, bounded by ln 2).
  - Total: `L = CE(x_a) + CE(x_b) + lambda * L_pair`, `lambda = 0.1` (tuned on validation from {0, 0.05, 0.1, 0.3}).
  Sources of pairs: VitaminC revision pairs, synthetic paraphrase versus value-change interventions, natural meaning-preserving edits paired with value changes on the same claim.
- **Hard negatives** (examples whose gold status stays `SUPPORTED`): meaning-preserving edits (paraphrase, reorder, reformat); nearby unaffected claims sharing an entity with the changed passage; numeric changes to a different number in the same passage; retrieved but irrelevant new evidence; removal of one of two support groups.
- **Imbalance**: class weights plus a sampler capping the majority class at 4x the next largest class per epoch; the realistic-prevalence evaluation is never resampled.

### 12.6 Calibration and thresholds

- Temperature scaling (one scalar) fit on the calibration split by NLL minimization (L-BFGS, 100 iterations).
- Report ECE with 15 equal-mass bins and reliability diagrams on validation and test.
- `tau_keep` (router) is chosen on the calibration split as the smallest threshold whose empirical unsafe-retention rate among accepted cheap verdicts is at or below the target `epsilon` (default 0.02, swept for curves). This is an empirical operating point with no distribution-free guarantee (REQ-ROUTE-003).

### 12.7 Checkpoint selection and reproducibility

- Optimizer AdamW, learning rate from {1e-5, 2e-5, 3e-5}, linear warmup 6%, weight decay 0.01, batch 16, at most 5 epochs, early stopping on validation macro-F1 with patience 2; ties broken by lower validation NLL.
- Seeds: at least 3 (13, 42, 1234) for every reported configuration; report mean and standard deviation across seeds and per-seed results.
- Set `random`, `numpy`, `torch` seeds; `torch.use_deterministic_algorithms(True, warn_only=True)`; record CUDA and cuDNN versions, GPU model, driver; note that some GPU kernels remain non-deterministic.
- Each training run is an `ExperimentRun` with `phase = OFFLINE` cost records, data manifest hash, tokenizer and model revision hashes, and the checkpoint hash.

### 12.8 CPU smoke mode and GPU stage

- **CPU smoke (`--smoke`)**: builds a 2-layer, hidden size 64 BERT-style config locally from `transformers` config classes with a tokenizer trained on fixture text (no download), trains 2 steps on 32 fixture-derived examples, runs calibration and prediction, and asserts the loss is finite and the pipeline completes in under 60 seconds on CPU (REQ-TRAIN-001). Runs in CI.
- **GPU stage**: full fine-tuning on one modest GPU; expected to need mixed precision and gradient accumulation for 512-token inputs. Exact hardware is an assumption (U-016).

---

## 13. Evaluation and cost accounting

### 13.1 Notation

Set notation is kept in code blocks so it survives export to other formats (D-041).

```text
U            update events in the evaluated stream (one track and split)
A_u          evaluable answer versions active at u (excludes DEFLECTION
             answers, ingestion errors and gold-ambiguous items)
J            {(a, u) : u in U, a in A_u}       answer-update judgments
g_pre(a,u)   gold answer status before u
g_post(a,u)  gold answer status after u
G_aff        {(a,u) in J : g_post(a,u) != g_pre(a,u)}
             affected
G_bad        {(a,u) in J : g_post(a,u) != SUPPORTED}
             not supported after u
G_ok         J minus G_bad
cur(a)       true when the scope type of a is ROLLING_CURRENT
G_harm       {(a,u) in G_aff : (a,u) in G_bad and cur(a)}
             affected, unsupported and current-use
G_aff_fe     {(a,u) in G_aff : the change is in force only after u's as_of}
C_M(u)       candidates of method M for u (excludes audit samples and
             TEMPORALLY_EXCLUDED rows)
avail(a,u)   1 if a is AVAILABLE after all processing for u and before
             u+1 is applied, else 0
st(a,u)      the status committed for a and valid for u's snapshot, or null
```

Gold labels define `G_aff`, `G_bad`, `G_ok`, `G_harm` and `G_aff_fe`. Method outputs (`C_M`, `avail`, `st`) are never used as labels (REQ-EVAL-001). Semantic impact labels are kept separate from any prediction about whether checking is necessary.

### 13.2 Metric definitions

Each metric is a numerator over a denominator; `#{...}` is the size of a set.

```text
candidate_recall
    #{(a,u) in G_aff : a in C_M(u)}
    / #G_aff
protective_withholding_recall
    #{(a,u) in G_harm : avail(a,u) = 0}
    / #G_harm
correct_transition_recall
    #{(a,u) in G_aff : st(a,u) = g_post(a,u)}
    / #G_aff
unsafe_retention
    #{(a,u) in G_bad : cur(a) and avail(a,u) = 1}
    / #{(a,u) in G_bad : cur(a)}
unsafe_retention_archive
    #{(a,u) in G_bad : cur(a) and avail(a,u) = 1}
    / #{(a,u) in J : cur(a)}
unnecessary_invalidation
    #{(a,u) in G_ok : avail(a,u) = 0}
    / #G_ok
  of_which_withheld_or_failed
    #{(a,u) in G_ok : avail(a,u) = 0 and st(a,u) = null}
    / #G_ok
  of_which_mislabelled
    #{(a,u) in G_ok : st(a,u) not in {null, SUPPORTED}}
    / #G_ok
availability
    #{(a,u) in J : avail(a,u) = 1}
    / #J
supported_availability
    #{(a,u) in G_ok : avail(a,u) = 1}
    / #G_ok
resolved_within_budget
    #{(a,u) : a in C_M(u) and st(a,u) != null}
    / #{(a,u) : a in C_M(u)}
affected_prevalence
    #G_aff
    / #J
future_effective_miss
    #{(a,u) in G_aff_fe : no ScheduledRecheck or later selection of a
                          covers the time the change comes into force}
    / #G_aff_fe
claim_macro_f1
    mean over status classes present in gold of per-class F1, over claims
    with both a gold label and a committed status
  claim_coverage
    #{claims with a gold label and a committed status}
    / #{gold-labelled claims of selected answers}
evidence_passage_recall_at_k
    sum over claims c of #(P_gold(c) intersect R_k(c))
    / sum over claims c of #P_gold(c)
evidence_group_hit_rate
    #{claims with a gold support group fully inside the bundle}
    / #{claims with gold support groups}
evidence_span_precision
    characters of committed citation spans overlapping same-stance gold spans
    / characters of committed citation spans
evidence_span_recall
    the same overlapping characters
    / characters of gold spans
must_keep_overflow_rate
    #{jobs with DISCOVERED_EVIDENCE_DROPPED}
    / #{jobs}
verification_delay
    for each completed assessed (a,u): sum of measured wall_ms of the jobs
    processed before and including it in routing order (sequential-queue
    model); report median and p90
total_cost
    sum of CostRecord units per stage and phase (13.3)
```

Rules:

- **Three recalls, never merged** (REQ-EVAL-010). Candidate recall asks whether an affected answer was selected. Protective withholding recall asks whether harm was prevented by any means, including procedural withholding. Correct transition recall asks whether the answer was correctly assessed. A method that selects everything and fails every verification scores 1.0 on the first two, 0.0 on the third, and has low availability; reports always show all three with availability.
- Protective withholding recall is computed over `G_harm` because withholding an answer that is still or newly supported protects nobody.
- Every recall is computed over all affected judgments in the archive, including answers no method ever selected (REQ-EVAL-002).
- **Zero denominators**: the metric value is `null` (JSON `null`, shown as "n/a"), the denominator `0` is shown, and aggregates over clusters skip it while reporting how many clusters were skipped. Values are never coerced to 0 or 1 (REQ-EVAL-001).

### 13.3 Cost accounting

- Every stage in the `CostRecord.stage` enum is instrumented, including preprocessing (`INGEST`, `SEGMENT`, `CLAIM_EXTRACTION`, `SUPPORT_INIT`, `INDEX_BUILD`), update detection, retrieval, routing, verification, retries, audit and repair (REQ-COST-001, REQ-COST-004).
- **Cold-start cost** `C_cold` = sum of `phase = COLD_START` records. **Incremental cost** `C_inc(u)` = sum of `phase = INCREMENTAL` records for `u`. **Offline** training cost reported separately with hardware.
- **Amortized cost per update over horizon H**: `(C_cold + sum_{u <= H} C_inc(u)) / H`, reported for `H` in {10, 100, 1000} by extrapolating mean `C_inc` (extrapolation labelled). **Break-even** `H*` vs B1: smallest `H` where the method's cumulative cost is below B1's, or "none within 10^4".
- **Query/update ratio**: for serving-cost discussion, report cost per update and per 1,000 answers in the archive; the ratio of queries to updates is a scenario parameter, not measured.
- **Money**: computed only at report time from a dated, versioned price table supplied by the user (`configs/pricing/<provider>-<YYYY-MM-DD>.yaml`); raw calls, tokens and times are always reported; GPU time is converted only with a stated hourly rate (REQ-COST-003). No prices are embedded in code.
- Replayed calls are counted with their recorded token counts and flagged `cached_calls`; replay wall time is reported separately from recorded latency.

### 13.4 Statistics

- **Confidence intervals**: cluster bootstrap with clusters = `group_id` (document, entity or project; update events nested inside), 2,000 resamples, percentile 95% intervals. Claims and answers within a cluster are never resampled independently (REQ-EVAL-004).
- **Paired comparisons**: differences between methods computed on the same bootstrap resamples; report the CI of the difference.
- **Multiple comparisons**: Holm correction over the pre-registered primary comparisons (M-AFT vs B1, B3b, B4 and B10 on unsafe retention at matched cost, and on total cost at matched unsafe retention).
- **Seeds**: methods with stochastic parts run with at least 3 seeds; report across-seed spread alongside bootstrap CIs.
- **Prevalence**: report the realistic-prevalence stream (natural order, natural prevalence) and the balanced diagnostic set separately; never pool them (REQ-EVAL-005).

### 13.5 Main figures

1. End-to-end total cost (x) vs unsafe retention (y), one curve per method from threshold or budget sweeps, with answer availability shown as marker labels or a second panel.
2. Candidate recall, protective withholding recall and correct transition recall at fixed strong-verifier budgets, with availability.
3. Risk-coverage curve for the router (coverage = fraction of candidates resolved without strong verification).

### 13.6 Ablations (Stage B, REQ-EVAL-008)

| Ablation | Change |
|---|---|
| A1 no discovery | Provenance path only |
| A2 no provenance | Discovery path only |
| A3 no alternative support | Singleton citation groups only |
| A4 independent NLI | Replace paired model with the independent classifier |
| A5 no scope | All questions treated as `ROLLING_CURRENT` |
| A6 oracle links | Gold evidence links as provenance (upper bound, labelled) |
| A7 no escalation | Transition model verdicts only, no strong verifier |
| A8 graph-only | B8-style propagation instead of two-path retrieval |

Stress settings: archive size (x1, x5, x25 by adding unrelated answers), update rate, provenance error (randomly delete or misattribute 10%, 30%, 50% of citations, labelled synthetic), source additions, repeated updates and reversions.

### 13.7 Guardrails on claims

- No report states deterministic hosted-model outputs; replay determinism is stated as replay determinism.
- No report states a formal or distribution-free reliability guarantee.
- Every number is tied to a run id, track, split and dataset hash.
- Fixture and mock results are labelled "software test, not empirical".

### 13.8 Experiment manifests and outputs

Planned experiment config (`configs/experiments/m1_tiny_saas.yaml`):

```yaml
schema_version: "1.0"
experiment: m1_tiny_saas
dataset:
  kind: fixture
  path: fixtures/tiny_saas
  stream: [fx-0001, fx-0002, fx-0003, fx-0004]
  track_filter: [FIXTURE]
gold: fixtures/tiny_saas/gold/labels.jsonl      # passed to the evaluator only
source_policy: configs/policies/sp-tiny-1.yaml
clock: logical
replay_mode: LIVE
seeds: [13]
verifiers:
  scripted_tiny:
    type: scripted
    script: fixtures/tiny_saas/scripts/verifier_script.yaml
    is_mock: true
evidence: {mode: CANONICAL, max_items: 12, max_chars: 6000, k_ev: 8, k_cs: 4, k_cc: 3, max_partitions: 4}
methods:                                        # each (method, seed) becomes its own method run
  - {method_id: B1_exhaustive,             selector: exhaustive,            router: verify_all_selected-v1, verifier: scripted_tiny, mode: SELECT_VERIFY}
  - {method_id: B2a_doc_invalidate,        selector: document_invalidation, router: invalidate_only-v1,     verifier: null,          mode: INVALIDATE_ONLY}
  - {method_id: B2b_doc_select_verify,     selector: document_invalidation, router: verify_all_selected-v1, verifier: scripted_tiny, mode: SELECT_VERIFY}
  - {method_id: B3a_passage_invalidate,    selector: passage_invalidation,  router: invalidate_only-v1,     verifier: null,          mode: INVALIDATE_ONLY}
  - {method_id: B3b_passage_select_verify, selector: passage_invalidation,  router: verify_all_selected-v1, verifier: scripted_tiny, mode: SELECT_VERIFY}
  - {method_id: B4_similarity,             selector: {similarity: {k_per_span: 20, tau: null, top_n: null}}, router: verify_all_selected-v1, verifier: scripted_tiny, mode: SELECT_VERIFY}
  - {method_id: B10_prov_plus_sim,         selector: {union: [passage_invalidation, {similarity: {k_per_span: 20, tau: null, top_n: null}}]}, router: verify_all_selected-v1, verifier: scripted_tiny, mode: SELECT_VERIFY}
budget: {strong_calls_per_update: null, strong_tokens_per_update: null}
audit: {enabled: false}
report: {bootstrap_resamples: 0}               # fixture: no CIs
```

Experiment directory:

```text
runs/<experiment_id>/
  manifest.resolved.json        resolved config, config_id, file hashes
  environment.json              Python, platform, lockfile hash, git sha and dirty flag, CPU/GPU, model revisions
  dataset_manifest.json         every input file with SHA-256; delivery order
  shared/bundles/               canonical evidence bundles by bundle_id (content-addressed)
  comparison.json, comparison.md   cross-method tables; written only if the runs pass the 11.3 checks
  experiment.sha256             digest over the method-run digests
  methods/<method_run_id>/
    serving.db  blobs/          this method run's store (isolated, REQ-REPRO-004)
    events.jsonl                one record per update event (8.12)
    candidates.jsonl  routing.jsonl  bundles_used.jsonl  verification_requests.jsonl
    verification_results.jsonl  verdicts.jsonl  current_state_final.jsonl  costs.jsonl
    metrics.json                Section 13.2 metrics per track, with numerators, denominators and CIs
    report.md                   human-readable report with the mock or empirical banner
    logical_records.jsonl       canonical export used for determinism
    determinism.sha256          SHA-256 of logical_records.jsonl
```

**Determinism contract** (REQ-REPRO-003, D-039):

- `logical_records.jsonl` contains every record of the method run's logical tables (all append-only tables plus the final rows of the pointer tables), serialized with `cjson-v1`, one record per line, sorted by `(record_type, primary id)`.
- Excluded fields: measured runtime values (`wall_ms`, `cpu_ms`, `gpu_ms`, `latency_ms`, `bytes_written`) and file-system paths. Every timestamp written by the pipeline comes from the logical clock (D-023), so timestamps are included.
- Not hashed: SQLite database bytes (page layout and WAL state vary), `blobs/` directory layout, `environment.json`, `ExperimentRun` wall-clock fields, and formatted outputs (`report.md`, `comparison.md`, `metrics.json`). Formatted outputs are regenerated from the logical records, and T-REPRO-003 checks that regeneration reproduces them.
- `experiment.sha256` = SHA-256 over the sorted lines `"<method_run_id> <determinism.sha256>"`.
- Live hosted-model runs are not expected to reproduce; `REPLAY` runs of recorded responses are (REQ-PIPE-005).

---

## 14. Acceptance scenarios

### 14.1 Fixture corpus `tiny_saas` (hand-authored, track `FIXTURE`)

Base snapshot `snap:000001` from delivery `fx-0001` (`INITIAL_LOAD`, `as_of = 2026-02-01T00:00:00.000Z`), revision `r1` of each document, `source_seq = 1`. Canonical texts (each ends with one newline):

```
{{FIXTURE_TEXTS}}
```

Passages of `doc_plans@r1`: `p0001` "Bulk export is available to all paid plans." (section Plans); `p0002` "The Starter plan costs 12 USD per month. The Pro plan costs 30 USD per month." (Plans); `p0003` "Each workspace can store up to 50 GB of files." (Limits). Every other document has one passage per paragraph in the same way.

Source policy `sp-tiny-1` (Section 5.8): `release_note` tier 1, `product_doc` tier 2, same-tier cross-document conflict is `CONFLICT`.

Archive (all answered `2026-02-01T12:00:00.000Z` against `snap:000001`, `answer_kind = GROUNDED`, one version each, initial status `SUPPORTED` declared by the fixture):

| Answer | Question (scope) | Answer text | Claims (all material) | Recorded citation |
|---|---|---|---|---|
| `ans_export_starter` | Does my Starter plan support bulk export? (`ROLLING_CURRENT`) | Yes, your Starter plan supports bulk export. | c01 "The Starter plan supports bulk export." | `doc_plans` quote "Bulk export is available to all paid plans." |
| `ans_starter_price` | How much does the Starter plan cost? (`ROLLING_CURRENT`) | The Starter plan costs 12 USD per month. | c01 = answer | `doc_plans` quote "The Starter plan costs 12 USD per month." |
| `ans_pro_price` | How much does the Pro plan cost? (`ROLLING_CURRENT`) | The Pro plan costs 30 USD per month. | c01 = answer | `doc_security` (no quote, so `DOCUMENT_ONLY`): **incorrect citation** |
| `ans_storage` | How much storage does a workspace get? (`ROLLING_CURRENT`) | Each workspace can store up to 50 GB of files. | c01 = answer | `doc_plans` quote "Each workspace can store up to 50 GB of files." (alternative support in `doc_storage_faq` is not cited) |
| `ans_encryption` | Is data encrypted at rest? (`ROLLING_CURRENT`) | Yes. All data is encrypted at rest with AES-256. | c01 "All data is encrypted at rest with AES-256." ("Yes." is non-material) | `doc_security` quote "All data is encrypted at rest with AES-256." |
| `ans_export_details` | What does bulk export produce and how often can I run it? (`ROLLING_CURRENT`) | Bulk export creates a ZIP archive of all notes. Paid plans can run bulk export once per day. | c01 first sentence, c02 second sentence | `doc_export_guide`, two quotes (both sentences) |
| `ans_export_hist` | According to revision r1 of the plans page, which plans include bulk export? (`FIXED_VERSION dv:doc_plans@r1`) | All paid plans included bulk export. | c01 = answer | `doc_plans@r1` quote "Bulk export is available to all paid plans." |
| `ans_export_feb` | Did the Starter plan include bulk export on 2026-02-01? (`FIXED_TIME 2026-02-01T00:00:00.000Z`) | Yes, the Starter plan included bulk export on 2026-02-01. | c01 "The Starter plan included bulk export on 2026-02-01." | `doc_plans` quote "Bulk export is available to all paid plans." |
| `ans_export_dec` | Will the Starter plan include bulk export on 2026-12-15? (`FIXED_TIME 2026-12-15T00:00:00.000Z`) | Yes, the Starter plan will include bulk export on 2026-12-15. | c01 "The Starter plan includes bulk export on 2026-12-15." | `doc_plans` quote "Bulk export is available to all paid plans." |

Effective intervals in the base snapshot are open-ended (`effective_to = null`), so `ans_export_dec` is supported at answer time under the stated temporal model.

**M1 stream** (`stream_v1`): `fx-0001` base; `fx-0002` (`as_of 2026-03-01`) `doc_plans@r2` paraphrase of p0001 to "All paid plans include bulk export."; `fx-0003` (`as_of 2026-04-01`) `doc_plans@r3` Starter price 12 to 15 (the worked example in 6.6); `fx-0004` (`as_of 2026-05-01`) `doc_release_notes@r2` appends paragraph "Starting with version 4.3, bulk export is available only on the Pro plan." with no declared `effective_from`.

### 14.2 Two kinds of test

- **Software correctness (deterministic, CI)**: run with `ScriptedVerifier`, whose script gives judgments per `(answer_version_id, target_snapshot_id)`; assertions on selections, workflow states, records, invariants and verdicts **given** the scripted judgments. These test the pipeline, not model quality. A missing script entry makes the scripted verifier return `PROVIDER_ERROR` (never a default verdict).
- **Model-quality probes (empirical, not CI gates)**: the same scenarios with `NliVerifier` and `LlmVerifier` in `RECORD` mode; outcomes are logged against the expected gold column and summarized; they never pass or fail a build and are never reported as empirical results (fixture track).

### 14.3 Global invariants (checked after every scenario, T-INV-*)

- INV-1: No `AnswerCurrentState` has `workflow_state in {QUEUED, IN_PROGRESS, WITHHELD, FAILED, UNASSESSED}` and `verification_basis = VERIFIED_AT_SNAPSHOT` for a snapshot newer than its last verdict.
- INV-2: Every non-null current `semantic_status` points to a verdict whose `valid_for_snapshot_id <= as_of_snapshot_id`; if they differ, `verification_basis = CARRIED_FORWARD`.
- INV-3: No verdict exists for a job whose verification result was not `OK` (or whose assessor is not `TRANSITION_MODEL`, `RULE` or `HUMAN`).
- INV-4: `availability` equals the derivation in 5.9.
- INV-5: Append-only tables have no updated or deleted rows (trigger plus row-count audit).
- INV-6: `manifest_hash` recomputation matches for every snapshot.
- INV-7: No `INVALIDATE_ONLY` job has a verdict.
- INV-8: `FIXED_VERSION` answers never have a verdict newer than their initial state.

### 14.4 Scenarios

Each scenario starts from the base snapshot (`fx-0001`) unless stated. "Selected by" lists the deterministic selection outcome for the Stage A selectors (B2 = document invalidation, B3 = passage invalidation, B4 = similarity with defaults); M-AFT outcomes are Stage B expectations. "Gold" is the expected semantic outcome, used by the scripted verifier script in software tests and as the expected value in model-quality probes.

| ID | Name | Exact input (delivery) | Selected by | Gold after update | Expected workflow and records | Active from |
|---|---|---|---|---|---|---|
| AS-01 | Meaning-preserving paraphrase | `fx-0002`: `doc_plans@r2`, p0001 becomes "All paid plans include bulk export." | B2: all citing `doc_plans` (`ans_export_starter`, `ans_starter_price`, `ans_storage`, `ans_export_feb`, `ans_export_dec`; `ans_export_hist` recorded `TEMPORALLY_EXCLUDED`). B3: `ans_export_starter`, `ans_export_feb`, `ans_export_dec` (p0001 `MODIFIED`). | All `SUPPORTED`. | B3b: 3 verdicts `SUPPORTED`; support refreshed to `pv:doc_plans@r2#p0001`. B3a: 3 `WITHHELD` (counted as unnecessary invalidation). Change span kind `MODIFIED`, features all false. | M1 |
| AS-02 | Passage movement | `doc_plans@r2m`: Limits section moved before Plans, text otherwise identical. | B2: same set as AS-01. B3: none (`MOVED` ignored). | All `SUPPORTED`. | Lineage edges `MOVED` for 3 passages; no `MODIFIED` spans. B3: empty candidate set, all carried forward. Lineage ids unchanged. | M1 |
| AS-03 | Numerical contradiction | `fx-0003` applied after `fx-0002` (the 6.6 example). | B3: `ans_starter_price` only (citation lineage `lin:doc_plans:r1:p0002`). B2: all `doc_plans` citers. | `ans_starter_price` `CONTRADICTED`; all others `SUPPORTED`. | Verdict and current state exactly as in 6.6 (modulo ids derived from the method run); the B2b and B3b method runs have separate current states, costs and verdict histories (T-PIPE-007); `ans_starter_price` availability `WITHHELD`. `ans_pro_price` not selected by B3 (its citation is to `doc_security`). | M1 |
| AS-04 | Unrelated update | `doc_release_notes@r2` appends "Version 4.3 improves search speed." | B2, B3: none. B4: whatever BM25 returns above defaults (asserted as a recorded list, not as empty). | All unchanged. | Empty candidate sets for B2/B3; event `APPLIED`; all answers `CARRIED_FORWARD`; zero verification cost records for B2/B3. | M1 |
| AS-05 | Removal of the only support | `doc_security@r2`: text "# Security\n\nSecurity practices are reviewed annually.\n" | B2, B3: `ans_encryption`, `ans_pro_price` (`DOCUMENT_ONLY` citation to a changed document). | `ans_encryption` `INSUFFICIENT_SUPPORT` (never `CONTRADICTED`); `ans_pro_price` `SUPPORTED` (via `doc_plans` p0002 retrieved). | `ans_encryption` claim resolution rule `NO_SUPPORT_FOUND`; availability `WITHHELD`; `semantic_status` not `CONTRADICTED`. | M2 |
| AS-06 | Removal of one of several sources | `doc_plans@r2d`: the Limits section and its paragraph deleted. | B3: `ans_storage` (p0003 `DELETED`). | `ans_storage` `SUPPORTED` via `doc_storage_faq`. | B3b verdict `SUPPORTED`, supporting group refreshed to `pv:doc_storage_faq@r1#p0001`; B3a withholds (unnecessary invalidation). | M2 |
| AS-07 | New contradiction without a citation link | `fx-0004`: `doc_release_notes@r2` appends "Starting with version 4.3, bulk export is available only on the Pro plan." (`effective_from` defaults to `as_of`). | B2, B3: none (no answer cites release notes). B4, B10 and M-AFT discovery: expected to include `ans_export_starter` and `ans_export_details` (asserted for B4 and B10 with fixture BM25 in M1). | `ans_export_starter` `CONTRADICTED` (tier 1 beats tier 2, rule `HIGHER_TIER_CONTRADICTION`); `ans_export_details` `CONTRADICTED` on c02 (claim about all paid plans), `SUPPORTED` on c01; `ans_export_feb` and `ans_export_hist` unchanged; `ans_export_dec` `CONTRADICTED`. | B2/B3: unsafe retention counted for the contradicted answers; B4/B10/M-AFT: verdicts committed. `ans_export_feb` is evaluated at 2026-02-01, where `eff(doc_release_notes)` is still `r1`; `ans_export_dec` at 2026-12-15, where it is `r2`. | M1 (B4, B10, fixed-time applicability), M6 (discovery) |
| AS-08 | Future-effective update | `doc_release_notes@r2f` (`as_of 2026-11-01`) with text "# Release notes\n\nVersion 4.2 adds dark mode.\n\nStarting 2026-12-01, bulk export will be available only on the Pro plan.\n" and declared `effective_from = 2026-12-01T00:00:00.000Z` for the whole version. Then a `CLOCK_TICK` delivery with `as_of = 2026-12-01T00:00:00.000Z`. | B4, B10 and discovery select `ans_export_starter` and schedule a recheck due 2026-12-01. B2 and B3 select nothing (no citation edge), so they schedule nothing, which the future-effective miss metric counts. | At 2026-11-01: `ans_export_starter` `SUPPORTED`; `ans_export_dec` `CONTRADICTED`. At the tick: `ans_export_starter` `CONTRADICTED`. | At 2026-11-01, `eff(doc_release_notes, 2026-11-01)` is still `r1`: the bundle contains `pv:doc_release_notes@r1#p0001` as applicable and `pv:doc_release_notes@r2f#p0002` with `applicable = false` (REQ-SEM-015). `doc_plans` evidence stays applicable. The recheck fires at the tick with reason `SCHEDULED_EFFECTIVE`; `ans_export_starter` has two verdicts with different snapshots and evaluation times. | M2 |
| AS-09 | Historical question | `fx-0004` as in AS-07. | `ans_export_hist`: `TEMPORALLY_EXCLUDED` by every selector. `ans_export_feb`: may be selected. | `ans_export_hist` and `ans_export_feb` remain `SUPPORTED`. | No new verdict for `ans_export_hist` (INV-8); `ans_export_feb` evaluated at `2026-02-01`, where the release note (effective 2026-05-01) is not applicable. | M1 |
| AS-10 | Conflicting equally authoritative sources | New document `doc_billing_faq` (`product_doc`, tier 2) with text "# Billing FAQ\n\nThe Starter plan costs 14 USD per month.\n" | B2, B3: none. B4/M-AFT: `ans_starter_price`. | `ans_starter_price` `UNRESOLVED_CONFLICT` (rule `SAME_TIER_CONFLICT`). | Availability `WITHHELD`; both supporting and contradicting groups recorded in resolution. | M2 (scripted, resolution logic), M6 (discovery) |
| AS-11 | Partially affected multi-claim answer | `doc_export_guide@r2`: "ZIP archive" becomes "JSON archive". | B2, B3: `ans_export_details`. | c01 `CONTRADICTED`, c02 `SUPPORTED`; answer `CONTRADICTED`. | Verdict has two `claim_statuses`; aggregation rule 1 applied; c02 status retained in the verdict for repair (Stage C repair touches only c01). | M1 |
| AS-12 | Incorrect citation | `doc_plans@r2p`: Pro price 30 becomes 35. | B3: `ans_starter_price` (its cited passage changed; expected `SUPPORTED`) but **not** `ans_pro_price` (cites `doc_security`). B2: `doc_plans` citers only. B4/M-AFT: `ans_pro_price` expected. | `ans_pro_price` `CONTRADICTED`. | B2/B3: unsafe retention of `ans_pro_price`. Stage B: citation audit flags the citation as unsupported at ingest and adds an inferred link to `pv:doc_plans@r1#p0002`, so provenance selects it. | M1 (B2/B3/B4), M5 (inferred link) |
| AS-13 | Repeated update and reversion | After `fx-0002`: `fx-0003` (12 to 15), then `doc_plans@r4` reverting the price to 12 (content hash equals `r2`). | B3: `ans_starter_price` at both updates. | After r3: `CONTRADICTED`; after r4: `SUPPORTED`. | Three verdict records over the stream for `ans_starter_price` (r3 and r4 snapshots, plus none at r2); r4 is a new `DocumentVersion` with a new id and the same `content_hash` as r2; the r4 assessment MAY set `reused_from_verdict_id` only if a verified verdict with an identical bundle hash exists (it does not in this fixture, so assert `null`). | M2 |
| AS-14 | Duplicate event | Deliver `fx-0003` twice; then deliver a payload with `delivery_id = fx-0003` and different text. | n/a | n/a | Second delivery: `DUPLICATE` attempt logged; the event's status stays `APPLIED`; no new snapshot, jobs, verdicts or verification cost. Third: `CONFLICT_REJECTED` attempt logged, `IdempotencyConflictError`, head unchanged. Separately, a delivery that failed during apply (injected fault) and is redelivered with the same payload is applied (`RETRY_APPLY`). | M1 (duplicate), M2 (retry) |
| AS-15 | Update during verification | Apply `fx-0003` (snap 3). The scripted verifier pauses on `ans_starter_price` (test hook). While paused, apply `doc_plans@r4b` (Starter 15 to 18, snap 4), which re-selects it. Resume. | B3: `ans_starter_price` at both. | At snap 3 `CONTRADICTED`; at snap 4 `CONTRADICTED`. | Job for snap 3 commits a verdict (history) but logs `SUPERSEDED` and does not change current state; current state points to the snap 4 verdict; INV-1, INV-2 hold. Variant: if `r4b` does not touch the Starter passage, the snap 3 verdict becomes current with `verification_basis = CARRIED_FORWARD` and `as_of_snapshot_id = snap:000004`. | M2 |
| AS-16 | Budget exhaustion | `fx-0002` with B1 and `budget.strong_calls_per_update = 2`. | B1: all 8 non-`FIXED_VERSION` answers. | All `SUPPORTED`. | Exactly 2 verdicts (the first 2 by `answer_version_id` order: `av:ans_encryption@1`, `av:ans_export_dec@1`); 6 jobs `WITHHELD`, `semantic_status = null`, availability `WITHHELD`; routing decisions record budget before and after; report shows 6 withheld due to budget. | M2 |
| AS-17 | Verifier failure | `fx-0003` with B3b; script returns malformed JSON on attempt 1, a timeout on attempt 2 and malformed JSON on attempt 3 for `ans_starter_price`. | B3: `ans_starter_price`. | n/a | 3 `VerificationRequest`s and 3 results; job `FAILED`; `semantic_status = null`; availability `WITHHELD`; cost records: 1 `VERIFICATION` + 2 `RETRY`; no verdict. | M2 |
| AS-18 | Deleted document | Delete `doc_security`. | B2, B3: `ans_encryption`, `ans_pro_price`. | `ans_encryption` `INSUFFICIENT_SUPPORT`; `ans_pro_price` `SUPPORTED`. | Tombstone version; `DOCUMENT_DELETED` span; earlier versions still retrievable from history. | M2 |
| AS-19 | Out-of-order delivery, including a mixed delivery | After `fx-0003`, one delivery containing `doc_plans` revision `r2x` with `source_seq = 2` (unknown revision) and `doc_security@r2` (in order). | n/a | n/a | Stage A: the whole delivery is `PARKED_OUT_OF_ORDER`; neither `dv:doc_plans@r2x` nor `dv:doc_security@r2` exists; head unchanged; a redelivery with the same payload is re-evaluated and parked again. Stage B: applied in one transaction; `doc_security@r2` becomes latest, `doc_plans@r2x` is known but never latest, and `FIXED_TIME` answers whose time falls where `eff` changed are selected. | M1 (park), M9 (backfill) |
| AS-20 | Split, merge and uncertain alignment | `doc_plans@r2s`: p0002 split into two paragraphs ("The Starter plan costs 12 USD per month." and "The Pro plan costs 30 USD per month."); and, as a separate delivery, `doc_export_guide@r2u`: paragraph 1 becomes "All of your notes are packaged into a ZIP archive by bulk export." (dice-v1 0.7273, `HIGH`) and paragraph 2 becomes "On paid plans you may run bulk export once in a day." (dice-v1 0.6667, `MODIFIED` with `LOW` confidence). | B3: answers citing p0002 (`ans_starter_price`) via `SPLIT`; `ans_export_details` via expansion. | All `SUPPORTED`. | `SPLIT` edge with two outputs and new lineages; `EXPANDED_UNCERTAIN` spans for every passage of the `Export guide` section (triggered by the `LOW` edge). | M2 |
| AS-21 | Verifier omits conflicting evidence | `fx-0004` with B10 (selects `ans_export_starter`). Scripted attempt 1 returns a valid SUPPORTS judgment with a located quote for the surviving `doc_plans` passage and no judgment for the release-note handle; attempt 2 returns all required judgments. | B10: `ans_export_starter`. | `ans_export_starter` `CONTRADICTED`. | Attempt 1 result is `INCOMPLETE_COVERAGE` with the release-note handle in `missing_coverage` and contributes nothing to resolution; attempt 2 is `OK` and resolves with rule `HIGHER_TIER_CONTRADICTION`. Variant: all 3 attempts incomplete gives `FAILED`, `semantic_status = null`, availability `WITHHELD`, never `SUPPORTED`. | M1 |
| AS-22 | Evidence overflow and partitioning | `fx-0004` with B10 and test limits `max_items = 1`; run once with `max_partitions = 4` and once with `max_partitions = 1`. | B10: `ans_export_starter`. | `ans_export_starter` `CONTRADICTED`. | `max_partitions = 4`: two partitions (`{index 0, count 2}`, `{index 1, count 2}`), coverage satisfied by their union, verdict `CONTRADICTED`; optional retrieved items appear in `dropped` with `OVER_ITEM_LIMIT` while `incompleteness = NONE`. `max_partitions = 1`: `incompleteness = DISCOVERED_EVIDENCE_DROPPED`, job `WITHHELD` with reason `EVIDENCE_OVERFLOW`, no verdict, `dropped_by_role` reported. | M2 |
| AS-23 | New revision with unchanged text | `doc_security@r2` whose text is identical to `r1` (new revision id, `source_seq = 2`). | B2: `ans_encryption`, `ans_pro_price` (new document version). B3, B4, B10: none. | All unchanged. | `dv:doc_security@r2` exists with the same `content_hash` as `r1`; `dv:doc_security@r1` remains addressable; a new snapshot exists; all lineage edges are `IDENTICAL`; there are no semantic change spans. B2a withholds 2 answers (unnecessary invalidation); B3 has an empty candidate set. | M1 |
| AS-24 | Effective-date-only change | From the base: `doc_plans@r2t` (`as_of 2026-03-01`), Starter price 12 to 15, declared `effective_from = 2026-12-01`. Then `doc_plans@r3t` (`as_of 2026-04-01`) with text identical to `r2t` and declared `effective_from = 2026-04-01`. | First delivery: B3 selects `ans_starter_price` (text diff). Second delivery: B3 selects `ans_starter_price` through the timeline span; the text diff `r2t -> r3t` is empty. | After `r2t`: `ans_starter_price` `SUPPORTED` at 2026-03-01 (r1 still in force) with a recheck due 2026-12-01. After `r3t`: `CONTRADICTED` at 2026-04-01. | Second delivery: all lineage edges `IDENTICAL`; one `ApplicabilityChange` for `[2026-04-01, 2026-12-01)` with `old_effective_version_id = dv:doc_plans@r1` and `new_effective_version_id = dv:doc_plans@r3t`; a `MODIFIED` span `"12" -> "15"` carrying that change id and interval. The pending 2026-12-01 recheck is not cancelled. Unit variant (T-SEM-017): a later `r4t` restoring 12 USD with `effective_from = 2026-12-01` cancels the December change but not the April one. | M1 |

Scripted-verifier entries for each scenario are stored in `fixtures/tiny_saas/scripts/verifier_script.yaml` keyed by scenario, answer and target snapshot, with judgments that reproduce the gold column (for software tests only).

---
