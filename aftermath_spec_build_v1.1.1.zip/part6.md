## 15. Implementation milestones

Milestones are dependency-ordered. A milestone is complete only when all its completion criteria pass on a clean checkout with the committed lockfile. Stage A = M0 to M4, Stage B = M5 to M10, Stage C = M11 to M13.

### M0: Natural-data feasibility audit (before the full M1 build)

- **Objective**: describe, on small natural samples, whether the phenomena AFTERMATH addresses occur, how often they occur in an ordinary update stream, whether people can label them reliably, and how much room a strong simple baseline leaves. M0 is a feasibility study, not a statistical validation.
- **Scope**: throwaway scripts in `m0/` (not the package); no training; no Stage B. M1 work on `core`, `textproc` and `store` may proceed in parallel, because those modules are needed whatever M0 shows (REQ-SCOPE-004).
- **Predeclared protocol** (REQ-SCOPE-005, D-047): before any M0 result is inspected, `m0/protocol.md` is written with the sampling procedures, rubric version, operating points and the decision questions below; its SHA-256 is recorded in the decision log. Any later change to the protocol is logged with its reason and the date, and the report states which results were produced under which protocol version.
- **Two sampling tracks, reported separately**:
  1. *Targeted diagnostic track*: deliberately collects the phenomena AFTERMATH must handle: value changes, meaning-preserving edits, impacts on uncited answers, redundant support, effective-date changes. Source: HoH change pairs, which are change-positive by construction. Questions may be written about the changed fact. This track can show that phenomena occur and can be labelled. It cannot estimate how often they occur.
  2. *Unconditioned stream track*, where a source allows it: update events sampled independently of whether they change any answer, for example consecutive revisions of randomly sampled Wikipedia pages (U-018) or consecutive commits to a public documentation repository. Questions are chosen from the before snapshot by a fixed, seeded procedure (sample passages uniformly from the before version, generate one question per sampled passage) that never sees the diff. Only this track estimates prevalence. If no source is accessible, the report says that prevalence is unknown and does not substitute the targeted track.
- **Sizes**: about 40 events in the targeted track and, where accessible, about 40 in the unconditioned track, 3 to 5 answers per event. Answers are generated from the before version only, with the generator's natural citations kept.
- **Labels**: two people independently label every answer's **initial support** (before the update) and its **post-update support**, with the four statuses, materiality and evidence spans, under `rubric-v1`. Disagreements are adjudicated. An LLM may prepare material (questions, answers, passage extracts, a draft rubric) but never supplies or pre-fills labels. Time per judgment is recorded. An answer counts as affected only if both adjudicated labels exist and differ; answers whose initial label is not `SUPPORTED` go to the mixed-quality tally, so pre-existing defects are not counted as update damage.
- **Measurements** (`m0/report.md`, per track, with Wilson or bootstrap intervals and the raw counts):
  - Share of events with at least one affected answer, and affected judgments per event (prevalence: unconditioned track only).
  - Share of dependency changes (B2, B3) that are meaning-preserving: descriptive evidence of unnecessary-invalidation exposure.
  - Affected answers with no citation edge to any change: descriptive evidence for the discovery path (H-2).
  - Agreement before adjudication, for initial and post-update labels separately: raw agreement, Cohen's kappa, per-class label counts, and a categorized disagreement analysis.
  - B10 error and cost analysis at several predeclared operating points (`k_per_span` in {5, 10, 20}, `tau` at three predeclared values): candidate recall, missed affected answers, selected answers per affected answer, and estimated strong-verifier calls compared with B1 and B3.
  - Effort: minutes per judgment; share of `MIXED_EFFECTIVE` and `CANCELLATION_UNSUPPORTED` documents (U-024).
- **Agreement as a review trigger, not a pivot rule**: raw agreement below 0.80 or kappa below 0.6 on either label set triggers a rubric review: categorize the disagreements, revise the rubric, and relabel a fresh subset with two annotators. Low agreement never triggers a pivot to the diagnostic benchmark on its own, because a diagnostic benchmark needs reliable labels too.
- **Decision questions G-0** (answered by the project lead from the report, against the predeclared protocol):
  1. *Labels*: after any rubric review, are initial and post-update labels reliable enough to build a benchmark? If not, fix the rubric before any benchmark work.
  2. *Phenomena*: does the targeted track show each phenomenon at least once in natural data? Absent phenomena move to the synthetic intervention track and are reported as such.
  3. *Feasibility of a stream evaluation*: from the unconditioned prevalence, how many events and how many annotation hours would the pilot need to reach 100 affected judgments (the predeclared pilot target)? If that exceeds the annotation budget (U-015), narrow the natural-stream evaluation to the diagnostic benchmark (plan Section 10) and keep the stream track descriptive.
  4. *Headroom*: across the B10 operating points, is there a point where B10 both misses affected answers and selects materially more answers than are affected, at a cost that matters relative to B1? If no operating point leaves room, record that selective revalidation has little room on this data and decide with the project lead.
- **Expected artifacts**: `m0/protocol.md` (hashed before results), `m0/sample.jsonl`, `m0/labels.jsonl` (both annotators and adjudication), `m0/report.md`, decision-log entries recording the protocol hash and the G-0 answers.
- **Completion criteria**: report written under the predeclared protocol; G-0 answers logged (R-05, R-06).
- **Remaining limitations**: small samples; one answer generator; prevalence only from the unconditioned track; Wikipedia-derived questions may be known to hosted models (U-012).

### M1: Runnable vertical slice (Stage A)

- **Objective**: load the tiny versioned fixture corpus and archive, apply the `stream_v1` updates, run B1, B2a/b, B3a/b, B4 and B10 as separate method runs with the scripted verifier and canonical bundles, and emit a reproducible evaluation report.
- **Records implemented in M1** (others are specified in 6.5 and implemented at their milestone): Document, DocumentVersion, CorpusSnapshot, PassageVersion, PassageLineageEdge, UpdateEvent (with `update_event_status_log` and `delivery_attempts`), ChangeSpan, ApplicabilityChange, Question, AnswerVersion, Claim, Citation, SupportGroup (`CITATION_ASSUMED` only), CandidateSelection, AssessmentJob, RoutingDecision, EvidenceBundle, VerificationRequest, VerificationResult, AnswerVerdict, AnswerCurrentState, CostRecord, ExperimentConfig, ExperimentRun, MethodRun. Deferred: EvidenceLink (M5), ScheduledRecheck (M2), ReviewAnnotation (M4; fixture gold is a plain `labels.jsonl`). Migrations are added per milestone.
- **Modules/files**: `pyproject.toml`, `uv.lock`, `core/*` (ids, hashing, cjson, timeutil, enums, errors, schemas for the records above, config), `textproc/*` (including `stop-v1`), `store/db.py`, `store/migrations/0001_init.sql` (the tables above, append-only triggers, pointer tables), `store/repos/*`, `corpus/ingest.py` (two-phase ingest, redelivery table, Stage A parking), `corpus/snapshots.py` (`latest_k`, `eff_k`), `corpus/policy.py`, `diff/align.py` (steps 1 to 3 and 5 of 8.3; splits and merges in M2), `diff/features.py`, `diff/timeline.py` (8.3a), `archive/ingest.py`, `archive/citations.py`, `archive/support_init.py` (Stage A form), `retrieval/bm25.py`, `selection/{exhaustive,doc_invalidation,passage_invalidation,similarity,union,temporal}.py`, `evidence/{gather,bundle,resolve,state}.py` (canonical mode from the frozen evidence state with cache verification, must-keep rules; a bundle that would need more than one partition is marked `DISCOVERED_EVIDENCE_DROPPED` until M2 adds partitioning), `verify/{base,scripted,parse}.py` (coverage and per-member citation checks apply to scripted output too), `routing/policies.py` (`verify_all_selected-v1`, `invalidate_only-v1`), `pipeline/{process_update,jobs,commit,report_update}.py` (sequential, no worker pool), `cost/ledger.py`, `eval/{gold,metrics,report}.py`, `experiments/{runner,manifest,cli}.py` (experiment and method runs, logical export), `fixtures/tiny_saas/*`, `configs/policies/sp-tiny-1.yaml`, `configs/experiments/m1_tiny_saas.yaml`.
- **Interfaces required**: `SnapshotView` (with `latest_version`, `effective_version`, `applicable_passages`), `ArchiveView`, `Selector`, `Retriever` (BM25), `EvidenceGatherer`, `Verifier`, `Router`, `resolve_claim_status`, `CostLedger`.
- **Tests**: T-ARCH-001, T-TEXT-001..004, T-DATA-001..008, T-ING-001..009, T-UPD-001, T-UPD-002, T-UPD-004, T-SEM-001..006, T-SEM-008, T-SEM-009, T-SEM-010, T-SEM-012, T-SEM-014, T-SEM-015, T-CAND-001, T-CAND-002, T-CAND-005, T-CAND-007, T-RET-001, T-RET-002, T-EVID-001, T-EVID-002, T-EVID-004, T-EVID-007, T-VER-001, T-VER-005, T-VER-007, T-VER-008, T-BASE-001..004, T-BASE-008, T-BASE-011, T-BASE-012, T-EVAL-001..003, T-EVAL-010, T-COST-001, T-PIPE-004, T-PIPE-006, T-PIPE-007, T-REPRO-001..003, acceptance AS-01, AS-02, AS-03, AS-04, AS-07, AS-09, AS-11, AS-12, AS-14 (duplicate part), AS-19 (park), AS-21, AS-23, AS-24, T-UPD-008, T-SEM-017, T-EVID-009, T-BASE-013, invariants T-INV-001..008.
- **Expected artifacts**: `runs/<experiment_id>/` with every file of 13.8 for each method run; `report.md` with the "software test, not empirical" banner; exported JSON Schemas in `schemas/`.
- **Completion criteria**: (1) `aftermath run-experiment configs/experiments/m1_tiny_saas.yaml` exits 0 offline; (2) two runs give the same `experiment.sha256` (T-REPRO-003); (3) the integrity records of Section 6.6 produced for `fx-0003` by the B3b method run match field by field, except measured fields and ids derived from the illustrative bundle; the illustrative bundle and the fields derived from it are not compared, and evidence gathering is tested against its rules instead (T-TEXT-003, T-EVID-009); (3a) running the method runs in reverse order yields identical canonical bundles and identical comparison results (T-BASE-013); (4) the B1 and B3b method runs keep independent states, costs and verdict histories for answers that only B1 selects (T-PIPE-007); (5) all listed tests pass; (6) lockfile committed.
- **Remaining limitations**: scripted verifier only; no splits or merges; no concurrency; `ROLLING_CURRENT` and `FIXED_TIME` applicability through `eff_k` with document-level effective dates from source timestamps or declared metadata, but no scheduled rechecks (M2) and no dates extracted from text (M9); no bundle partitioning (M2); fixture only.

### M2: Workflow robustness and temporal basics

- **Objective**: make the pipeline correct under duplicates, retries, races, failures, deletions, structural changes, budgets and basic temporal scopes.
- **Modules/files**: `pipeline/jobs.py` (worker pool, leases), `pipeline/commit.py` (CAS rules of 8.11), `pipeline/barriers.py` (named barrier points for tests), `pipeline/scheduler.py` (`ScheduledRecheck`, `CLOCK_TICK`), `diff/align.py` (splits, merges, uncertain expansion), `corpus/ingest.py` (tombstones, `RETRY_APPLY`), `evidence/bundle.py` (partitioning, 9.5 step 9), `routing/budget.py`, `verify/scripted.py` (pause hook, failure scripts).
- **Interfaces required**: `Budget`, scheduler hooks; no new public protocols.
- **Tests**: T-UPD-003, T-UPD-005, T-UPD-006 (declared metadata), T-UPD-007, T-SEM-007, T-SEM-013, T-DATA-005, T-VER-003, T-EVID-008, T-EVID-010, T-ROUTE-001, T-ROUTE-002, T-PIPE-001..003, T-PIPE-008, AS-05, AS-06, AS-08, AS-10 (resolution with scripted judgments), AS-13 to AS-18, AS-20, AS-22.
- **Expected artifacts**: acceptance test report; updated fixtures and scripts.
- **Completion criteria**: race behavior is tested with controlled interleavings (T-PIPE-008, REQ-PIPE-007). The pipeline exposes named barrier points (`after_select`, `after_bundle`, `after_verify`, `before_commit`, `after_commit`). A test scheduler drives two deliveries and the verification worker through every interleaving of these points for AS-15 (enumerated, not sampled) and checks the invariants after each. Randomized test order (`pytest-randomly`) is also used, but only to catch order dependence between tests; it is not a concurrency test. All listed tests pass.
- **Remaining limitations**: scripted verifier only; effective dates only from metadata.

### M3: Real verifiers and cost instrumentation

- **Objective**: NLI (cheap) and LLM (strong) verifiers behind the shared interface, with record/replay and full token and latency accounting; baselines B5 and B6.
- **Modules/files**: `verify/nli.py`, `verify/llm.py`, `verify/providers/<provider>.py` (one first, chosen in U-010), `verify/prompts/verify-v2.txt`, `verify/parse.py`, `verify/replay.py`, `cost/pricing.py`, `configs/verifiers/*.yaml`.
- **Interfaces required**: `ChatProvider`, `Verifier.estimate_cost`.
- **Tests**: T-VER-001, T-VER-002, T-VER-004, T-VER-006, T-SEC-001, T-SEC-002, T-COST-002..004, T-BASE-005, T-BASE-006, model-quality probes on AS-01..AS-20 (logged, not gated).
- **Expected artifacts**: recorded responses for the fixture in `cache/responses/`; probe summary `runs/<experiment_id>/methods/<method_run_id>/probes.md`.
- **Completion criteria**: replay of a recorded run reproduces `experiment.sha256`; partition quality is measured (U-027): on bundles that fit one call, judgments with and without forced partitioning are compared and the disagreement rate is reported; a forced `REPLAY` miss raises `ReplayMissError`; secrets absent from every output file (T-SEC-001); verifier outputs with unlocatable quotes are rejected (T-VER-002).
- **Remaining limitations**: verifier quality unknown beyond fixture probes.

### M4: Data audit, annotation tooling and pilot benchmark (Stage A gate)

- **Objective**: resolve U-001 to U-005, build the first natural track (HoH unless the audit rules it out), annotation tooling and gold store, splits and leakage checks, and run B1 to B6 on the pilot with bootstrap CIs.
- **Modules/files**: `datasets/{hoh,dynaquest,vitaminc,fruit,garage,construct,splits}.py`, `annotation/*`, `eval/bootstrap.py`, `eval/curves.py`, `docs/rubric-v1.md`, `data/README.md` (download instructions and licenses).
- **Interfaces required**: dataset adapter protocol `DatasetAdapter.to_deliveries_and_archive(manifest) -> Stream`.
- **Tests**: T-DATA-009..011, T-TRAIN-002, T-EVAL-004..007, T-SEC-002 (injection fixture inside a dataset document).
- **Expected artifacts**: `data/<dataset>/manifest.json` with hashes; pilot gold store; agreement report; pilot report with all Stage A baselines.
- **Completion criteria (gate G-A)**: (1) license and access decisions recorded for each dataset; (2) leakage checks pass; (3) pilot report exists with per-track metrics and CIs, including B10; (4) the plan's first exit gate is evaluated again at pilot scale, building on G-0: is there a genuine difference between dependency changes and semantic impact in the natural data, and are there enough naturally occurring selective-update cases? If not, the project narrows to the diagnostic benchmark (plan Section 10) and the decision is logged.
- **Remaining limitations**: Stage B methods absent.

### M5: Claims, inferred links and support groups (Stage B)

- **Objective**: `decompose-v1`, citation audit, inferred evidence links and verified support groups per 9.6.
- **Modules/files**: `archive/claims.py`, `archive/support_init.py` (Stage B form), `evidence/groups.py`, prompts for decomposition.
- **Tests**: T-SEM-011, T-EVID-003, T-EVID-006, T-CAND-003, AS-12 (inferred link row), AS-06 with verified groups.
- **Completion criteria**: claim coverage check implemented; group caps enforced; decomposition and support-init cost recorded as `COLD_START`.
- **Remaining limitations**: decomposition quality measured only on annotated subset.

### M6: Two-path candidate retrieval and audit sample

- **Objective**: hybrid claim index, discovery path, provenance with inferred links, union, audit sample.
- **Modules/files**: `retrieval/{dense,hybrid,rerank}.py`, `selection/{provenance,discovery,audit}.py`.
- **Tests**: T-CAND-003, T-CAND-004, T-CAND-006, AS-07 and AS-10 discovery rows.
- **Completion criteria**: ablations A1 and A2 runnable; candidate recall reported on validation.
- **Remaining limitations**: reranker off unless U-021 resolves in its favour.

### M7: Transition model

- **Objective**: train, calibrate and evaluate the paired model and the independent comparator.
- **Modules/files**: `transition/*`.
- **Tests**: T-TRAIN-001 (CI), T-TRAIN-003, T-TRAIN-004, T-TRAIN-005 and T-TRAIN-006 (experiment).
- **Completion criteria (gate G-M7)**: the paired model beats B5 on validation macro-F1 and risk-coverage, and the system using it beats B10 (provenance plus similarity with the shared strong verifier) on total cost at matched unsafe retention, both with CIs; otherwise the model is not adopted and the decision is logged (REQ-TRAIN-005).
- **Remaining limitations**: depends on annotation volume (U-015).

### M8: Router and escalation

- **Objective**: routing policies of 8.10, budget sweeps, risk-coverage and cost curves.
- **Modules/files**: `routing/policies.py`, `eval/curves.py`.
- **Tests**: T-ROUTE-003..005.
- **Completion criteria**: thresholds fit on calibration only (hash checked); curves produced for all four policies.

### M9: Full temporal handling

- **Objective**: effective-date extraction from text, out-of-order backfill, scheduled rechecks at scale.
- **Modules/files**: `evidence/temporal.py`, `diff/features.py` (date extraction), `corpus/ingest.py` (`backfill-v1`).
- **Tests**: T-UPD-006 (extracted dates), AS-08 full, AS-19 backfill row.
- **Completion criteria**: extraction precision measured on annotated dates; A5 ablation runnable.

### M10: Held-out evaluation, ablations and adaptations

- **Objective**: test-split runs, ablations A1 to A8, stress settings, B7, B8 and B9 adaptations, final report.
- **Tests**: T-EVAL-008, T-BASE-007..010.
- **Completion criteria**: every reported number traceable to a run id; plan exit gates for weeks 7 to 10 evaluated and written up honestly, including negative outcomes.

### M11: API and inspection UI (Stage C)

- **Objective**: FastAPI read endpoints and a thin Next.js UI for: inspect update, inspect affected answer, compare old/new evidence spans, view pending and withheld cases, approve a proposed repair.
- **Endpoints (planned)**: `GET /updates`, `GET /updates/{id}`, `GET /updates/{id}/report`, `GET /answers/{id}`, `GET /answers/{id}/history`, `GET /answers/{id}/evidence?snapshot=`, `GET /queue?state=WITHHELD`, `POST /repairs/{id}/approve`. No endpoint publishes to external users.
- **Tests**: T-API-001..003, T-UI-001.
- **Completion criteria**: UI renders the AS-03 and AS-11 cases with correct highlighted spans (UTF-16 conversion tested).

### M12: Optional minimal repair

- **Objective**: propose edits only for affected claims, check independently, keep old and new answer versions, require human approval.
- **Tests**: T-REPAIR-001, T-REPAIR-002.
- **Completion criteria**: repaired versions are `REPAIRED` with parent pointer and status `PROPOSED` until approved; unaffected claims preserved (token-level check).

### M13: Larger streams and additional domains

- **Objective**: public versioned software documentation track; scale tests (archive x25).
- **Completion criteria**: per-project hold-out respected; licenses recorded.

---

## 16. Requirements

Level: M = MUST, S = SHOULD, Y = MAY. Stage: A, B, C.

### 16.1 Scope

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-SCOPE-001 | M | A | Every verdict and report MUST describe support within the bounded corpus under the declared temporal scope and source policy, never truth in general. |
| REQ-SCOPE-002 | M | A | The implementation MUST NOT introduce multi-agent orchestration, a graph database, distributed services, autonomous web crawling or reinforcement learning without a decision-log entry citing a demonstrated requirement. |
| REQ-SCOPE-003 | M | A | Custom model training and UI work MUST NOT start before gate G-A (M4) passes. |
| REQ-SCOPE-004 | M | A | The G-0 questions (M0) MUST be answered and logged before M1 work beyond `core`, `textproc` and `store`, and before any later milestone starts. |
| REQ-SCOPE-005 | M | A | The M0 sampling, labelling and decision protocol MUST be written and its hash logged before any M0 result is inspected; later changes MUST be logged with reasons; the two M0 tracks MUST be reported separately, and prevalence MUST be estimated only from the unconditioned track. |

### 16.2 Semantics

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-SEM-001 | M | A | Semantic status MUST be one of `SUPPORTED`, `CONTRADICTED`, `INSUFFICIENT_SUPPORT`, `UNRESOLVED_CONFLICT`, and MUST be null for answers never assessed. |
| REQ-SEM-002 | M | A | Workflow state MUST be stored separately from semantic status, use the states and transitions of 5.3, and reject illegal transitions. |
| REQ-SEM-003 | M | A | Every verdict MUST record `valid_for_snapshot_id`, `evaluation_time` and `source_policy_version`. |
| REQ-SEM-004 | M | A | Answer status MUST be aggregated from material claim statuses by the precedence rule of 5.6; partial verdicts MUST NOT be committed. |
| REQ-SEM-005 | M | A | Absence of supporting or contradicting evidence MUST yield `INSUFFICIENT_SUPPORT`, never `CONTRADICTED`. |
| REQ-SEM-006 | M | A | Answers not selected MUST NOT receive a new verdict; their status MUST be carried forward with `verification_basis = CARRIED_FORWARD`, and reports MUST count them separately from verified answers. |
| REQ-SEM-007 | M | A | Failures, malformed outputs, timeouts and budget exhaustion MUST NOT produce a semantic status. |
| REQ-SEM-008 | M | A | Evidence applicability MUST follow the scope rules of 5.7 for `ROLLING_CURRENT`, `FIXED_TIME` and `FIXED_VERSION` (document-level effective dates from M1; passage-level overrides from M9). |
| REQ-SEM-009 | M | A | Claim status MUST be computed from verifier judgments by the shared deterministic `resolve_claim_status` under the active source policy for every verifier. |
| REQ-SEM-010 | M | A | Non-material claims MUST NOT change the answer status and MUST be recorded in `nonmaterial_issues` when not supported. |
| REQ-SEM-011 | M | B | Low-confidence decompositions MUST fall back to sentence or answer claims, which MUST be escalated to the strong verifier. |
| REQ-SEM-012 | M | A | Answers MUST be evaluated under their original question scope; historical questions MUST NOT be re-evaluated as current questions. |
| REQ-SEM-013 | M | B | Future-effective content MUST NOT apply to current evaluation before its effective time; selected candidates MUST receive scheduled rechecks; missed future-effective impacts MUST be measured. |
| REQ-SEM-014 | M | A | Availability MUST be derived by the rule of 5.9 and never set independently. |
| REQ-SEM-015 | M | A | Applicability MUST be resolved by `eff_k` over all versions known at the target snapshot; a known revision that is not yet in force MUST NOT displace the revision in force. |
| REQ-SEM-017 | M | A | Supersession MUST follow `supersession-v1` (5.7); events needing revision withdrawal without replacement MUST be flagged `CANCELLATION_UNSUPPORTED` and counted. |
| REQ-SEM-016 | M | A | Documents with mixed effective dates MUST be flagged and excluded from the temporal track until passage-level applicability (M9) exists, and the exclusions MUST be reported. |

### 16.3 Data

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-DATA-001 | M | A | Text MUST be canonicalized by `canon-v1`; all offsets MUST be code-point offsets into canonical text and reproduce stored spans exactly. |
| REQ-DATA-002 | M | A | Content hashes MUST be SHA-256 over canonical UTF-8 text or `cjson-v1`. |
| REQ-DATA-003 | M | A | Tables listed as append-only MUST reject UPDATE and DELETE at the database level. |
| REQ-DATA-004 | M | A | Pointer tables MUST be updated only by compare-and-swap inside a transaction, with every change logged. |
| REQ-DATA-005 | M | A | Timestamps MUST be UTC RFC 3339 with milliseconds and `Z`; naive datetimes MUST be rejected. |
| REQ-DATA-006 | M | A | IDs MUST follow the grammar of 6.3 and be deterministic for identical inputs. |
| REQ-DATA-007 | M | A | Every serialized record MUST carry `schema_version` and `record_type`; JSON Schemas MUST be exported from the Pydantic models. |
| REQ-DATA-008 | M | A | Gold labels, gold evidence and gold support MUST live only in the gold store, readable only by `aftermath.eval` and `aftermath.annotation`. |
| REQ-DATA-009 | M | A | Every model-derived record MUST record model id, prompt version (if any) and config hash. |
| REQ-DATA-010 | M | A | Every example and report row MUST carry its track (`NATURAL`, `SYNTHETIC_INTERVENTION`, `FIXTURE`). |
| REQ-DATA-011 | M | B | Splits MUST be by group (document, entity or project) with temporal cutoffs and duplicate clustering per 10.6; contrastive mates MUST stay in one split. |

### 16.4 Ingestion

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-ING-001 | M | A | Document versions MUST be immutable; a known revision id with different content MUST raise `IdempotencyConflictError`. |
| REQ-ING-002 | M | A | Deliveries MUST be idempotent by `delivery_id` and payload hash (8.1). |
| REQ-ING-003 | M | A | A delivery containing an out-of-order document MUST be parked whole in Stage A with no version written, and applied with backfill in one transaction in Stage B; an out-of-order version MUST never become the latest observed version. |
| REQ-ING-004 | M | A | Answer ingestion MUST record question, scope, `answered_at`, `generated_against_snapshot_id`, claims and recorded citations. |
| REQ-ING-005 | M | A | Citations MUST be resolved and recorded with a resolution status and MUST NOT be treated as verified support. |
| REQ-ING-006 | M | A | Undecodable source bytes MUST be rejected with `InvalidEncodingError`. |
| REQ-ING-007 | M | A | Delivery validation MUST complete before any write; the apply phase MUST commit fully or roll back fully, with no early return inside the transaction. |
| REQ-ING-008 | M | A | Redelivery MUST follow the redelivery table of 8.1 for each prior status. |
| REQ-ING-009 | M | A | A new revision id MUST create a new `DocumentVersion` even when its text is unchanged; a change of `source_type` MUST produce an `AUTHORITY_CHANGED` span. |

### 16.5 Update detection

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-UPD-001 | M | A | Each new version MUST be compared with the document's current version in the head snapshot (8.2). |
| REQ-UPD-002 | M | A | Alignment MUST classify passages into the classes of 8.4.1 using `diff-v1`. |
| REQ-UPD-003 | M | A | Low-confidence or unmatched alignment MUST expand change scope to the section or document. |
| REQ-UPD-004 | M | A | Change spans MUST record numeric, date, negation and qualifier features. |
| REQ-UPD-005 | M | A | Deletions MUST be tombstones; prior versions MUST remain available as history. |
| REQ-UPD-006 | S | B | `effective_from` SHOULD be taken from declared metadata, then text extraction, then source timestamp, recording the source. |
| REQ-UPD-007 | M | A | Every delivery MUST be checked for effective-timeline changes (8.3a); an interval whose in-force content changes MUST produce an `ApplicabilityChange` and change spans even when the latest text is unchanged. |

### 16.6 Candidate selection

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-CAND-001 | M | A | Every selector MUST implement `Selector` and attach at least one reason to each candidate. |
| REQ-CAND-002 | M | A | Merged candidates MUST keep all distinct reasons and use the deterministic ranking and tie-break of 8.7. |
| REQ-CAND-003 | M | B | The provenance path MUST include recorded citations, document-only citations and inferred links of any confidence. |
| REQ-CAND-004 | M | B | The discovery path MUST search the claim index with new and old change text (8.6). |
| REQ-CAND-005 | M | A | `FIXED_VERSION` answers MUST be recorded as `TEMPORALLY_EXCLUDED`, not silently skipped. |
| REQ-CAND-006 | S | B | An audit sample outside the candidate set SHOULD be run and reported separately from method metrics. |
| REQ-CAND-007 | M | A | Selectors MUST NOT access gold data. |

### 16.7 Evidence

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-EVID-001 | M | A | Evidence MUST be read only from the job's target snapshot and history up to it. |
| REQ-EVID-002 | M | A | Bundles MUST meet per-call limits by dropping optional items only, and MUST list every dropped or windowed item with its role and reason. |
| REQ-EVID-003 | M | B | Support groups MUST follow AND-within, OR-across semantics with the size and count caps of 9.6; exhaustive subset enumeration is forbidden. |
| REQ-EVID-004 | M | A | Contradiction candidates MUST be gathered and judged even when old support survives. |
| REQ-EVID-005 | M | A | Evidence text MUST be passed to verifiers only inside delimited, escaped data blocks. |
| REQ-EVID-006 | S | B | After a `SUPPORTED` verdict, supporting groups SHOULD be re-recorded at the target snapshot. |
| REQ-EVID-008 | M | B | Partitions MUST be packed deterministically per 9.5 step 9, with overlapping groups merged, one home partition per required entry, and anchor judgments outside home partitions excluded from resolution. |
| REQ-EVID-007 | M | A | Must-keep evidence MUST NOT be dropped silently: bundles MUST be partitioned up to `max_partitions` (from M2); beyond that the job MUST end `WITHHELD` (`EVIDENCE_OVERFLOW`) with no verdict; any incompleteness MUST block cheap acceptance; truncation MUST be reported by role. |

### 16.8 Verification

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-VER-001 | M | A | All verifiers MUST implement `Verifier`; outputs MUST be validated against the output schema. |
| REQ-VER-002 | M | A | Supporting and contradicting judgments MUST cite quotes locatable in the referenced passage; unlocatable quotes MUST be discarded and recorded. |
| REQ-VER-003 | M | A | Retries MUST be bounded (3 attempts); exhausted jobs MUST end `FAILED`. |
| REQ-VER-004 | M | A | Hosted model calls MUST support `RECORD` and `REPLAY` modes keyed by request hash. |
| REQ-VER-005 | M | A | Mock verifiers MUST set `is_mock = true`; runs containing mock results MUST NOT produce empirical tables. |
| REQ-VER-006 | M | A | Per-call timeouts MUST be configurable (default 60 s). |
| REQ-VER-007 | M | A | Verifier results MUST give exactly one valid stance for every required coverage entry; otherwise the result is `INCOMPLETE_COVERAGE`, retried, and finally `FAILED` without status. |
| REQ-VER-008 | M | A | SUPPORTS and CONTRADICTS judgments MUST cite one located quote per member passage. |

### 16.9 Routing

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-ROUTE-001 | M | A | Candidates not escalated or accepted within budget MUST be `WITHHELD` with null status; provisional predictions MUST NOT be committed. |
| REQ-ROUTE-002 | M | A | Every candidate MUST have a `RoutingDecision` recording policy, action, estimate and budget before and after. |
| REQ-ROUTE-003 | M | B | Routing thresholds MUST be fit only on the calibration split, and the split hash MUST be recorded. |
| REQ-ROUTE-004 | S | B | Risk-only, uncertainty-only and uniform policies SHOULD be available for comparison. |
| REQ-ROUTE-005 | M | B | Fallback claims, missing predictions, incomplete model inputs and incomplete bundles MUST force escalation (or withholding when budget is exhausted). |

### 16.10 Pipeline

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-PIPE-001 | M | A | Updates for a corpus MUST be applied sequentially by one writer with CAS on head. |
| REQ-PIPE-002 | M | A | A verdict MUST be committed for its job's target snapshot and MUST change current state only if the job is still the answer's active job. |
| REQ-PIPE-003 | M | A | Failure of one answer's assessment MUST NOT affect others; apply failures MUST roll back completely. |
| REQ-PIPE-004 | M | A | Every processed delivery MUST produce an update report (8.12). |
| REQ-PIPE-005 | M | A | In `REPLAY` mode a run MUST reproduce candidates, routing and verdicts exactly. |
| REQ-PIPE-006 | M | A | Empty candidate sets MUST complete normally with all answers carried forward. |
| REQ-PIPE-007 | M | A | Race behavior MUST be tested with controlled, enumerated interleavings at named barrier points. |

### 16.11 Baselines

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-BASE-001 | M | A | B1 exhaustive revalidation per 11.2. |
| REQ-BASE-002 | M | A | B2 document invalidation in both modes per 11.2. |
| REQ-BASE-003 | M | A | B3 passage invalidation in both modes per 11.2. |
| REQ-BASE-004 | M | A | B4 similarity selection per 9.4. |
| REQ-BASE-005 | M | A | B5 independent old/new NLI per 11.2 (M3). |
| REQ-BASE-006 | M | A | B6 direct strong-LLM paired-evidence verification per 11.2 (M3). |
| REQ-BASE-007 | M | A | Selection comparisons MUST hold the verifier constant; verifier comparisons MUST hold candidates and bundles constant (11.3). |
| REQ-BASE-011 | M | A | B10 provenance plus similarity with the shared verifier per 11.2. |
| REQ-BASE-013 | M | A | Canonical bundles MUST be built from the frozen evidence state, whose hash MUST be part of the bundle id; canonical bundles and comparison results MUST NOT depend on method execution order. |
| REQ-BASE-012 | M | A | Selector-isolation comparisons MUST use canonical bundles; end-to-end comparisons MUST report evidence retrieval quality and evidence cost per method. |
| REQ-BASE-008 | M | A | `INVALIDATE_ONLY` outputs MUST be `WITHHELD` with null status, never `CONTRADICTED`. |
| REQ-BASE-009 | M | B | PACMI-style and FinCacheServe-style comparisons MUST be labelled adaptations unless original code and settings are reproduced. |
| REQ-BASE-010 | S | B | B7 TTL refresh SHOULD be implemented. |

### 16.12 Training

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-TRAIN-001 | M | B | A CPU-only, offline smoke mode MUST run in CI in under 60 seconds. |
| REQ-TRAIN-002 | M | B | Training data MUST exclude validation, calibration and test groups and any event at or after `T_test`. |
| REQ-TRAIN-003 | M | B | Calibration MUST use the calibration split only. |
| REQ-TRAIN-004 | M | B | Training runs MUST record seeds, model and tokenizer revisions, data hashes and checkpoint hashes; reported results MUST use at least 3 seeds. |
| REQ-TRAIN-005 | M | B | The transition model MUST be adopted only if it passes gate G-M7; otherwise it MUST NOT be used in the system method. |
| REQ-TRAIN-006 | M | B | Paired encoding MUST be compared against the independent classifier under identical data. |

### 16.13 Evaluation

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-EVAL-001 | M | A | Metrics MUST follow 13.2, report numerators and denominators, return null for zero denominators, and use only gold as labels. |
| REQ-EVAL-002 | M | A | Candidate, protective withholding and correct transition recall MUST be computed over all affected judgments in the archive, including never-selected answers. |
| REQ-EVAL-003 | M | A | Every safety metric MUST be reported alongside answer availability. |
| REQ-EVAL-004 | M | A | CIs MUST use cluster bootstrap by group with paired resamples for comparisons. |
| REQ-EVAL-005 | M | A | Tracks and prevalence settings MUST be reported separately. |
| REQ-EVAL-006 | M | A | Gold labels MUST be independent of the evaluated methods; test-split first-round annotation MUST be blind to model output. |
| REQ-EVAL-007 | M | B | Oracle-provenance conditions MUST be labelled upper bounds and never defaults. |
| REQ-EVAL-008 | M | B | Ablations A1 to A8 MUST be runnable from config. |
| REQ-EVAL-009 | M | A | Reports MUST NOT describe targets as achieved, claim deterministic hosted outputs, or claim formal reliability guarantees. |
| REQ-EVAL-010 | M | A | Candidate recall, protective withholding recall and correct transition recall MUST be reported separately, with availability, and never combined into one "recall". |
| REQ-EVAL-011 | M | B | Audit-based miss estimates in empirical reports MUST use human labels; verifier-only audit results MUST be reported as verifier-detected change rates. |

### 16.14 Cost, reproducibility, security, API, UI, repair

| ID | Lvl | Stg | Requirement |
|---|---|---|---|
| REQ-COST-001 | M | A | Every stage in the `CostRecord.stage` enum MUST be instrumented. |
| REQ-COST-002 | M | A | Cold-start, incremental, amortized and offline costs MUST be reported separately. |
| REQ-COST-003 | M | A | Money MUST be computed only from a dated price table; raw units MUST always be reported. |
| REQ-COST-004 | M | A | Retries and audit sampling MUST be included in totals. |
| REQ-REPRO-001 | M | A | Each run MUST write the outputs of 13.8. |
| REQ-REPRO-002 | M | A | A dependency lockfile MUST be generated and committed before M1 completes. |
| REQ-REPRO-003 | M | A | Two runs of the M1 config MUST produce an identical `experiment.sha256` computed over canonical logical records (13.8). |
| REQ-REPRO-004 | M | A | Each (method, seed) MUST run as a separate method run with its own store and operational identities; no mutable record may be shared between method runs. |
| REQ-SEC-001 | M | A | Secrets MUST come from environment variables only and MUST NOT appear in configs, logs, records or reports. |
| REQ-SEC-002 | M | A | Instructions inside documents, passages or answers MUST NOT influence control flow; only parsed enum fields and located quotes from verifier output are acted upon. |
| REQ-API-001 | S | C | The API SHOULD expose the read endpoints of M11. |
| REQ-API-002 | M | C | Components MUST NOT publish corrections to external users automatically; repairs MUST require explicit human approval. |
| REQ-API-003 | M | C | The API MUST convert code-point offsets to UTF-16 offsets for browser clients at the boundary only. |
| REQ-UI-001 | S | C | The UI SHOULD support inspect update, inspect affected answer, compare evidence, view pending/withheld, approve repair. |
| REQ-REPAIR-001 | Y | C | The system MAY propose minimal repairs limited to affected claims. |
| REQ-DOC-001 | M | A | Every exported form of this specification MUST be validated for text content against the Markdown source: each raw cell MUST parse to its table cell's exact text, tables MUST match in shape and exact cell text, code blocks MUST match byte for byte and in order, and raw HTML MUST be absent. Visual layout is checked by rendering, separately. |
| REQ-DOC-002 | M | A | The specification build MUST exit non-zero when any mandatory audit fails, and a negative test MUST show that each audit category fails the build when a fault is injected. |
| REQ-REPAIR-002 | M | C | Any repair MUST be independently verified, MUST preserve unaffected claims, and MUST create a new `AnswerVersion` with a parent pointer. |


---

## 17. Requirements-to-tests traceability

### 17.1 Test catalog

| Test | Location | Kind | Checks |
|---|---|---|---|
| T-ARCH-001 | `pyproject.toml` import-linter, run in CI | static | Dependency direction of 7.4; gold import ban |
| T-TEXT-001 | `tests/unit/textproc/test_offsets.py` | unit | `text[start:end]` equals stored passage, citation, span and quote text |
| T-TEXT-002 | `tests/unit/textproc/test_segment_property.py` | property | Segmentation coverage and ordering |
| T-TEXT-003 | `tests/integration/test_worked_example.py` | integration | Integrity records for `fx-0003` match Section 6.6 exactly; the illustrative bundle is excluded |
| T-TEXT-004 | `tests/unit/textproc/test_canon.py` | unit | BOM, CRLF, NFC; invalid UTF-8 rejected |
| T-DATA-001 | `tests/unit/core/test_hashing.py` | unit | `cjson-v1` and SHA-256 vectors |
| T-DATA-002 | `tests/unit/core/test_ids.py` | unit | ID grammar, determinism, operational id tuples |
| T-DATA-003 | `tests/integration/store/test_append_only.py` | integration | UPDATE/DELETE on append-only tables abort |
| T-DATA-004 | `tests/integration/store/test_snapshots.py` | integration | Membership query and `manifest_hash` recomputation |
| T-DATA-005 | `tests/integration/store/test_cas.py` | integration | `StaleHeadError`, `StaleStateError` on concurrent writers |
| T-DATA-006 | `tests/unit/core/test_time.py` | unit | Naive datetimes rejected; format |
| T-DATA-007 | `tests/unit/core/test_schemas.py` | unit | Round-trip, `schema_version`, exported JSON Schema up to date |
| T-DATA-008 | `tests/unit/test_gold_isolation.py` | unit | Import ban plus `LeakageError` on gold path in method config |
| T-DATA-009 | `tests/unit/test_model_provenance.py` | unit | Model-derived records carry model id, prompt version, config hash |
| T-DATA-010 | `tests/unit/eval/test_tracks.py` | unit | Track propagated to every metric row; mixing raises |
| T-DATA-011 | `tests/unit/datasets/test_splits.py` | unit | Group splits, temporal cutoff, dedup clusters, contrastive mates together |
| T-ING-001 | `tests/integration/test_ingest.py::conflict` | integration | Same revision, different content |
| T-ING-002 | `tests/integration/test_ingest.py::duplicate` | integration | Duplicate and conflicting deliveries (AS-14) |
| T-ING-003 | `tests/integration/test_ingest.py::out_of_order` | integration | Park (Stage A), backfill (Stage B) |
| T-ING-004 | `tests/integration/test_archive.py` | integration | Answer fields, claims, `NoMaterialClaimsError` |
| T-ING-005 | `tests/unit/archive/test_citations.py` | unit | Resolution kinds |
| T-ING-006 | `tests/unit/textproc/test_canon.py::invalid` | unit | `InvalidEncodingError` |
| T-ING-007 | `tests/integration/test_ingest_atomic.py` | integration | A mixed delivery that parks writes nothing; a fault injected mid-apply rolls back every version |
| T-ING-008 | `tests/integration/test_redelivery.py` | integration | Every row of the redelivery table |
| T-ING-009 | `tests/integration/test_same_text_revision.py` | integration | New version for unchanged text (AS-23); `AUTHORITY_CHANGED` span |
| T-UPD-001 | `tests/unit/diff/test_prior.py` | unit | Prior choice incl. re-added documents |
| T-UPD-002 | `tests/unit/diff/test_align.py` | unit | Classes on fixture pairs (AS-01, AS-02, AS-03) |
| T-UPD-003 | `tests/unit/diff/test_expand.py` | unit | Section and document expansion |
| T-UPD-004 | `tests/unit/diff/test_features.py` | unit | Feature extraction vectors |
| T-UPD-005 | `tests/integration/test_delete.py` | integration | Tombstones, history (AS-18) |
| T-UPD-006 | `tests/unit/evidence/test_effective.py` | unit | Effective-from sources and intervals |
| T-UPD-007 | `tests/unit/diff/test_split_merge.py` | unit | Split/merge lineage (AS-20) |
| T-UPD-008 | `tests/unit/diff/test_timeline.py` | unit | Timeline diff: effective-date-only changes, merged equal intervals, reuse of text-diff spans (AS-24) |
| T-SEM-001 | `tests/unit/core/test_enums.py` | unit | Status enum, nullability |
| T-SEM-002 | `tests/unit/pipeline/test_transitions.py` | unit | Allowed and illegal transitions |
| T-SEM-003 | `tests/unit/core/test_verdict_schema.py` | unit | Required verdict fields |
| T-SEM-004 | `tests/unit/evidence/test_aggregate.py` | unit | Table-driven aggregation |
| T-SEM-005 | `tests/unit/evidence/test_resolve.py::no_evidence` | unit | Empty judgments give `INSUFFICIENT_SUPPORT` |
| T-SEM-006 | `tests/integration/test_carry_forward.py` | integration | Unselected answers carried forward and counted |
| T-SEM-007 | `tests/integration/test_no_status_on_failure.py` | integration | Failure and budget paths leave null status |
| T-SEM-008 | `tests/unit/evidence/test_scope.py` | unit | Applicability under three scopes |
| T-SEM-009 | `tests/unit/evidence/test_resolve.py` | unit | Every rule of 5.8 |
| T-SEM-010 | `tests/unit/evidence/test_nonmaterial.py` | unit | Non-material claims ignored for status |
| T-SEM-011 | `tests/unit/archive/test_fallback_claims.py` | unit | Fallback claims and forced escalation |
| T-SEM-012 | `tests/acceptance/test_as_09_historical.py` | acceptance | Historical scope preserved |
| T-SEM-013 | `tests/acceptance/test_as_08_future.py` | acceptance | Scheduled rechecks |
| T-SEM-014 | `tests/unit/pipeline/test_availability.py` | unit | Availability derivation |
| T-SEM-015 | `tests/unit/corpus/test_effective_version.py` | unit | `eff_k` with future-effective versions, tombstones, ties and backfill; latest vs effective |
| T-SEM-016 | `tests/unit/datasets/test_mixed_effective.py` | unit | Mixed-date documents flagged, excluded and counted |
| T-SEM-017 | `tests/unit/corpus/test_supersession.py` | unit | Same-date higher-seq revision cancels a scheduled change; an earlier-dated revision does not |
| T-CAND-001 | `tests/unit/selection/test_contract.py` | unit | Every selector returns reasons |
| T-CAND-002 | `tests/unit/selection/test_union.py` | unit | Merge, dedupe, ranking, tie-break, overflow recorded |
| T-CAND-003 | `tests/unit/selection/test_provenance.py` | unit | Citation, document-only and low-confidence links |
| T-CAND-004 | `tests/unit/selection/test_discovery.py` | unit | Queries from new and old text |
| T-CAND-005 | `tests/unit/selection/test_temporal_exclusion.py` | unit | `TEMPORALLY_EXCLUDED` recorded |
| T-CAND-006 | `tests/unit/selection/test_audit.py` | unit | Seeded sample, separate reporting |
| T-CAND-007 | covered by T-DATA-008 and T-ARCH-001 | static | No gold access |
| T-RET-001 | `tests/unit/retrieval/test_bm25.py` | unit | Scores, rounding, tie-breaks |
| T-RET-002 | `tests/unit/retrieval/test_incremental.py` | unit | Incremental add equals rebuild |
| T-EVID-001 | `tests/integration/test_evidence_snapshot.py` | integration | Bundles ignore head changes |
| T-EVID-002 | `tests/unit/evidence/test_limits.py` | unit | Limits, role priority, windows containing the change span, `dropped` |
| T-EVID-003 | `tests/unit/evidence/test_groups.py` | unit | Group caps and semantics |
| T-EVID-004 | `tests/unit/evidence/test_contradiction_included.py` | unit | Contradiction candidates with surviving support |
| T-EVID-005 | `tests/unit/verify/test_prompt_escaping.py` | unit | Delimiters escaped; evidence only in data blocks |
| T-EVID-006 | `tests/integration/test_support_refresh.py` | integration | Groups re-recorded after `SUPPORTED` |
| T-EVID-007 | `tests/unit/evidence/test_must_keep.py` | unit | Only optional items trimmed; `dropped_by_role`; overflow gives `WITHHELD`; incompleteness blocks cheap acceptance |
| T-EVID-008 | `tests/integration/test_partitions.py` | integration | Partitioning end to end (AS-22) |
| T-EVID-009 | `tests/unit/evidence/test_gather_rules.py` | unit | Gathering rules on the fixture, asserted rule by rule (roles, deduplication, applicability, positive-score retrieval, contradiction candidates, limits), not equality with the 6.6 bundle |
| T-EVID-010 | `tests/unit/evidence/test_packing.py` | unit | Deterministic packing, merged overlapping groups, one home partition per entry, anchors excluded from resolution |
| T-VER-001 | `tests/unit/verify/test_parse_schema.py` | unit | Schema validation |
| T-VER-002 | `tests/unit/verify/test_quotes.py` | unit | Quote location exact and normalized; rejection |
| T-VER-003 | `tests/integration/test_retries.py` | integration | 3 attempts then `FAILED` (AS-17) |
| T-VER-004 | `tests/unit/verify/test_replay.py` | unit | Record, replay, `ReplayMissError` |
| T-VER-005 | `tests/unit/eval/test_mock_banner.py` | unit | `MockResultReportingError`, banner |
| T-VER-006 | `tests/unit/verify/test_timeout.py` | unit | Timeout mapping |
| T-VER-007 | `tests/unit/verify/test_coverage.py` | unit | Missing or conflicting judgments give `INCOMPLETE_COVERAGE`; retry names missing entries (AS-21) |
| T-VER-008 | `tests/unit/verify/test_group_citations.py` | unit | One located citation per group member |
| T-ROUTE-001 | `tests/acceptance/test_as_16_budget.py` | acceptance | Budget exhaustion |
| T-ROUTE-002 | `tests/unit/routing/test_records.py` | unit | One decision per candidate with budgets |
| T-ROUTE-003 | `tests/unit/routing/test_threshold_provenance.py` | unit | Calibration split hash recorded and checked |
| T-ROUTE-004 | `tests/unit/routing/test_policies.py` | unit | Policy orderings deterministic |
| T-ROUTE-005 | `tests/unit/routing/test_forced.py` | unit | Forced escalation cases |
| T-PIPE-001 | `tests/integration/test_single_writer.py` | integration | Sequential apply, `StaleHeadError` |
| T-PIPE-002 | `tests/integration/test_job_idempotency.py` | integration | Retries and duplicate commits |
| T-PIPE-003 | `tests/integration/test_isolation.py` | integration | Partial failures |
| T-PIPE-004 | `tests/integration/test_update_report.py` | integration | Report fields |
| T-PIPE-005 | `tests/experiment/test_replay_determinism.py` | experiment | Replay reproduces records |
| T-PIPE-006 | `tests/acceptance/test_as_04_unrelated.py` | acceptance | Empty candidate set |
| T-PIPE-007 | `tests/integration/test_method_isolation.py` | integration | B1 selects an answer that B3 does not: separate stores, states, costs, verdict histories and ids |
| T-PIPE-008 | `tests/integration/test_interleavings.py` | integration | Every interleaving of the named barrier points for AS-15, invariants after each |
| T-BASE-001..004 | `tests/acceptance/test_baselines_stage_a.py` | acceptance | B1 to B4 selections on AS-01..AS-04, AS-07, AS-12 |
| T-BASE-011 | `tests/acceptance/test_baselines_stage_a.py::b10` | acceptance | B10 union and reasons on AS-03, AS-07, AS-12 |
| T-BASE-012 | `tests/integration/test_canonical_bundles.py` | integration | Same `bundle_id` and bundle for an answer selected by different selectors |
| T-BASE-013 | `tests/experiment/test_order_reversal.py` | experiment | Method runs in reverse order: identical canonical bundles (rebuilt and compared, not served from cache) and identical comparison results |
| T-BASE-005, 006 | `tests/integration/test_baselines_verifiers.py` | integration | B5, B6 wiring with fixed bundles (replayed) |
| T-BASE-007 | `tests/unit/experiments/test_comparability.py` | unit | Runner refuses non-comparable experiments |
| T-BASE-008 | `tests/unit/pipeline/test_invalidate_only.py` | unit | No verdicts, null status |
| T-BASE-009 | review R-03 plus `tests/unit/eval/test_adaptation_labels.py` | unit | Adaptation label in reports |
| T-BASE-010 | `tests/unit/selection/test_ttl.py` | unit | TTL selection |
| T-TRAIN-001 | `tests/experiment/test_train_smoke.py` | experiment (CI) | CPU smoke |
| T-TRAIN-002 | `tests/unit/datasets/test_leakage.py` | unit | Group and time leakage checks |
| T-TRAIN-003 | `tests/unit/transition/test_calibration.py` | unit | Temperature fit uses calibration split only |
| T-TRAIN-004 | `tests/unit/transition/test_run_records.py` | unit | Seeds, revisions, hashes recorded |
| T-TRAIN-005 | experiment gate G-M7 | experiment | Adoption decision logged |
| T-TRAIN-006 | experiment M7 | experiment | Paired vs independent comparison |
| T-EVAL-001 | `tests/unit/eval/test_metrics.py` | unit | Hand-computed fixture metrics, null denominators |
| T-EVAL-002 | `tests/unit/eval/test_full_archive.py` | unit | Recall counts unselected affected answers |
| T-EVAL-003 | `tests/unit/eval/test_report_pairs.py` | unit | Availability present with every safety metric |
| T-EVAL-004 | `tests/unit/eval/test_bootstrap.py` | unit | Cluster resampling, paired differences |
| T-EVAL-005 | `tests/unit/eval/test_tracks.py::prevalence` | unit | Separate tables |
| T-EVAL-006 | `tests/unit/annotation/test_blind.py` | unit | Test-split R1/R2 with `saw_model_output = true` rejected |
| T-EVAL-007 | `tests/unit/eval/test_oracle_label.py` | unit | Oracle runs labelled |
| T-EVAL-008 | `tests/experiment/test_ablation_configs.py` | experiment | A1 to A8 configs run on fixture |
| T-EVAL-009 | `tests/unit/eval/test_report_language.py` | unit | Lint for forbidden phrases in generated reports |
| T-EVAL-010 | `tests/unit/eval/test_recall_family.py` | unit | Three recalls, including the select-all, fail-all case |
| T-EVAL-011 | `tests/unit/eval/test_audit_reporting.py` | unit | Audit reported as verifier-detected rate without human labels |
| T-COST-001 | `tests/integration/test_cost_stages.py` | integration | Every stage emits records on fixture |
| T-COST-002 | `tests/unit/cost/test_amortized.py` | unit | Cold, incremental, amortized, break-even |
| T-COST-003 | `tests/unit/cost/test_pricing.py` | unit | No money without price table |
| T-COST-004 | `tests/integration/test_cost_retries_audit.py` | integration | Retry and audit costs included |
| T-REPRO-001 | `tests/experiment/test_run_outputs.py` | experiment | All 13.8 files present |
| T-REPRO-002 | CI step `uv lock --check` (planned) | static | Lockfile present and current |
| T-REPRO-003 | `tests/experiment/test_determinism.py` | experiment | Identical `experiment.sha256` over canonical logical records twice; formatted outputs regenerate identically from logical records |
| T-SEC-001 | `tests/integration/test_secrets.py` | integration | Fake key never appears in outputs |
| T-SEC-002 | `tests/integration/test_injection.py` | integration | Passage with embedded instructions cannot alter control flow |
| T-API-001..003 | `tests/integration/api/` | integration | Endpoints, no publish, UTF-16 offsets |
| T-UI-001 | `web/tests/` (Playwright, planned) | e2e | Five views |
| T-REPAIR-001, 002 | `tests/integration/test_repair.py` | integration | Scope of edit, independent check, versioning |
| T-INV-001..008 | `tests/acceptance/invariants.py` | acceptance | INV-1 to INV-8 after every scenario |
| T-DOC-001 | `build_spec.py` (spec maintenance) | static | Raw cells, table cells, ordered code blocks and raw HTML checked exactly (REQ-DOC-001) |
| T-DOC-002 | `tests/test_build_audits.py` (spec maintenance) | static | One injected fault per audit category; each must make the build exit non-zero |

Review checks (manual, recorded in PR descriptions): R-01 scope language (REQ-SCOPE-001, REQ-EVAL-009), R-02 exclusions (REQ-SCOPE-002), R-03 adaptation labelling (REQ-BASE-009), R-04 gate G-A before training/UI (REQ-SCOPE-003), R-05 G-0 answers logged (REQ-SCOPE-004), R-06 M0 protocol hash logged before results were inspected (REQ-SCOPE-005).

### 17.2 Traceability table

| Requirement | Tests | Milestone |
|---|---|---|
| REQ-SCOPE-001 | R-01, T-EVAL-009 | M1 |
| REQ-SCOPE-002 | R-02 | all |
| REQ-SCOPE-003 | R-04 | M4 |
| REQ-SCOPE-004 | R-05 | M0 |
| REQ-SCOPE-005 | R-06 | M0 |
| REQ-SEM-001 | T-SEM-001 | M1 |
| REQ-SEM-002 | T-SEM-002 | M1 |
| REQ-SEM-003 | T-SEM-003 | M1 |
| REQ-SEM-004 | T-SEM-004, AS-11 | M1 |
| REQ-SEM-005 | T-SEM-005, AS-05 | M1 |
| REQ-SEM-006 | T-SEM-006, AS-04 | M1 |
| REQ-SEM-007 | T-SEM-007, AS-16, AS-17 | M2 |
| REQ-SEM-008 | T-SEM-008, AS-07, AS-09 | M1, M9 |
| REQ-SEM-009 | T-SEM-009, AS-07, AS-10 | M1 |
| REQ-SEM-010 | T-SEM-010 | M1 |
| REQ-SEM-011 | T-SEM-011, T-ROUTE-005 | M5 |
| REQ-SEM-012 | T-SEM-012, AS-09 | M1 |
| REQ-SEM-013 | T-SEM-013, AS-08 | M2, M9 |
| REQ-SEM-014 | T-SEM-014, T-INV-004 | M1 |
| REQ-SEM-015 | T-SEM-015, AS-08 | M1, M2 |
| REQ-SEM-016 | T-SEM-016 | M0, M4 |
| REQ-SEM-017 | T-SEM-017 | M1 |
| REQ-DATA-001 | T-TEXT-001, T-TEXT-003, T-TEXT-004 | M1 |
| REQ-DATA-002 | T-DATA-001 | M1 |
| REQ-DATA-003 | T-DATA-003, T-INV-005 | M1 |
| REQ-DATA-004 | T-DATA-005 | M1, M2 |
| REQ-DATA-005 | T-DATA-006 | M1 |
| REQ-DATA-006 | T-DATA-002 | M1 |
| REQ-DATA-007 | T-DATA-007 | M1 |
| REQ-DATA-008 | T-DATA-008, T-ARCH-001 | M1 |
| REQ-DATA-009 | T-DATA-009 | M3, M4 |
| REQ-DATA-010 | T-DATA-010 | M1, M4 |
| REQ-DATA-011 | T-DATA-011, T-TRAIN-002 | M4 |
| REQ-ING-001 | T-ING-001 | M1 |
| REQ-ING-002 | T-ING-002, AS-14 | M1, M2 |
| REQ-ING-003 | T-ING-003, T-ING-007, AS-19 | M1, M9 |
| REQ-ING-004 | T-ING-004 | M1 |
| REQ-ING-005 | T-ING-005, AS-12 | M1 |
| REQ-ING-006 | T-ING-006 | M1 |
| REQ-ING-007 | T-ING-007 | M1 |
| REQ-ING-008 | T-ING-008, AS-14 | M1, M2 |
| REQ-ING-009 | T-ING-009, AS-23 | M1 |
| REQ-UPD-001 | T-UPD-001 | M1 |
| REQ-UPD-002 | T-UPD-002, AS-01, AS-02, AS-03 | M1 |
| REQ-UPD-003 | T-UPD-003, AS-20 | M2 |
| REQ-UPD-004 | T-UPD-004 | M1 |
| REQ-UPD-005 | T-UPD-005, AS-18 | M2 |
| REQ-UPD-006 | T-UPD-006 | M2, M9 |
| REQ-UPD-007 | T-UPD-008, AS-24 | M1 |
| REQ-CAND-001 | T-CAND-001 | M1 |
| REQ-CAND-002 | T-CAND-002 | M1 |
| REQ-CAND-003 | T-CAND-003, AS-12 | M5, M6 |
| REQ-CAND-004 | T-CAND-004, AS-07 | M6 |
| REQ-CAND-005 | T-CAND-005, AS-09 | M1 |
| REQ-CAND-006 | T-CAND-006 | M6 |
| REQ-CAND-007 | T-CAND-007, T-DATA-008 | M1 |
| REQ-EVID-001 | T-EVID-001, AS-15 | M1, M2 |
| REQ-EVID-002 | T-EVID-002, T-EVID-009 | M1 |
| REQ-EVID-003 | T-EVID-003 | M5 |
| REQ-EVID-004 | T-EVID-004, AS-07 | M1 |
| REQ-EVID-005 | T-EVID-005, T-SEC-002 | M3 |
| REQ-EVID-006 | T-EVID-006, AS-06 | M5 |
| REQ-EVID-007 | T-EVID-007, T-EVID-008, AS-22 | M1, M2 |
| REQ-EVID-008 | T-EVID-010, AS-22 | M2 |
| REQ-VER-001 | T-VER-001 | M1, M3 |
| REQ-VER-002 | T-VER-002 | M3 |
| REQ-VER-003 | T-VER-003, AS-17 | M2 |
| REQ-VER-004 | T-VER-004 | M3 |
| REQ-VER-005 | T-VER-005 | M1 |
| REQ-VER-006 | T-VER-006 | M3 |
| REQ-VER-007 | T-VER-007, AS-21 | M1 |
| REQ-VER-008 | T-VER-008 | M1 |
| REQ-ROUTE-001 | T-ROUTE-001, AS-16 | M2 |
| REQ-ROUTE-002 | T-ROUTE-002 | M2 |
| REQ-ROUTE-003 | T-ROUTE-003 | M8 |
| REQ-ROUTE-004 | T-ROUTE-004 | M8 |
| REQ-ROUTE-005 | T-ROUTE-005 | M8 |
| REQ-PIPE-001 | T-PIPE-001 | M2 |
| REQ-PIPE-002 | T-PIPE-002, AS-15 | M2 |
| REQ-PIPE-003 | T-PIPE-003 | M2 |
| REQ-PIPE-004 | T-PIPE-004 | M1 |
| REQ-PIPE-005 | T-PIPE-005 | M3 |
| REQ-PIPE-006 | T-PIPE-006, AS-04 | M1 |
| REQ-PIPE-007 | T-PIPE-008, AS-15 | M2 |
| REQ-BASE-001 | T-BASE-001 | M1 |
| REQ-BASE-002 | T-BASE-002 | M1 |
| REQ-BASE-003 | T-BASE-003 | M1 |
| REQ-BASE-004 | T-BASE-004 | M1 |
| REQ-BASE-005 | T-BASE-005 | M3 |
| REQ-BASE-006 | T-BASE-006 | M3 |
| REQ-BASE-007 | T-BASE-007 | M3, M10 |
| REQ-BASE-008 | T-BASE-008, T-INV-007 | M1 |
| REQ-BASE-009 | T-BASE-009, R-03 | M10 |
| REQ-BASE-010 | T-BASE-010 | M10 |
| REQ-BASE-011 | T-BASE-011 | M1 |
| REQ-BASE-012 | T-BASE-012 | M1 |
| REQ-BASE-013 | T-BASE-013 | M1 |
| REQ-TRAIN-001 | T-TRAIN-001 | M7 |
| REQ-TRAIN-002 | T-TRAIN-002 | M4, M7 |
| REQ-TRAIN-003 | T-TRAIN-003 | M7 |
| REQ-TRAIN-004 | T-TRAIN-004 | M7 |
| REQ-TRAIN-005 | T-TRAIN-005 | M7 |
| REQ-TRAIN-006 | T-TRAIN-006 | M7 |
| REQ-EVAL-001 | T-EVAL-001 | M1 |
| REQ-EVAL-002 | T-EVAL-002, T-EVAL-010 | M1 |
| REQ-EVAL-003 | T-EVAL-003 | M1 |
| REQ-EVAL-004 | T-EVAL-004 | M4 |
| REQ-EVAL-005 | T-EVAL-005 | M4 |
| REQ-EVAL-006 | T-EVAL-006 | M4 |
| REQ-EVAL-007 | T-EVAL-007 | M10 |
| REQ-EVAL-008 | T-EVAL-008 | M10 |
| REQ-EVAL-009 | T-EVAL-009, R-01 | M1 |
| REQ-EVAL-010 | T-EVAL-010 | M1 |
| REQ-EVAL-011 | T-EVAL-011 | M6 |
| REQ-COST-001 | T-COST-001 | M1, M3 |
| REQ-COST-002 | T-COST-002 | M3 |
| REQ-COST-003 | T-COST-003 | M3 |
| REQ-COST-004 | T-COST-004 | M3 |
| REQ-REPRO-001 | T-REPRO-001 | M1 |
| REQ-REPRO-002 | T-REPRO-002 | M1 |
| REQ-REPRO-003 | T-REPRO-003 | M1 |
| REQ-REPRO-004 | T-PIPE-007 | M1 |
| REQ-SEC-001 | T-SEC-001 | M3 |
| REQ-SEC-002 | T-SEC-002 | M3, M4 |
| REQ-DOC-001 | T-DOC-001 | spec |
| REQ-DOC-002 | T-DOC-002 | spec |
| REQ-API-001 | T-API-001 | M11 |
| REQ-API-002 | T-API-002 | M11, M12 |
| REQ-API-003 | T-API-003 | M11 |
| REQ-UI-001 | T-UI-001 | M11 |
| REQ-REPAIR-001 | T-REPAIR-001 | M12 |
| REQ-REPAIR-002 | T-REPAIR-002 | M12 |

---

## 18. Decision log

Status of every entry: `ACCEPTED` (default in force) unless marked otherwise.

| ID | Decision | Alternatives considered | Chosen default and reason | Reconsider when |
|---|---|---|---|---|
| D-001 | Process shape | Microservices; agent framework; modular monolith | Single Python package, one process per run: simplest, reproducible, matches plan Section 9 | A Stage C requirement needs concurrent multi-user writes |
| D-002 | Store | PostgreSQL; graph DB; DuckDB; SQLite | SQLite with append-only triggers and CAS pointers; dependency edges as tables | Archive beyond about 10^7 rows or concurrent writers needed |
| D-003 | Identifiers | UUIDs; ULIDs; readable composite ids | Readable deterministic composite ids for content, hashed tuples for operational records: deterministic replay and readable fixtures | External sources lack stable revision ids |
| D-004 | Offsets and normalization | UTF-8 byte offsets; UTF-16; grapheme clusters | NFC canonical text, code-point offsets, original bytes kept by hash | Dataset with heavy combining characters breaks span annotation UX |
| D-005 | Passage unit | Fixed token windows; sentences; paragraphs | Paragraphs capped at 1200 code points, token-level diffs inside: stable boundaries for markdown-like docs | Natural data has very long unstructured paragraphs |
| D-006 | Alignment | Hungarian matching; embedding similarity; greedy Dice | Greedy over multiset Dice with thresholds 0.50 / 0.70 / margin 0.05 plus expansion on uncertainty: deterministic, cheap, conservative | Pilot shows many paraphrases scored below 0.50 causing excessive expansion |
| D-007 | Where precedence lives | Let the verifier decide; deterministic code | Deterministic `resolve_claim_status` shared by all verifiers: comparability and auditability | Policy needs nuance verifiers handle better (measured on annotated conflicts) |
| D-008 | Evidence citations from verifiers | Offsets; passage ids only; quotes | Exact quotes located by code: models are unreliable at offsets | Quote rejection rate above 10% on pilot |
| D-009 | Status vs workflow | Single combined status | Separate enums plus derived availability | none expected |
| D-010 | Aggregation precedence | Majority; weakest-link with insufficiency first | CONTRADICTED > UNRESOLVED_CONFLICT > INSUFFICIENT_SUPPORT > SUPPORTED | Annotators disagree with the rule on mixed answers |
| D-011 | Unselected answers | Treat as re-verified; expire after TTL | Carry forward with explicit basis; TTL only as baseline B7 | Product requirement for maximum verdict age |
| D-012 | Stage A claims | LLM decomposition from day one | Sentences plus fixture overrides; decomposition in M5 | n/a |
| D-013 | Lexical retrieval | SQLite FTS5; Elasticsearch; rank-bm25; in-house | In-house BM25: exact control of tokenization and tie-breaks | Corpus too large for in-memory index |
| D-014 | Dense index | FAISS; ANN libraries; NumPy exact | NumPy exact cosine | More than about 10^6 vectors or latency issues |
| D-015 | Transition model family | LLM with PEFT first; encoder first | Encoder cross-encoder first; PEFT only if pilot shows scope or multi-passage reasoning dominates errors | U-023 resolves in favour |
| D-016 | Routing | Learned deferral; RL scheduling; transparent score | Transparent score policy over calibrated probabilities | Learned deferral ablation clearly better on validation |
| D-017 | Calibration and guarantees | Conformal prediction; temperature scaling | Temperature scaling, empirical thresholds, no guarantee claimed | A valid proof under stated assumptions becomes available |
| D-018 | CI method | Per-claim bootstrap; analytic | Cluster bootstrap by group | n/a |
| D-019 | Gold separation | Same DB with flags | Separate store and import ban | n/a |
| D-020 | LLM pre-labels | Allowed everywhere (plan) | Allowed for train/validation only; test R1/R2 blind | Annotation budget makes blind test labelling infeasible (then reduce test size, not blindness) |
| D-021 | Out-of-order deliveries | Reorder buffer; apply as current; per-document parking | Park the whole delivery in Stage A; backfill as known-but-not-latest versions in Stage B | Sources deliver out of order frequently |
| D-022 | Race handling | Locks during verification; abort stale jobs | Store every verdict as history; CAS on active job for current state | n/a |
| D-023 | Experiment time | Wall clock | Logical clock from deliveries | Live serving demo (Stage C) |
| D-024 | Hosted model determinism | Assume temperature 0 determinism | Record/replay; no determinism claims for live calls | n/a |
| D-025 | Dependency management | pip-tools; poetry; uv | `uv` with committed `uv.lock` if available in the dev environment; fallback `pip-tools` with `requirements.lock` (tool availability unverified, U-011) | Tool unavailable in CI image |
| D-026 | Support group size | Unbounded; 3 | Max 2 by default, 3 optional, max 4 groups | Annotated data shows frequent 3-way joint support |
| D-027 | Workflow states | Plan's four states | Six states incl. `IN_PROGRESS`, `FAILED` | n/a |
| D-028 | Primary track | All answers | Answers gold-`SUPPORTED` before the update; mixed track secondary | n/a |
| D-029 | First natural dataset | DynaQuest; FRUIT; HoH | HoH first (verified access, timestamps, current vs outdated evidence), DynaQuest second | U-003 license review blocks use, or audit finds too few usable cases |
| D-030 | Store per run | Shared store across runs | Fresh `serving.db` per method run (see D-033) | n/a |
| D-031 | Near-duplicate handling | Drop all members; keep all | Assign cluster to earliest-cutoff split, remove from later splits | n/a |
| D-033 | Method-run isolation (review item 2) | One store per experiment with a method column; shared state | One method run per (method, seed) with its own store and operational ids; immutable inputs shared by content hash | Store size or ingest time per method run becomes prohibitive (then share immutable corpus tables read-only through SQLite `ATTACH`) |
| D-034 | Applicability by effective version (review item 3) | Evidence from the snapshot's latest versions | `eff_k(d, t)` over all known versions | n/a |
| D-035 | Document-level effective dates first | Passage-level dates from the start | Document-level; mixed-date documents excluded and counted until M9 | M0 or M4 shows many mixed-date documents (U-024) |
| D-036 | Required judgment coverage (review item 4) | Accept partial verifier outputs | Explicit stance for every applicable item and group; retry on gaps; per-member citations | Coverage cost too high for large bundles (measured in M3, U-026) |
| D-037 | Partition rather than truncate must-keep evidence (review item 5) | Truncate; escalate the same bundle | Up to 4 partitions, then withhold with `EVIDENCE_OVERFLOW` | Partition cap frequently reached |
| D-038 | Two-phase ingest and whole-delivery parking (review item 6) | Per-document application inside the loop | Validate everything, then apply atomically; explicit redelivery table | Sources batch unrelated documents so parking delays too much (then split deliveries upstream) |
| D-039 | Canonical determinism digest (review item 10) | Hash all output files | Hash canonical logical records only | n/a |
| D-040 | Canonical bundles for selector isolation; B10 baseline (review item 8) | Selector-informed bundles only; separate citation-only and similarity-only baselines | Canonical bundles for isolation, selector-informed only end to end; B10 as the strong simple baseline | n/a |
| D-041 | Set-based formulas in code blocks; export validation (review item 7) | Formulas inside tables | Code blocks plus a cell-by-cell round-trip check of the DOCX | n/a |
| D-042 | Feasibility first (review item 11) | Main data gate at M4 after infrastructure | M0 audit with gate G-0 before the full M1 build | n/a |
| D-043 | Frozen evidence state for canonical bundles (second review item 3) | Read each method's current support groups | Answer-time state computed once per experiment, hashed into the bundle id; refresh only in end-to-end runs; cache verified by rebuild in CI | n/a |
| D-044 | Effective-timeline diff (item 4) | Text diff only | Text diff for lineage plus a timeline diff for applicability changes | n/a |
| D-045 | Supersession-only cancellation (item 4) | Explicit withdrawal events | Greatest effective date with sequence tie-break; withdrawal without replacement unsupported and counted | Sources issue withdrawals often (counted in M0 and M4) |
| D-046 | Deterministic packing with home partitions (item 6) | Union of all partition judgments | Next-fit packing of merged units, one home partition per entry, anchors as context only | M3 shows partitioning harms accuracy materially (U-027) |
| D-047 | Predeclared two-track M0 (item 5) | Fixed numeric gate decided after M0 | Hashed protocol, targeted and unconditioned tracks, two human labels before and after, agreement as a review trigger, B10 error and cost analysis | n/a |
| D-048 | Example integrity separated from algorithm reproduction (item 2) | Exact equality with a hand-built bundle | Exact tests on computed records; illustrative bundle excluded; gathering tested by rules | A reference implementation of the gatherer exists and is accepted as the oracle |
| D-049 | Mandatory audits with negative tests (item 1) | Report-only audits | Any FAIL exits non-zero; one injected fault per category; text-content checks exact | n/a |
| D-032 | Withhold while queued | Serve last status while re-checking | `withhold_while_queued = true` in experiments (conservative, counted in availability) | Serving demo prefers stale-while-revalidate (then report both) |

---

## 19. Assumption and uncertainty register

Type: EXT = unverified external fact; ASM = assumption; EVG = EVIDENCE-GATED decision; HYP = linked to a hypothesis.

| ID | Type | Item | Impact if wrong | Verification task | Fallback | Due |
|---|---|---|---|---|---|---|
| U-001 | EXT | VitaminC exact field names and label strings | Adapter bugs | Download `tals/vitaminc`, record schema and counts in `data/vitaminc/manifest.json` | Use GitHub jsonlines files | M4 |
| U-002 | EXT | FRUIT-WIKI download path, file format and data license | Cannot use for repair evaluation | Open `google-research/language` repo `language/fruit` manually, record license and files | Skip FRUIT | M4 |
| U-003 | EXT | HoH dataset license (Apache-2.0 tag) vs CC BY-SA Wikipedia text | Redistribution of derived benchmark | License review; keep derived data private until resolved | Release only scripts and ids | M4 |
| U-004 | EXT | DynaQuest file schema and Google Drive access | Second natural track delayed | Download, record schema | HoH only | M4 |
| U-005 | EXT | Completeness of GaRAGe enterprise passages in JSONL | Citation stress test scope | Inspect file | Use web passages only | M4 |
| U-006 | EXT | PACMI code/data availability | B8 can only be an adaptation | Check arXiv 2610.05732 latest version and author pages | Adaptation from paper description | M10 |
| U-007 | EXT | FinCacheServe code availability | B9 adaptation only | Check arXiv 2607.26076 and links | Adaptation | M10 |
| U-008 | HYP | Natural data contains enough selective-update cases (H-2) | Main study narrowed | Pilot statistics at gate G-A | Diagnostic benchmark paper | M4 |
| U-009 | ASM | Hosted LLMs remain available and stable during the study | Re-runs differ | Record/replay; pin model ids with dates | Local open model as strong verifier | M3 |
| U-010 | EXT | Choice and license of NLI model, embedding model and strong LLM (`PLACEHOLDER_STRONG_MODEL`) | Cannot run M3/M6 | Shortlist, check model cards and licenses, pin revisions in `configs/verifiers/` | Smaller open models | M3 |
| U-011 | EXT | Python version, package versions, `uv` availability | Install failures | Resolve and lock in M1 | pip-tools | M1 |
| U-012 | ASM | LLM parametric knowledge of post-update facts contaminates verification of natural Wikipedia data | Inflated B6 scores | Compare natural vs fictional/synthetic tracks; record model cutoffs | Emphasize fixture-like and software-doc tracks | M10 |
| U-013 | ASM | Claim independence in `p_answer_supported` | Mis-routed multi-claim answers | Compare against per-answer calibration on validation | Route multi-claim answers by min claim probability | M8 |
| U-014 | EVG | Accuracy of effective-date extraction from text | Wrong scheduling | Annotate dates on pilot | Metadata-only dates, conservative recheck | M9 |
| U-015 | ASM | Annotation capacity for plan targets (pilot about 1,000 judgments; main 5,000 plus 500 double-annotated) | Underpowered study | Measure throughput in pilot | Smaller main study, wider CIs, stated limits | M4 |
| U-016 | ASM | One modest GPU available | Training slower | Confirm hardware | Smaller backbone; hosted fine-tuning | M7 |
| U-017 | ASM | `sentences-v1` adequate on real documents | Bad passage splits and claim fallbacks | Measure on pilot | Replace with a library splitter (decision entry) | M4 |
| U-018 | EXT | Retrieval of specific Wikipedia revisions for HoH pages via Wikimedia APIs, and their terms of use | Sentence-only documents | Check API terms; list revisions explicitly (no crawling) | Sentence-level documents | M4 |
| U-019 | EXT | CacheSense and OntoCacheRAG (unverified leads in the plan) | Novelty positioning | Locate primary texts before any paper submission | Omit | M10 |
| U-020 | ASM | Fixture scenarios reflect natural phenomena | Overfitting design to fixtures | Compare error categories on pilot | Add natural regression cases to acceptance suite | M4 |
| U-021 | EVG | Value of the reranker | Wasted compute | Candidate recall at fixed count with and without | Keep off | M6 |
| U-022 | EXT | StreamingQA access and license | none critical | Check official release | Skip | M13 |
| U-024 | EVG | Share of natural documents with mixed effective dates | Smaller temporal track | Measure in M0 and M4 | Passage-level overrides (M9) | M4 |
| U-025 | EVG | M0 decision answers (G-0) | Wrong scope decision | Protocol fixed and hashed before results; answers logged by the project lead | Diagnostic benchmark scope | M0 |
| U-026 | ASM | Token cost of full judgment coverage | Higher verification cost | Measure in M3 | Per-claim calls | M3 |
| U-027 | EVG | Effect of partitioning on verifier accuracy | Lower accuracy on large bundles | M3 comparison of forced partitioning vs one call | Larger-context verifier; smaller bundles | M3 |
| U-028 | EXT | Access to an unconditioned update stream (Wikipedia revision API terms, public documentation repositories) | No prevalence estimate in M0 | Check access and terms when writing the M0 protocol | Report prevalence as unknown | M0 |
| U-023 | EVG | Need for an instruction model with PEFT | Model choice | Pilot error analysis by category | Encoder only | M7 |

---

## 20. Intentionally removed

The coding-agent handoff checklist that appeared here in v1.0.0 is maintained separately, so this document stays a reference. Section numbers are stable: later sections keep their numbers.

---

## 21. Consistency audit

Checks performed on this document after assembly (by script where marked):

| Check | Method | Result |
|---|---|---|
| Every schema referenced elsewhere is defined in 6.5 | Script: record types used in examples and text vs 6.5 headings | {{AUDIT_SCHEMAS}} |
| Semantic status names agree across sections | Script: every upper-case status-like token is one of the four statuses or a declared enum value | {{AUDIT_STATUSES}} |
| Workflow state names agree | Script: same check for the six states | {{AUDIT_WORKFLOW}} |
| Example IDs and references match | Script: every id referenced inside the 6.6 JSON is defined in it or in 14.1 (fixture) | {{AUDIT_IDS}} |
| Requirement IDs in traceability equal requirement IDs defined | Script | {{AUDIT_REQS}} |
| Test IDs used in traceability are in the test catalog | Script | {{AUDIT_TESTS}} |
| Decision and uncertainty IDs referenced are defined | Script | {{AUDIT_DU}} |
| JSON blocks parse | Script | {{AUDIT_JSON}} |
| Table rows have the header's cell count in the Markdown source | Script: unescaped pipes per row | {{AUDIT_PIPES}} |
| Exported DOCX text content matches the source | Script T-DOC-001: each raw cell parsed alone equals its table cell exactly; DOCX tables equal in shape and exact cell text; code blocks byte-identical and in order. Visual layout is not covered and is checked by rendering pages | {{AUDIT_DOCX}} |
| No raw HTML in the source (pandoc would drop it from the DOCX) | Script over the parsed Markdown | {{AUDIT_RAWHTML}} |
| Worked example integrity | Script: offsets, hashes, linkage and coverage of the computed records (the illustrative bundle is excluded, 6.6) | {{AUDIT_EXAMPLE}} |
| No em, en or double dashes in prose | Script | {{AUDIT_STYLE}} |
| Build fails on any failed audit | `build_spec.py` exits non-zero on any FAIL; `tests/test_build_audits.py` injects one fault per audit category and requires a non-zero exit (T-DOC-002) | Verified by the negative test suite, run separately |
| Every operational identity tuple carries the method-run id | Script over the 6.3 table, and over the records of the 6.6 example | {{AUDIT_MRUN}} |
| Temporal rules consistent | Manual: 5.1 (`latest_k`, `eff_k`), 5.7 (scopes, derived intervals, future-effective), 8.4.3 (backfill), 8.7 (scheduled rechecks), 9.5 (applicability), AS-07, AS-08, AS-09, AS-19 all resolve applicability through `eff_k` | Consistent |
| Baselines receive comparable information | Manual: 11.1 and 11.3 fix the verifier and use canonical bundles for selector isolation, and fix bundles for verifier comparisons; B2, B3 and B10 are restricted to recorded citations by definition and labelled as such | Consistent |
| Evaluation labels cannot leak into inference | Manual: gold store separation (6.4), import ban (7.4), `LeakageError` (10.6), blind test annotation (10.4), oracle condition labelled (13.6) | Consistent |
| Unchecked answers are never silently labelled verified | Manual: 5.2, 5.3, 5.9, 5.10, 8.10, 8.11 (coverage and overflow paths), INV-1 to INV-3 | Consistent |
| Research targets not described as achieved | Manual plus script search for "achieved", "guarantee", "we show" | {{AUDIT_LANG}} |
| No placeholder ids presented as real models | Manual: only `PLACEHOLDER_STRONG_MODEL`, flagged in 6.6 and U-010 | Consistent |

---

## 22. External verification record

Checked on 2026-11-01 with web search and direct fetches of official pages. "Verified" means seen on the official source on that date; it does not guarantee future availability. These sources were not re-checked for v1.1.0, which changes no external claim.

| Resource | Source checked | Finding | Status |
|---|---|---|---|
| VitaminC | Hugging Face `tals/vitaminc` card; GitHub `TalSchuster/VitaminC` README; BIG-bench task page | License `cc-by-sa-3.0`; more than 450,000 claim-evidence pairs from over 100,000 revisions plus synthetic; jsonlines; real and synthetic test sets | Verified (fields unverified) |
| FRUIT-WIKI | arXiv 2112.08634 (paper text); ACL Anthology 2022.naacl-main.269 | Over 170K silver pairs; 914 gold evaluation instances; data and code stated to be at `google-research/language/tree/master/language/fruit` | Paper verified; repository page not fetchable (robots); data license unverified |
| HoH | ACL Anthology (ACL 2025 long paper); GitHub `0russwest0/HoH` (Apache-2.0); Hugging Face `russwest404/HoH-QAs` dataset viewer | About 112k rows, one train split, fields listed in 10.1, license tag apache-2.0, README empty | Verified |
| DynaQuest | ACL Anthology 2025.findings-acl.1380; GitHub `nusnlp/DynaQuest` README | Data on Google Drive; CC BY-SA 4.0; based on Wikipedia infobox changes | Verified (fields unverified) |
| GaRAGe | GitHub `amazon-science/GaRAGe` README; arXiv 2506.07671 | 2,366 questions, over 35K annotated passages, fields listed in 10.1, CC-BY-NC-4.0 | Verified |
| PACMI | arXiv 2610.05732 (search result) | Paper exists; method summary consistent with plan | Paper located; release status unverified |
| FinCacheServe | arXiv 2607.26076 (search result) | Paper exists (cs.IR, July 2026) | Paper located; code unverified |
| Python packages, models | none checked | Not verified; resolved at M1 (U-011) and M3 (U-010) | Unverified |
