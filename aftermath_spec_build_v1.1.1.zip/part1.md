# AFTERMATH Implementation Specification

| Field | Value |
|---|---|
| Document | `AFTERMATH_IMPLEMENTATION_SPEC.md` |
| Spec version | 1.1.1 |
| Date | 2026-11-01 |
| Status | Canonical reference for implementation. No code exists yet. v1.1.0 addressed the first design review (0.2); v1.1.1 is a focused correction after the second review (0.3). M0 may proceed under its predeclared protocol; M1's exact-output contract is defined in 15 (M1). |
| Source of intent | "AFTERMATH: When Sources Change, Which Answers Must Change?" research proposal v1.0 (1 November 2026), referred to here as **the plan** |
| Repository state | No repository was available when this spec was written. Every file path below is a **proposed** layout, not a description of existing files. |

## 0. How to read this document

- Requirement keywords follow RFC 2119 usage: **MUST** / **MUST NOT** are binding, **SHOULD** is the default that may be departed from only with a decision-log entry, **MAY** is optional.
- Requirements carry stable IDs (`REQ-<AREA>-<NNN>`). IDs are never reused or renumbered. A retired requirement keeps its ID with status `RETIRED`.
- Decisions carry IDs `D-NNN` (Section 18). Assumptions and uncertainties carry IDs `U-NNN` (Section 19). Hypotheses carry IDs `H-N`. Acceptance scenarios carry IDs `AS-NN`. Tests carry IDs `T-<AREA>-<NNN>`.
- Every command in this document is **planned**: none has been implemented or run. Commands become "verified" only after a milestone's completion criteria pass.
- Every number described as a target, threshold, or budget is a **proposed default** unless attributed to a verified source. Nothing in this document reports an experimental result.
- Field tables use `req` for required and `opt` for optional (nullable).

### 0.1 Contents

1. Project summary
2. Classification of inputs and resolved ambiguities
3. Scope, stages and exclusions
4. Glossary
5. Formal task and semantic contract
6. Data model and schemas
7. Architecture, module boundaries and component contracts
8. Update-processing algorithm
9. Evidence and candidate-selection design
10. Dataset and annotation contracts
11. Baselines and fair comparisons
12. Training plan
13. Evaluation and cost accounting
14. Acceptance scenarios
15. Implementation milestones
16. Requirements
17. Requirements-to-tests traceability
18. Decision log
19. Assumption and uncertainty register
20. Intentionally removed (the coding-agent handoff is maintained separately)
21. Consistency audit
22. External verification record

### 0.2 Changes in 1.1.0

v1.1.0 responds to a design review that approved the foundations (semantic and workflow separation, shared authority resolution, snapshot-bound commits, blind test annotation, gold separation, replay-only determinism, the model-removal gate, M1 scope control) and requested the changes below. Each row names where the change lives.

| Review item | Change | Where |
|---|---|---|
| Methods collide in storage identity | Experiment and method-run identities; one store and one set of operational records per method run | 6.3, 6.4, 6.5 (ExperimentRun, MethodRun), 13.8, REQ-REPRO-004, T-PIPE-007, D-033 |
| Future-effective revisions hide evidence still in force | Applicability resolved by the effective version `eff_k(d, t)` over all known versions, not by the latest observed version; mixed-date documents excluded until passage-level applicability; only discovered candidates are scheduled and misses are measured | 5.1, 5.7, 8.7, 9.5, 13.2, REQ-SEM-013, REQ-SEM-015, REQ-SEM-016, AS-08, D-034, D-035 |
| Verifier can omit conflicting evidence | Required judgment coverage over every applicable item and group, per-member citations for joint evidence, `INCOMPLETE_COVERAGE` retried then failed | 6.5 (VerificationResult), 9.8, REQ-VER-007, REQ-VER-008, AS-21, D-036 |
| Trimming can drop decisive evidence | Must-keep roles, truncation recorded by role, partitioning instead of truncation, overflow withheld, cheap acceptance blocked | 6.5 (EvidenceBundle), 8.10, 8.11, 9.5, 12.2, REQ-EVID-002, REQ-EVID-007, AS-22, D-037 |
| Ingest partial application and retry gaps | Validate the whole delivery before any write; apply in one transaction with no early return; redelivery table per prior status; new revisions with unchanged text are recorded; authority changes detected | 8.1, 8.4.3, 8.13, REQ-ING-003, REQ-ING-007..009, AS-19, AS-23, D-038 |
| DOCX tables corrupted by pipe characters | Pipes escaped in table cells, set-based formulas moved to code blocks, export validated cell by cell against the source; Section 20 kept as a numbered placeholder | 13.1, 13.2, 21, REQ-DOC-001, T-DOC-001, D-041 |
| Selectors can give the verifier different evidence | `CANONICAL` bundles for selector isolation, `SELECTOR_INFORMED` only in end-to-end experiments; new B10 provenance-plus-similarity baseline | 9.5, 11.1, 11.2, 11.3, REQ-BASE-011, REQ-BASE-012, D-040 |
| "Detection recall" rewards procedural withholding | Three separate recalls (candidate, protective withholding, correct transition); audit reported as verifier-detected change rate unless human-labelled | 9.7, 13.2, REQ-EVAL-002, REQ-EVAL-010, REQ-EVAL-011 |
| M1 temporal scope conflict; weak determinism and race testing | Minimal fixed-time applicability in M1; determinism digest over canonical logical records; enumerated interleaving tests at named barrier points | 13.8, 15 (M1, M2), REQ-REPRO-003, REQ-PIPE-007, T-PIPE-008, D-039 |
| Feasibility gate too late; M1 too large | New M0 natural-data feasibility audit with gate G-0; M1 implements only the records the slice needs | 15 (M0, M1), REQ-SCOPE-004, U-025, D-042 |

### 0.3 Changes in 1.1.1

The second review ran the v1.1.0 build independently, confirmed its counts, kept the v1.1.0 changes, and asked for six corrections before M1.

| Review item | Change | Where |
|---|---|---|
| An audit could print FAIL and still exit 0 | Every audit is mandatory: any FAIL exits non-zero. A negative test injects one fault per audit category and requires a non-zero exit. Export checks are now exact: each raw Markdown cell must parse to the same text as its table cell, code blocks must match byte for byte and in order, and raw HTML is rejected. The audit claims text-content fidelity only; visual layout is checked by rendering | 21, REQ-DOC-001, REQ-DOC-002, T-DOC-001, T-DOC-002, D-049 |
| The worked example's bundle was assembled by hand | 6.6 separates computed integrity records (exact M1 test) from the illustrative bundle (not compared). Evidence gathering is tested against its rules (T-EVID-009). The illustrative bundle now follows the stated retrieval rules on the fixture | 6.6, 15 (M1), T-TEXT-003, T-EVID-009, D-048 |
| Canonical bundles could depend on which method ran first | Canonical bundles are built from a frozen, method-independent evidence state whose hash is part of the bundle id; support refresh happens only in end-to-end runs; an order-reversal test is required | 6.3, 6.5 (EvidenceBundle), 9.5, 9.6, 11.1, REQ-BASE-013, T-BASE-013, D-043 |
| Effective-date-only revisions escaped change detection | An effective-timeline diff emits `ApplicabilityChange` records and change spans whenever what is in force changes, even with unchanged text. Supersession and cancellation semantics are stated explicitly | 5.7, 6.5 (ApplicabilityChange, ChangeSpan), 8.1, 8.3a, AS-24, REQ-UPD-007, REQ-SEM-017, D-044, D-045 |
| G-0 thresholds were methodologically weak | M0 has a predeclared, hashed protocol, two sampling tracks reported separately, two human labels before and after the update, agreement as a review trigger rather than a pivot rule, and an error and cost analysis of B10 across operating points | 15 (M0), REQ-SCOPE-004, REQ-SCOPE-005, U-025, U-028, D-047 |
| Partitioning claimed too much | Deterministic packing with overlapping groups merged, a single home partition per required entry, and repeated context-only anchors. The claim is narrowed to preserving required coverage, not reasoning quality, which M3 measures | 9.5 step 9, 9.8, REQ-EVID-008, T-EVID-010, U-027, D-046 |

---

## 1. Project summary

AFTERMATH studies **selective semantic revalidation**: after a source document in a bounded, versioned corpus changes, which previously stored, evidence-grounded answers must be reconsidered, and what is their support status now?

Inputs: a versioned document corpus; an archive of questions and previously generated answers; recorded citations that may be incomplete or wrong; an update that adds, modifies or deletes source content.

Outputs per update: a candidate set of possibly affected answers (with reasons), a per-answer workflow outcome, a semantic support verdict for every answer that was actually assessed (with evidence spans and the snapshot it is valid for), an audit trail, and a cost report.

The research question (from the plan) is whether selective checking reduces **total** checking cost relative to exhaustive revalidation **at comparable reliability and answer availability**. This is a hypothesis to be tested, not a claim.

AFTERMATH is not a chatbot and makes no claim to answer questions better than a general model. A strong external LLM may be used as a verifier or as a baseline. Any advantage over a simple LLM pipeline must be shown experimentally (H-3).

The central scientific distinction, kept everywhere in this spec: **dependency freshness is not semantic support.** A changed dependency is a reason to investigate. An unchanged dependency is not evidence of continued support.

---

## 2. Classification of inputs and resolved ambiguities

### 2.1 Classification

| Class | Meaning | Where recorded |
|---|---|---|
| Established project requirement | Stated as intent by the plan or the task brief and adopted here | Section 16 (`REQ-*`) |
| Proposed engineering default | A choice made by this spec to make implementation concrete | Section 18 (`D-*`), marked "default" |
| Research hypothesis | A claim the project tries to support or refute | Section 2.3 (`H-*`) |
| Unverified external fact | Anything about a third-party dataset, paper, model or package that was not confirmed from an official source on 2026-11-01 | Section 19 (`U-*`), Section 22 |
| Decision requiring experimental evidence | A choice deferred until a pilot or ablation decides it | Section 19, flagged `EVIDENCE-GATED` |

### 2.2 Ambiguities in the plan and how this spec resolves them

| ID | Ambiguity in the plan | Resolution |
|---|---|---|
| A-01 | Workflow status listed as "unassessed, queued, reviewed, withheld"; the brief asks for unassessed, queued, completed, failed, withheld. | `WorkflowState = {UNASSESSED, QUEUED, IN_PROGRESS, COMPLETED, FAILED, WITHHELD}`. "Reviewed" in the plan maps to `COMPLETED` plus a `ReviewAnnotation`. `IN_PROGRESS` is added because race handling needs it (D-027). |
| A-02 | "Pending/withheld" used loosely. | `QUEUED` = selected and awaiting work. `WITHHELD` = selected and deliberately not served because it was not resolved within budget or policy. "Pending" is not a state name. |
| A-03 | "Affected" can mean "status changed" or "needs checking". | Separated. *Affected* is a gold semantic label (status changed). *Selected* is a method decision. Section 5.4. |
| A-04 | Unsafe retention denominator not fixed. | Primary denominator = gold-unsupported current-use judgments. Archive-normalized rate reported alongside. Section 13.2. |
| A-05 | "Retain with updated evidence" path in the architecture diagram bypasses the strong verifier. | Allowed only for a calibrated transition-model verdict above threshold with no applicable higher-or-equal-tier contradiction candidate; the verdict records `assessor_tier = TRANSITION_MODEL`. Stage A has no such path. |
| A-06 | Plan wants the model to "predict whether strong verification is warranted" and also to keep status prediction and routing distinct. | The transition model outputs a calibrated status distribution only. Routing is a separate component that consumes it (D-016). A learned deferral head is an optional ablation. |
| A-07 | Plan lists a TTL baseline; the brief's initial baseline list does not. | TTL is baseline B7 in Stage B. |
| A-08 | Plan requires a reranker after hybrid retrieval. | Reranker interface is defined; default **off** until a pilot shows it improves candidate recall at fixed candidate count (EVIDENCE-GATED, U-021). |
| A-09 | Plan allows "LLMs may propose labels". | Allowed for train/validation pre-labelling only. Test-split first-round annotation is blind to all model output (D-020). |
| A-10 | Plan mentions PostgreSQL optional for demo. | Deferred. SQLite throughout Stages A and B. Postgres only if a Stage C requirement demands concurrent writers (D-002). |
| A-11 | Mixed-quality track: what is "affected" when the prior status was not SUPPORTED? | Affected = gold status changed, in either direction. Primary track only contains judgments whose gold prior status is SUPPORTED. |
| A-12 | Observed time vs effective time. | Bitemporal: `observed_at` (transaction time, when the system learned of a version) and `effective_from`/`effective_to` (valid time, when the content applies). Section 5.7. |
| A-13 | "95% recall at half the verifier work" target. | Recorded as an engineering go/no-go heuristic (H-1 gate) only. It is never a CI pass/fail criterion and never reported as achieved. |
| A-14 | Source precedence "fixed by the benchmark", newest text does not always win. | Explicit `SourcePolicy` with authority tiers; same-tier cross-document conflicts default to `UNRESOLVED_CONFLICT` (Section 5.8). |
| A-15 | "CandidateDecision", "VerificationRun", "ReviewLabel" in the plan vs schema names in the brief. | Brief names win: `CandidateSelection`, `VerificationRequest`/`VerificationResult`, `ReviewAnnotation`. |
| A-16 | Plan says to align "sections/sentences"; segmentation unit not fixed. | Passages are paragraphs (bounded length); diffs inside a passage are token-level; sentence boundaries are used for passage splitting and claim fallback (D-005). |

### 2.3 Research hypotheses

These are things to test. None is assumed true anywhere in the design.

| ID | Hypothesis | Evidence that would support it | Evidence that would refute or narrow it |
|---|---|---|---|
| H-1 | Two-path selection plus budgeted escalation reaches correct transition recall and unsafe retention comparable to exhaustive strong revalidation at materially lower total cost, including preprocessing. | Cost vs unsafe-retention curve dominates B1, B4 and B10 on held-out natural data with cluster-bootstrap CIs excluding zero difference. | Overlapping CIs, or advantage that disappears once indexing and claim-extraction cost are amortized realistically. |
| H-2 | The discovery path catches a non-trivial share of affected answers that have no citation edge to any changed passage. | Ablation "remove discovery" lowers candidate recall and correct transition recall on natural data. | Natural data has almost no such cases (then report it as a benchmark finding, plan Section 10). |
| H-3 | A paired old/new transition model beats independent NLI judgments and is cheaper than direct strong-LLM verification at comparable accuracy. | Claim-level macro-F1 and calibrated risk-coverage better than B5 and cost lower than B6 at similar quality. | If B6 wins cheaply, B6 becomes the system verifier and training claims are dropped (plan Section 10). |
| H-4 | Alternative support groups reduce unnecessary invalidation when one supporting source is removed. | Ablation "remove alternative support" raises unnecessary invalidation on redundancy cases. | No difference on natural data. |

---

## 3. Scope, stages and exclusions

### 3.1 Stage A: executable baseline (must run end to end first)

- A small natural-data feasibility audit (M0, gate G-0) before the slice grows beyond its core modules.
- Immutable document versions and corpus snapshots.
- Ingestion of existing questions, answers and recorded citations.
- Paragraph segmentation, passage alignment and change detection.
- Citation resolution to passages (dependency mapping).
- Baselines B1 (exhaustive), B2 (document-version invalidation), B3 (passage invalidation), B4 (lexical similarity selection), B10 (passage provenance plus similarity).
- Shared `Verifier` interface with a scripted test verifier (mock) and, by M3, real NLI and LLM adapters.
- Deterministic fixture-based tests, evaluation runner, cost report.

Stage A is complete when milestone M4's completion criteria pass. No custom model training (Section 12) and no UI work (Stage C) may begin before that (REQ-SCOPE-003).

### 3.2 Stage B: research method

- Provenance path (recorded plus inferred links) and discovery path (claim search) candidate retrieval.
- Claim decomposition, inferred evidence links, alternative support groups.
- Learned support-transition model with calibration.
- Full temporal scope handling (effective-date extraction, scheduled rechecks, out-of-order backfill).
- Budgeted verification escalation and routing policies.
- Baselines B5, B6, B7 and later adaptations B8, B9; controlled ablations.

### 3.3 Stage C: demonstration and extensions

- Thin FastAPI service and Next.js inspection interface.
- Optional minimal answer repair with independent checking and human approval.
- Larger update streams and additional domains (public versioned software documentation).

### 3.4 Exclusions

The following are **out of scope** unless a decision-log entry cites a demonstrated requirement (REQ-SCOPE-002):

- Multi-agent orchestration or agent frameworks.
- A graph database (dependency edges live in ordinary SQLite tables).
- Distributed services, message brokers, or job-queue servers (jobs are rows in SQLite processed by one process).
- Autonomous web crawling. Targeted download of specific, listed dataset files or specific listed revisions is a data-collection step and is allowed (U-018).
- Reinforcement learning, including learned scheduling. The router is a transparent scoring policy.
- Automatic publication of corrections to any external user (REQ-API-002).
- Any claim of truth beyond the bounded corpus under its declared policy.
- Formal, conformal or distribution-free reliability guarantees.

---

## 4. Glossary

| Term | Definition |
|---|---|
| Corpus | The bounded set of documents (`Document`) the system reasons over, identified by `corpus_id`. |
| Document | A stable logical source (a page, a file) identified by `document_id`. Has zero or more versions. |
| Document version | An immutable text of a document at one source revision (`DocumentVersion`). |
| Canonical text | The document version text after `canon-v1` normalization (Section 6.2). All offsets point into it. |
| Passage | A paragraph-sized unit of a document version (`PassageVersion`), with code-point offsets. |
| Lineage | The identity of "the same passage" across versions (`lineage_id`) and the edges connecting passage versions across an update (`PassageLineageEdge`). |
| Corpus snapshot | The set of current document versions after a given update (`CorpusSnapshot`), numbered by `snapshot_seq`. |
| Head | The latest committed snapshot. It records what has been observed, not what is in force. |
| Latest observed version | `latest_k(d)`: the version of a document with the greatest `source_seq` known at snapshot `k`. Used for change detection. |
| Effective version | `eff_k(d, t)`: the version of a document in force at time `t` given everything known at snapshot `k`. Used for evidence applicability. |
| Experiment | One execution of an experiment configuration (`ExperimentRun`), containing one method run per method and seed. |
| Method run | One method with one seed inside an experiment (`MethodRun`), with its own store and operational records. |
| Canonical bundle | An evidence bundle that depends only on the answer, update, target snapshot and gatherer configuration, never on which selector chose the answer. |
| Required coverage | The applicable evidence items and support groups that a verifier must judge explicitly for each claim. |
| Must-keep evidence | Evidence roles that may never be dropped silently: modified successors, new evidence, contradiction candidates, surviving support and members of partially kept groups. |
| Partition | One of several verification calls that together cover a bundle too large for one call. Each required entry has exactly one home partition. |
| Frozen evidence state | The method-independent support groups, citations and inferred links that canonical bundles are built from (9.5); its hash is part of the bundle id. |
| Applicability change | A change in which version of a document is in force over some time interval (`ApplicabilityChange`), detected by the effective-timeline diff even when no text changed. |
| Answer archive | All stored questions and answer versions. |
| Answer version | An immutable answer text (`AnswerVersion`). A repaired answer is a new version. |
| Claim | A unit of an answer that can be supported or contradicted (`Claim`). |
| Material claim | A claim whose truth is necessary for the answer to be correct and useful for its question (Section 5.5). |
| Citation | A source reference recorded with the answer (`Citation`). Not proof of support. |
| Evidence link | A system-inferred relation between a claim and a passage (`EvidenceLink`). |
| Support group | A set of passages that jointly support a claim; alternative groups each suffice (`SupportGroup`). |
| Update event | One delivered change to the corpus (`UpdateEvent`), producing one new snapshot. |
| Change span | A detected difference between two versions of a document (`ChangeSpan`). |
| Candidate | An answer version selected for assessment for a given update (`CandidateSelection`). |
| Evidence bundle | The passages handed to a verifier for one assessment, with roles and applicability. |
| Verifier | Any component that judges claims against evidence through the `Verifier` interface. |
| Strong verifier | The most capable and most expensive verifier in a configuration (default: a hosted LLM). |
| Transition model | The Stage B learned model predicting post-update claim status. |
| Router | The component deciding, per candidate, whether to accept a cheap verdict, escalate, or withhold. |
| Semantic status | One of `SUPPORTED`, `CONTRADICTED`, `INSUFFICIENT_SUPPORT`, `UNRESOLVED_CONFLICT`. |
| Workflow state | Processing state of an answer: `UNASSESSED`, `QUEUED`, `IN_PROGRESS`, `COMPLETED`, `FAILED`, `WITHHELD`. |
| Verdict | A committed semantic assessment of an answer version, valid for one snapshot (`AnswerVerdict`). |
| Verification basis | Why an answer's current status is believed: `VERIFIED_AT_SNAPSHOT`, `CARRIED_FORWARD`, or `NONE`. |
| Availability | Whether an answer may be served: `AVAILABLE` or `WITHHELD`. Derived, never set directly. |
| Source policy | Configuration of authority tiers and precedence rules (`SourcePolicy`). |
| Authority tier | Integer rank of a source type; **lower number = higher authority**. |
| Temporal scope | What time a question is about: `ROLLING_CURRENT`, `FIXED_TIME`, `FIXED_VERSION`. |
| Evaluation time | The world time at which a claim is evaluated (`t_eval`). |
| Effective time | The valid-time interval during which a passage's content applies. |
| Observed time | When the system received a version (transaction time). |
| Scheduled recheck | A deferred job created when future-effective content arrives (`ScheduledRecheck`). |
| Audit sample | A random sample of non-selected answers that are verified to estimate selection misses. |
| Gold | Human-adjudicated labels and evidence, stored separately and never visible to methods. |
| Track | Provenance class of an evaluation example: `NATURAL`, `SYNTHETIC_INTERVENTION`, `FIXTURE`. |
| Mock verifier | A verifier whose outputs are scripted or rule-based for software testing; `is_mock = true`. |
| Run | Informal; see Experiment and Method run. |
| Logical clock | Experiment time taken from fixture or dataset timestamps rather than the wall clock. |

---
