"""Generate the internally consistent fixture texts and JSON example for the AFTERMATH spec (v1.1.0).

Implements canon-v1, seg-v1, cjson-v1, the ID grammar, dice-v1 and the canonical bundle
contract so offsets, hashes and ids in the spec are computed, not typed.
"""
import hashlib, json, re, unicodedata, difflib
from collections import Counter

def canon(text: str) -> str:
    if text.startswith("﻿"):
        text = text[1:]
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return unicodedata.normalize("NFC", text)

def sha(s: str) -> str:
    return "sha256:" + hashlib.sha256(s.encode("utf-8")).hexdigest()

def cjson(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

def opid(prefix, tup):
    return prefix + "_" + hashlib.sha256(cjson(tup).encode("utf-8")).hexdigest()[:20]

def norm(s: str) -> str:
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", s).casefold()).strip()

def dice(a, b):
    A = Counter(re.findall(r"\w+", norm(a))); B = Counter(re.findall(r"\w+", norm(b)))
    return 2 * sum((A & B).values()) / (sum(A.values()) + sum(B.values()))

def segment(text):
    out, section, pos = [], [], 0
    para_start = para_end = None
    def flush():
        nonlocal para_start, para_end
        if para_start is not None:
            out.append((para_start, para_end, list(section)))
        para_start = para_end = None
    for line in text.split("\n"):
        start, end = pos, pos + len(line)
        pos = end + 1
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            flush()
            level = len(m.group(1))
            section = section[: level - 1] + [m.group(2).strip()]
        elif line.strip() == "":
            flush()
        else:
            if para_start is None:
                para_start = start
            para_end = end
    flush()
    return out

PLANS = {
 "r1": "# Plans\n\nBulk export is available to all paid plans.\n\nThe Starter plan costs 12 USD per month. The Pro plan costs 30 USD per month.\n\n# Limits\n\nEach workspace can store up to 50 GB of files.\n",
 "r2": "# Plans\n\nAll paid plans include bulk export.\n\nThe Starter plan costs 12 USD per month. The Pro plan costs 30 USD per month.\n\n# Limits\n\nEach workspace can store up to 50 GB of files.\n",
 "r3": "# Plans\n\nAll paid plans include bulk export.\n\nThe Starter plan costs 15 USD per month. The Pro plan costs 30 USD per month.\n\n# Limits\n\nEach workspace can store up to 50 GB of files.\n",
}
OTHER_DOCS = {
 "doc_export_guide": ("product_doc", "Export guide", "# Export guide\n\nBulk export creates a ZIP archive of all notes.\n\nPaid plans can run bulk export once per day.\n"),
 "doc_storage_faq": ("product_doc", "Storage FAQ", "# Storage FAQ\n\nEach workspace can store up to 50 GB of files, regardless of plan.\n"),
 "doc_security": ("product_doc", "Security", "# Security\n\nAll data is encrypted at rest with AES-256.\n"),
 "doc_release_notes": ("release_note", "Release notes", "# Release notes\n\nVersion 4.2 adds dark mode.\n"),
}

def pv_record(doc_id, rev, text, idx, first_rev="r1"):
    s, e, sec = segment(text)[idx]
    ptxt = text[s:e]
    return {
        "schema_version": "1.0", "record_type": "PassageVersion",
        "passage_version_id": f"pv:{doc_id}@{rev}#p{idx+1:04d}",
        "document_version_id": f"dv:{doc_id}@{rev}",
        "ordinal": idx + 1, "section_path": sec, "start": s, "end": e,
        "content_hash": sha(ptxt), "norm_hash": sha(norm(ptxt)),
        "lineage_id": f"lin:{doc_id}:{first_rev}:p{idx+1:04d}",
        "segmentation_version": "seg-v1", "effective_from_override": None,
    }, ptxt

EXPERIMENT_CFG = {"experiment": "m1_tiny_saas", "dataset_manifest": "fixtures/tiny_saas",
                  "methods": ["B1_exhaustive", "B2a_doc_invalidate", "B2b_doc_select_verify",
                              "B3a_passage_invalidate", "B3b_passage_select_verify",
                              "B4_similarity", "B10_prov_plus_sim"],
                  "seeds": [13], "evidence_mode": "CANONICAL"}
GATHERER_CFG = {"version": "evidence-v2", "max_items": 12, "max_chars": 6000, "k_ev": 8,
                "k_cs": 4, "k_cc": 3, "max_partitions": 4, "window": 1500}
GIT_SHA = "0000000"

def main():
    t1, t2, t3 = canon(PLANS["r1"]), canon(PLANS["r2"]), canon(PLANS["r3"])
    seg2, seg3 = segment(t2), segment(t3)
    s2, e2, _ = seg2[1]
    s3, e3, _ = seg3[1]
    old_p, new_p = t2[s2:e2], t3[s3:e3]
    tok = lambda s, base: [(m.group(0), base + m.start(), base + m.end()) for m in re.finditer(r"\S+", s)]
    ot, nt = tok(old_p, s2), tok(new_p, s3)
    sm = difflib.SequenceMatcher(a=[x[0] for x in ot], b=[x[0] for x in nt], autojunk=False)
    ops = [op for op in sm.get_opcodes() if op[0] != "equal"]
    assert len(ops) == 1
    _, i1, i2, j1, j2 = ops[0]
    old_span = (ot[i1][1], ot[i2 - 1][2])
    new_span = (nt[j1][1], nt[j2 - 1][2])
    assert t2[old_span[0]:old_span[1]] == "12" and t3[new_span[0]:new_span[1]] == "15"

    config_id = opid("xcfg", EXPERIMENT_CFG)
    experiment_id = opid("xexp", [config_id, GIT_SHA])
    method_id = "B3b_passage_select_verify"
    mrid = opid("mrun", [experiment_id, method_id, 13])
    mrun = {"schema_version": "1.0", "record_type": "MethodRun", "method_run_id": mrid,
            "experiment_id": experiment_id, "method_id": method_id, "seed": 13,
            "mode": "SELECT_VERIFY", "evidence_mode": "CANONICAL",
            "verifier_profile_hash": sha(cjson({"verifier": "strong-llm-v1", "prompt_version": "verify-v2",
                                                 "model_id": "PLACEHOLDER_STRONG_MODEL"})),
            "status": "SUCCEEDED",
            "store_path": f"runs/{experiment_id}/methods/{mrid}/serving.db",
            "corpus_snapshot_ids": ["snap:000001", "snap:000004"], "contains_mock_results": False}

    docs_r3 = {"doc_plans": "dv:doc_plans@r3"}
    docs_r3.update({d: f"dv:{d}@r1" for d in OTHER_DOCS})
    manifest = sorted(docs_r3.items())
    snap3 = {"schema_version": "1.0", "record_type": "CorpusSnapshot",
             "snapshot_id": "snap:000003", "snapshot_seq": 3, "corpus_id": "tiny_saas",
             "parent_snapshot_id": "snap:000002", "created_by_update_event_id": "upd:fx-0003",
             "manifest_hash": sha(cjson(manifest)), "document_count": len(manifest),
             "as_of": "2026-04-01T00:00:00.000Z"}
    payload = {"delivery_id": "fx-0003", "corpus_id": "tiny_saas", "documents": [
        {"document_id": "doc_plans", "source_revision_id": "r3", "source_seq": 3,
         "content_hash": sha(t3), "source_timestamp": "2026-04-01T00:00:00.000Z",
         "effective_from": None, "deleted": False}]}
    upd = {"schema_version": "1.0", "record_type": "UpdateEvent",
           "update_event_id": "upd:fx-0003", "delivery_id": "fx-0003", "corpus_id": "tiny_saas",
           "payload_hash": sha(cjson(payload)), "kind": "CONTENT_UPDATE", "status": "APPLIED",
           "received_at": "2026-04-01T00:00:00.000Z", "as_of": "2026-04-01T00:00:00.000Z",
           "base_snapshot_id": "snap:000002", "result_snapshot_id": "snap:000003",
           "document_version_ids": ["dv:doc_plans@r3"], "diff_version": "diff-v1", "error": None}
    dv3 = {"schema_version": "1.0", "record_type": "DocumentVersion",
           "document_version_id": "dv:doc_plans@r3", "document_id": "doc_plans",
           "source_revision_id": "r3", "source_seq": 3, "is_deletion": False,
           "text": t3, "char_length": len(t3), "content_hash": sha(t3), "source_bytes_hash": sha(PLANS["r3"]),
           "normalization_version": "canon-v1", "segmentation_version": "seg-v1",
           "source_timestamp": "2026-04-01T00:00:00.000Z", "observed_at": "2026-04-01T00:00:00.000Z",
           "effective_from": "2026-04-01T00:00:00.000Z", "effective_from_source": "DEFAULT_SOURCE_TIMESTAMP",
           "effective_to": None, "delivery_id": "fx-0003",
           "metadata": {"title": "Plans", "source_type": "product_doc"}}
    pv_old, _ = pv_record("doc_plans", "r2", t2, 1)
    pv_new, _ = pv_record("doc_plans", "r3", t3, 1)
    edge = {"schema_version": "1.0", "record_type": "PassageLineageEdge",
            "lineage_edge_id": "le:fx-0003:0002", "update_event_id": "upd:fx-0003",
            "from_passage_version_ids": [pv_old["passage_version_id"]],
            "to_passage_version_ids": [pv_new["passage_version_id"]],
            "relation": "MODIFIED", "alignment_score": round(dice(old_p, new_p), 4),
            "alignment_confidence": "HIGH", "alignment_method": "diff-v1/dice-v1"}
    cs = {"schema_version": "1.0", "record_type": "ChangeSpan",
          "change_span_id": "cs:fx-0003:0001", "update_event_id": "upd:fx-0003", "document_id": "doc_plans",
          "old_document_version_id": "dv:doc_plans@r2", "new_document_version_id": "dv:doc_plans@r3",
          "old_passage_version_id": pv_old["passage_version_id"], "new_passage_version_id": pv_new["passage_version_id"],
          "kind": "MODIFIED", "lineage_edge_id": edge["lineage_edge_id"],
          "old_start": old_span[0], "old_end": old_span[1], "new_start": new_span[0], "new_end": new_span[1],
          "old_text": t2[old_span[0]:old_span[1]], "new_text": t3[new_span[0]:new_span[1]],
          "features": {"numeric_change": True, "numbers_old": ["12"], "numbers_new": ["15"],
                       "date_change": False, "negation_change": False, "qualifier_change": False},
          "alignment_confidence": "HIGH", "effective_from": "2026-04-01T00:00:00.000Z"}

    q = {"schema_version": "1.0", "record_type": "Question", "question_id": "q_starter_price",
         "text": "How much does the Starter plan cost?",
         "scope": {"type": "ROLLING_CURRENT", "time": None, "document_version_id": None},
         "created_at": "2026-02-01T12:00:00.000Z", "origin": "FIXTURE"}
    ans_text = "The Starter plan costs 12 USD per month."
    av = {"schema_version": "1.0", "record_type": "AnswerVersion",
          "answer_version_id": "av:ans_starter_price@1", "answer_id": "ans_starter_price",
          "question_id": "q_starter_price", "version": 1, "text": ans_text, "content_hash": sha(ans_text),
          "answer_kind": "GROUNDED", "origin": "FIXTURE", "parent_answer_version_id": None,
          "answered_at": "2026-02-01T12:00:00.000Z", "generated_against_snapshot_id": "snap:000001",
          "generator": None}
    quote = "The Starter plan costs 12 USD per month."
    qpos = t1.index(quote)
    cit = {"schema_version": "1.0", "record_type": "Citation",
           "citation_id": "cit:ans_starter_price@1#01", "answer_version_id": av["answer_version_id"],
           "ordinal": 1, "document_id": "doc_plans", "document_version_id": "dv:doc_plans@r1",
           "passage_version_id": "pv:doc_plans@r1#p0002", "quote": quote,
           "start": qpos, "end": qpos + len(quote), "resolution": "QUOTE_EXACT", "origin": "RECORDED"}
    clm = {"schema_version": "1.0", "record_type": "Claim",
           "claim_id": "clm:ans_starter_price@1#c01", "answer_version_id": av["answer_version_id"],
           "ordinal": 1, "text": ans_text, "answer_start": 0, "answer_end": len(ans_text),
           "kind": "ATOMIC", "is_material": True, "materiality_source": "FIXTURE",
           "decomposition_method": "sentence-v1", "decomposition_confidence": 1.0,
           "scope_override": None, "created_by": None}
    sg = {"schema_version": "1.0", "record_type": "SupportGroup",
          "support_group_id": "sg:ans_starter_price@1#c01.g01", "claim_id": clm["claim_id"],
          "established_at_snapshot_id": "snap:000001", "origin": "CITATION_ASSUMED",
          "verified": False, "confidence": None,
          "members": [{"passage_version_id": "pv:doc_plans@r1#p0002", "lineage_id": "lin:doc_plans:r1:p0002",
                       "start": qpos, "end": qpos + len(quote)}],
          "created_by": {"component": "support-init", "config_hash": None, "model_id": None}}

    sel = {"schema_version": "1.0", "record_type": "CandidateSelection",
           "selection_id": opid("csel", [mrid, "upd:fx-0003", av["answer_version_id"]]),
           "method_run_id": mrid, "update_event_id": "upd:fx-0003",
           "answer_version_id": av["answer_version_id"], "selector_id": "passage_invalidation-v1",
           "rank": 1, "is_audit_sample": False,
           "reasons": [{"path": "PASSAGE_INDEX", "change_span_id": cs["change_span_id"],
                        "via": cit["citation_id"], "score": 1.0}],
           "temporal_exclusion": None}
    job_id = opid("job", [mrid, "upd:fx-0003", av["answer_version_id"], "snap:000003"])
    route = {"schema_version": "1.0", "record_type": "RoutingDecision",
             "routing_decision_id": opid("route", [mrid, "upd:fx-0003", av["answer_version_id"]]),
             "method_run_id": mrid, "update_event_id": "upd:fx-0003", "answer_version_id": av["answer_version_id"],
             "job_id": job_id, "policy_id": "verify_all_selected-v1", "action": "ESCALATE_STRONG",
             "priority_score": None, "prediction": None,
             "estimated_cost": {"model_calls": 1, "input_tokens": 900},
             "budget_before": {"model_calls": None}, "budget_after": {"model_calls": None}, "thresholds": None}

    # Illustrative canonical bundle (6.6). Retrieved items come from a BM25 sketch that follows 9.2 and 9.5
    # step 3 (tok-v1, k1 = 1.2, b = 0.75, positive scores only, claim query then question query, top k_ev).
    # The sketch is not the reference implementation; M1 does not compare bundles to this example.
    import math
    applicable = [("doc_plans", "r3", t3)] + [(d, "r1", canon(v[2])) for d, v in OTHER_DOCS.items()]
    corpus = []
    for d, rev, txt in applicable:
        for k in range(len(segment(txt))):
            rec, ptxt = pv_record(d, rev, txt, k)
            corpus.append((rec, ptxt, re.findall(r"\w+", norm(ptxt))))
    N = len(corpus); avgdl = sum(len(c[2]) for c in corpus) / N
    def bm25(query):
        q = re.findall(r"\w+", norm(query)); scores = []
        for rec, ptxt, toks in corpus:
            tf = Counter(toks); sc = 0.0
            for term in set(q):
                df = sum(1 for c in corpus if term in c[2])
                if tf[term] == 0: continue
                idf = math.log(1 + (N - df + 0.5) / (df + 0.5))
                sc += idf * tf[term] * 2.2 / (tf[term] + 1.2 * (0.25 + 0.75 * len(toks) / avgdl))
            if sc > 0: scores.append((round(sc, 6), rec["passage_version_id"], rec, ptxt))
        return sorted(scores, key=lambda x: (-x[0], x[1]))
    retrieved, seen = [], {pv_new["passage_version_id"]}
    for query in (ans_text, q["text"]):
        for sc, pid, rec, ptxt in bm25(query):
            if pid not in seen and len(retrieved) < GATHERER_CFG["k_ev"]:
                seen.add(pid); retrieved.append((rec, ptxt))
    items = [{"handle": "E1", "passage_version_id": pv_new["passage_version_id"], "role": "MODIFIED_SUCCESSOR",
              "applicable": True, "authority_tier": 2, "content_hash": pv_new["content_hash"], "group_ids": [], "window": None}]
    for rec, ptxt in retrieved:
        items.append({"handle": f"E{len(items)+1}", "passage_version_id": rec["passage_version_id"], "role": "RETRIEVED",
                      "applicable": True, "authority_tier": 2, "content_hash": rec["content_hash"], "group_ids": [], "window": None})
    items.append({"handle": f"E{len(items)+1}", "passage_version_id": pv_old["passage_version_id"], "role": "OLD_SUPPORT",
                  "applicable": False, "authority_tier": 2, "content_hash": pv_old["content_hash"], "group_ids": [], "window": None})
    retrieved_chars = sum(len(p) for _, p in retrieved)
    gatherer_hash = sha(cjson(GATHERER_CFG))
    evidence_state = {"version": "evstate-v1", "basis": "ANSWER_TIME_FROZEN",
                      "support_groups": [sg_ref for sg_ref in [ {"support_group_id": "sg:ans_starter_price@1#c01.g01",
                                          "members": ["pv:doc_plans@r1#p0002"]} ]],
                      "citations": [{"citation_id": "cit:ans_starter_price@1#01", "passage_version_id": "pv:doc_plans@r1#p0002"}],
                      "evidence_links": []}
    evidence_state_hash = sha(cjson(evidence_state))
    bundle = {"bundle_id": opid("bun", [av["answer_version_id"], "upd:fx-0003", "snap:000003", "CANONICAL",
                                        gatherer_hash, evidence_state_hash]),
              "evidence_mode": "CANONICAL", "gatherer_config_hash": gatherer_hash,
              "evidence_state_hash": evidence_state_hash, "items": items,
              "required_coverage": [{"claim_id": clm["claim_id"],
                                     "handles": [i["handle"] for i in items if i["applicable"]], "groups": []}],
              "bundle_hash": sha(cjson(items)), "dropped": [], "dropped_by_role": {},
              "incompleteness": "NONE", "char_count": len(new_p) + retrieved_chars + len(old_p)}
    vreq = {"schema_version": "1.0", "record_type": "VerificationRequest",
            "request_id": opid("vreq", [mrid, "upd:fx-0003", av["answer_version_id"], "strong-llm-v1", 0, 1]),
            "job_id": job_id, "method_run_id": mrid, "update_event_id": "upd:fx-0003",
            "answer_version_id": av["answer_version_id"], "claim_ids": [clm["claim_id"]],
            "target_snapshot_id": "snap:000003", "evaluation_time": "2026-04-01T00:00:00.000Z",
            "verifier_id": "strong-llm-v1", "verifier_tier": "STRONG",
            "model_id": "PLACEHOLDER_STRONG_MODEL", "prompt_version": "verify-v2",
            "params": {"temperature": 0, "max_output_tokens": 800, "timeout_s": 60},
            "evidence_bundle": bundle, "partition": {"index": 0, "count": 1},
            "attempt": 1, "replay_mode": "RECORD"}
    q2 = "The Starter plan costs 15 USD per month."
    q2pos = t3.index(q2)
    raw = cjson({"judgments": [
        {"claim_id": "C1", "evidence": ["E1"], "stance": "CONTRADICTS", "citations": [{"evidence": "E1", "quote": q2}]}]
        + [{"claim_id": "C1", "evidence": [i["handle"]], "stance": "NEUTRAL", "citations": []}
           for i in items if i["role"] == "RETRIEVED"],
        "claim_status": [{"claim_id": "C1", "status": "CONTRADICTED", "confidence": 0.97}]})
    vres = {"schema_version": "1.0", "record_type": "VerificationResult",
            "result_id": opid("vres", [vreq["request_id"]]), "request_id": vreq["request_id"],
            "status": "OK", "is_mock": False,
            "judgments": [
                {"claim_id": clm["claim_id"], "passage_version_ids": [pv_new["passage_version_id"]],
                 "stance": "CONTRADICTS",
                 "citations": [{"passage_version_id": pv_new["passage_version_id"], "quote": q2,
                                "start": q2pos, "end": q2pos + len(q2)}]},
                ] + [{"claim_id": clm["claim_id"], "passage_version_ids": [i["passage_version_id"]],
                      "stance": "NEUTRAL", "citations": []} for i in items if i["role"] == "RETRIEVED"],
            "coverage_complete": True, "missing_coverage": [],
            "verifier_claim_statuses": [{"claim_id": clm["claim_id"], "status": "CONTRADICTED", "confidence": 0.97}],
            "raw_response_hash": sha(raw), "parse_errors": [],
            "latency_ms": 2140, "input_tokens": 1104, "output_tokens": 156}
    verdict = {"schema_version": "1.0", "record_type": "AnswerVerdict",
               "verdict_id": opid("verdict", [job_id]), "job_id": job_id, "method_run_id": mrid,
               "answer_version_id": av["answer_version_id"], "update_event_id": "upd:fx-0003",
               "valid_for_snapshot_id": "snap:000003", "evaluation_time": "2026-04-01T00:00:00.000Z",
               "semantic_status": "CONTRADICTED",
               "claim_statuses": [{"claim_id": clm["claim_id"], "is_material": True, "semantic_status": "CONTRADICTED",
                                   "resolution": {"rule": "CONTRADICTION_ONLY", "best_support_tier": None,
                                                  "best_contradiction_tier": 2, "supporting_groups": [],
                                                  "contradicting_groups": [[pv_new["passage_version_id"]]]}}],
               "nonmaterial_issues": [], "assessor_tier": "STRONG_VERIFIER",
               "verification_result_ids": [vres["result_id"]], "source_policy_version": "sp-tiny-1",
               "evidence_incompleteness": "NONE",
               "reused_from_verdict_id": None, "committed_at_logical": "2026-04-01T00:00:00.000Z"}
    state = {"schema_version": "1.0", "record_type": "AnswerCurrentState",
             "method_run_id": mrid, "answer_version_id": av["answer_version_id"],
             "workflow_state": "COMPLETED", "semantic_status": "CONTRADICTED",
             "verdict_id": verdict["verdict_id"], "status_snapshot_id": "snap:000003",
             "as_of_snapshot_id": "snap:000003", "verification_basis": "VERIFIED_AT_SNAPSHOT",
             "availability": "WITHHELD", "active_job_id": None,
             "last_selected_update_event_id": "upd:fx-0003", "state_version": 3}
    cost = {"schema_version": "1.0", "record_type": "CostRecord",
            "cost_record_id": opid("cost", [mrid, "VERIFICATION", "strong-llm-v1", vreq["request_id"]]),
            "method_run_id": mrid, "stage": "VERIFICATION", "component": "strong-llm-v1",
            "update_event_id": "upd:fx-0003", "answer_version_id": av["answer_version_id"],
            "request_id": vreq["request_id"], "phase": "INCREMENTAL",
            "model_calls": 1, "cached_calls": 0, "retries": 0, "input_tokens": 1104, "output_tokens": 156,
            "wall_ms": 2140, "cpu_ms": 4, "gpu_ms": None, "bytes_written": 2310,
            "money_estimate": None, "price_table_version": None}

    records = [mrun, upd, snap3, dv3, pv_old, pv_new, edge, cs, q, av, cit, clm, sg, sel, route, vreq, vres, verdict, state, cost]
    json.dump(records, open("example.json", "w"), indent=2, ensure_ascii=False)
    print("method_run_id", mrid, "experiment_id", experiment_id)
    return records

if __name__ == "__main__":
    main()
