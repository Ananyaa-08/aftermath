"""Negative tests for build_spec.py (T-DOC-002).

For each audit category, copy the build inputs to a temporary directory, inject one fault, run the
build, and require (a) a non-zero exit and (b) that the targeted category is reported as FAIL.
A clean copy must exit 0. Run from the build directory:  python3 tests/test_build_audits.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUTS = [f"part{i}.md" for i in range(1, 7)] + ["gen_example.py", "build_spec.py", "ref.docx"]

def edit(part, old, new):
    def f(d):
        p = os.path.join(d, part); s = open(p).read()
        assert old in s, f"anchor missing for injection in {part}: {old[:40]!r}"
        open(p, "w").write(s.replace(old, new, 1))
    return f

CASES = {
    "PIPES":        (edit("part6.md", "| D-043 | Frozen evidence state", "| D-043 | Frozen | evidence state"), None),
    "SCHEMAS":      (edit("part2.md", "#### MethodRun", "#### MethodRunRenamed"), None),
    "STATUSES":     (edit("part2.md", "### 5.2 Semantic statuses", "### 5.2 Semantic statuses\n\nAn UNSUPPORTED answer."), None),
    "WORKFLOW":     (edit("part1.md", "## 1. Project summary", "## 1. Project summary\n\nState PENDING."), None),
    "IDS":          (None, "ids"),
    "EXAMPLE":      (None, "example"),
    "MRUN":         (edit("part2.md", "| CandidateSelection | `csel` | `[method_run_id, ", "| CandidateSelection | `csel` | `["), None),
    "REQS":         (edit("part1.md", "## 1. Project summary", "## 1. Project summary\n\nSee REQ-BOGUS-999."), None),
    "TESTS":        (edit("part1.md", "## 1. Project summary", "## 1. Project summary\n\nSee T-FOO-001."), None),
    "DU":           (edit("part1.md", "## 1. Project summary", "## 1. Project summary\n\nSee D-999."), None),
    "JSON":         (edit("part4.md", '"claim_status": [', '"claim_status": [['), None),
    "LANG":         (edit("part1.md", "## 1. Project summary", "## 1. Project summary\n\nThis design has achieved the target."), None),
    "STYLE":        (edit("part1.md", "## 1. Project summary", "## 1. Project summary\n\nA claim — with an em dash."), None),
    "RAWHTML":      (edit("part1.md", "## 1. Project summary", "## 1. Project summary\n\nRender as <attribute> of <entity>."), None),
    "DOCX":         (None, "docx"),
    "PLACEHOLDERS": (edit("part1.md", "## 1. Project summary", "## 1. Project summary\n\n{{AUDIT_NOPE}}"), None),
}

def run(mutate=None, inject=None):
    d = tempfile.mkdtemp(prefix="aftermath-build-")
    for f in INPUTS: shutil.copy(os.path.join(HERE, f), d)
    if mutate: mutate(d)
    env = dict(os.environ, AFTERMATH_BUILD_INJECT=inject or "")
    p = subprocess.run([sys.executable, "build_spec.py"], cwd=d, env=env, capture_output=True, text=True, timeout=600)
    res = json.load(open(os.path.join(d, "audit_results.json"))) if os.path.exists(os.path.join(d, "audit_results.json")) else {}
    shutil.rmtree(d, ignore_errors=True)
    return p.returncode, res, p.stdout[-400:] + p.stderr[-400:]

failures = []
code, res, _ = run()
print(f"{'CLEAN':13} exit={code}  {'ok' if code == 0 else 'UNEXPECTED FAILURE'}")
if code != 0: failures.append("CLEAN")
for name, (mutate, inject) in CASES.items():
    code, res, tail = run(mutate, inject)
    flagged = str(res.get(name, "")).startswith("FAIL")
    ok = code != 0 and flagged
    # The example-integrity fault trips a hard check; a missing results key is acceptable only if the exit is non-zero.
    print(f"{name:13} exit={code}  category={'FAIL' if flagged else res.get(name, 'n/a')[:30]}  {'ok' if ok else 'NOT CAUGHT'}")
    if not ok: failures.append(name)
print("NEGATIVE TESTS:", "all caught" if not failures else f"problems in {failures}")
sys.exit(1 if failures else 0)
