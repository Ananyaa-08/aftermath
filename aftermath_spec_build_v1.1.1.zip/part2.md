## 5. Formal task and semantic contract

### 5.1 Objects

- **Knowledge at snapshot k**: `K_k` = every document version ingested at or before snapshot `k`, including tombstones, each with its `source_seq` and `effective_from`. Snapshots record what the system has *observed*; they do not by themselves decide what is in force.
- **Latest observed version**: `latest_k(d)` = the version of document `d` in `K_k` with the greatest `source_seq`. The snapshot manifest is `D_k = { (d, latest_k(d)) }`, excluding documents whose latest version is a tombstone. Change detection compares latest observed versions (8.2).
- **Effective version**: `eff_k(d, t)` = the version of `d` in `K_k` with the greatest `effective_from <= t`, ties broken by the greatest `source_seq`; undefined (no evidence from `d`) if no version qualifies or the qualifying version is a tombstone. Evidence applicability always uses `eff_k`, never `latest_k` (REQ-SEM-015). A known revision that is not yet in force therefore never hides the revision that is.
- **History**: `H_k` = `K_k`; the term is used when a scope looks at times other than the present.
- **Answer archive**: `A_k` = every answer version that exists at snapshot `k`, each with its question, temporal scope, `answered_at`, `generated_against_snapshot_id`, recorded citations, and claims.
- **Update event**: `u` extends `K_k` to `K_(k+1)` and moves the manifest from `D_k` to `D_(k+1)`. It carries one or more new document versions or deletions, `observed_at`, and optional declared effective times.
- **Change set**: `Δ(u)` = the `ChangeSpan` records and lineage edges produced by aligning each changed document's prior current version with its new version.
- **Candidate set**: `C_M(u) ⊆ A_(k+1)` = answers selected by method `M` for update `u`, each with one or more selection reasons.
- **Evidence set**: for answer `a`, claim `c`, update `u`: `E(c, u)` = the evidence bundle gathered from `K_(k+1)` under the scope rule of 5.7 (Section 9.5).
- **Predicted verdict**: `v(a, u)` = a semantic status per material claim and an aggregated answer status, valid for snapshot `k+1` at evaluation time `t_eval(a, u)`, committed only if the answer was assessed.

### 5.2 Semantic statuses

| Status | Meaning (always relative to a snapshot, an evaluation time and a source policy) |
|---|---|
| `SUPPORTED` | Applicable evidence entails the claim, and no applicable evidence of equal or higher authority contradicts it (after policy resolution). |
| `CONTRADICTED` | Applicable evidence of strictly higher authority than any support contradicts the claim, or contradiction exists and no support exists. |
| `INSUFFICIENT_SUPPORT` | Within the evidence gathered by this process, nothing applicable entails or contradicts the claim. This is **not** a statement that the claim is false and **not** a statement that no support exists anywhere in the corpus. |
| `UNRESOLVED_CONFLICT` | Applicable evidence both supports and contradicts the claim at the same authority tier, and the source policy does not decide between them. |

Rules:

- Semantic status is **nullable**. It is absent (`null`) for any answer that has never been assessed, and for any assessment that failed or was withheld (REQ-SEM-001).
- Every non-null status is attached to a `valid_for_snapshot_id`, an `evaluation_time`, and a `source_policy_version` (REQ-SEM-003).
- "No evidence retrieved" maps to `INSUFFICIENT_SUPPORT`, never `CONTRADICTED` (REQ-SEM-005).
- "Not selected for checking" never creates a new verdict (REQ-SEM-006).
- A verifier error, timeout, malformed output, incomplete judgment coverage, evidence overflow or budget exhaustion never creates a semantic status (REQ-SEM-007, REQ-VER-007, REQ-EVID-007).

### 5.3 Workflow states

Workflow state belongs to `AnswerCurrentState` (one row per answer version per run). It is independent of semantic status.

| State | Meaning | Semantic status allowed |
|---|---|---|
| `UNASSESSED` | Never assessed in this run (including answers ingested but not yet initially checked). | `null` |
| `QUEUED` | Selected by an update; a job exists and has not started. | Previous verdict retained as history; current status field shows the previous value with `verification_basis = CARRIED_FORWARD` until the job resolves, but `availability = WITHHELD` if the policy `withhold_while_queued` is true (default true for Stage A and B experiments). |
| `IN_PROGRESS` | A job holds the lease. | As for `QUEUED`. |
| `COMPLETED` | A verdict has been committed for the job's target snapshot. | Non-null. |
| `FAILED` | The job exhausted retries. | Previous value retained as history only; current `semantic_status = null`. |
| `WITHHELD` | Selected but not resolved because budget or policy prevented assessment. | Current `semantic_status = null`. |

Allowed transitions (anything else raises `IllegalTransitionError`):

```
UNASSESSED -> QUEUED | COMPLETED (initial check)
QUEUED     -> IN_PROGRESS | WITHHELD | QUEUED (re-selected by a newer update: new active job)
IN_PROGRESS-> COMPLETED | FAILED | QUEUED (re-selected by a newer update)
COMPLETED  -> QUEUED (selected by a later update)
FAILED     -> QUEUED (retry by operator or later update)
WITHHELD   -> QUEUED (budget replenished or later update)
```

### 5.4 Four distinct notions (never conflated)

| Notion | Definition | Who computes it | Has semantic meaning? |
|---|---|---|---|
| **Answer affected by update `u`** | Gold answer-level status after `u` differs from gold status before `u`: `g+(a,u) != g-(a,u)`. | Annotation only. | Yes (gold). |
| **Claim loses support at `u`** | Gold claim status before `u` is `SUPPORTED` and after `u` is one of the other three statuses. | Annotation only. | Yes (gold). |
| **Source dependency outdated at `u`** | The answer has at least one recorded citation or evidence link whose passage lineage has a non-identity edge (`MODIFIED`, `SPLIT`, `MERGED`, `DELETED`, or document deleted) in `Δ(u)`. | Deterministic code. | No. It is a structural fact only. |
| **Answer not checked at `u`** | The answer is not in `C_M(u)`, or it is in `C_M(u)` and ended `WITHHELD` or `FAILED`. | Deterministic code. | No. Its status is carried forward or absent. |

"Needs checking" is a property of a method, not of the data, and has no gold label.

### 5.5 Claims and materiality

- A **claim** is a declarative proposition expressed by a contiguous span of the answer text (`answer_start`, `answer_end`), or, for fallback claims, a whole sentence or the whole answer.
- A claim is **material** if its truth is necessary for the answer to correctly answer the question as asked, including numbers, conditions, qualifiers, named entities and time expressions that the question depends on. Hedges, pleasantries, generic advice and restatements of the question are not material.
- Materiality source, in priority order: gold annotation (evaluation only), fixture declaration, decomposer output. Stage A: claims are answer sentences (`sentence-v1`), all material unless the fixture says otherwise. Stage B: LLM decomposition (`decompose-v1`) proposes claims with `is_material` and `decomposition_confidence`.
- **Uncertain decomposition**: if `decomposition_confidence < 0.7` (default), or claims fail the coverage check (the union of claim spans must cover at least 80% of non-whitespace answer characters), the decomposer emits fallback claims of `kind = SENTENCE` for each answer sentence, or one `kind = ANSWER` claim if sentence splitting fails. Fallback claims are always material, and the router MUST escalate them to the strong verifier rather than accept a cheap verdict (REQ-SEM-011).

### 5.6 Aggregation from claims to answer

Applied over **material** claims only, in this precedence order:

1. If any material claim is `CONTRADICTED`, the answer is `CONTRADICTED`.
2. Else if any material claim is `UNRESOLVED_CONFLICT`, the answer is `UNRESOLVED_CONFLICT`.
3. Else if any material claim is `INSUFFICIENT_SUPPORT`, the answer is `INSUFFICIENT_SUPPORT`.
4. Else (all material claims `SUPPORTED`) the answer is `SUPPORTED`.

If any material claim lacks a status because its assessment failed, the answer gets **no** verdict and the job is `FAILED`. Partial verdicts are never committed as answer verdicts. Non-material claims that are not `SUPPORTED` are recorded in `nonmaterial_issues` and do not change the answer status. An answer with zero material claims and `answer_kind = GROUNDED` is an ingestion error (`NoMaterialClaimsError`); answers with `answer_kind = DEFLECTION` are stored but excluded from assessment and from all metrics.

Rationale for the precedence (D-010): contradiction is the strongest signal that serving the answer is harmful; conflict still includes contradicting evidence; missing support is weaker than either.

### 5.7 Temporal scope, effective versions and evaluation time

Each question has a `scope` (a claim may override it with `scope_override`):

| Scope type | Parameters | Evaluation time `t_eval` | Applicable evidence at target snapshot `k` |
|---|---|---|---|
| `ROLLING_CURRENT` | none | `as_of` of the update being processed (logical clock in experiments) | Passages of `eff_k(d, t_eval)` for every document `d` |
| `FIXED_TIME` | `time` (UTC) | `scope.time` | Passages of `eff_k(d, scope.time)` for every document `d` |
| `FIXED_VERSION` | `document_version_id` | n/a | Only passages of that exact document version |

`ROLLING_CURRENT` and `FIXED_TIME` use one rule and differ only in the time they evaluate. Consequences:

- **Current questions** follow what is in force at `t_eval`, judged with everything known at snapshot `k`.
- **Future-effective revisions** (`effective_from > t_eval`) are known but not in force. The previous version of the same document stays applicable until the new version's `effective_from` (AS-08). The new version's passages may appear in a bundle as non-applicable context so a verifier sees the announced change.
- **Historical questions**: a `FIXED_TIME` answer is affected by a later delivery only if that delivery changes what is in force at `scope.time` (for example a backfilled or retroactive revision whose `effective_from <= scope.time`). A `FIXED_VERSION` answer can never be affected, because document versions are immutable; selectors MUST record it as `TEMPORALLY_EXCLUDED` rather than silently skip it (REQ-CAND-005).
- **Effective-from sources**, in priority order: declared in delivery metadata (`DECLARED_METADATA`), extracted from text (Stage B, `EXTRACTED_TEXT`, with extractor version and confidence), else `source_timestamp` (`DEFAULT_SOURCE_TIMESTAMP`).
- **Effective intervals are derived, never stored.** The interval of version `v` relative to snapshot `k` is `[v.effective_from, next.effective_from)`, where `next` is the version of the same document with the smallest later `effective_from` in `K_k`. Because a later delivery can add a version that changes this interval, intervals are always computed by `eff_k` for a named snapshot and never written into rows.
- **Supersession and cancellation (`supersession-v1`, REQ-SEM-017)**: `eff_k` picks the greatest `effective_from <= t`, ties broken by the greatest `source_seq`. A scheduled change is therefore cancelled or replaced only by a later-observed revision whose `effective_from` is at least the scheduled one's. Example: to cancel a revision scheduled for 2026-12-01, the source delivers a revision with `effective_from = 2026-12-01` (or later) that restores the old text; a revision effective earlier (say 2026-11-01) does not cancel it. Withdrawing a revision without delivering a replacement is not supported in this version. Dataset adapters MUST flag source events that need it (`CANCELLATION_UNSUPPORTED`) and report their count (D-045).
- **Effective-timeline changes** (REQ-UPD-007): a delivery can change what is in force over some interval without any text difference from the latest observed version. Example: `r1` (12 USD, effective January) and `r2` (15 USD, effective December) are known; `r3` arrives in November with `r2`'s text and effective November. The text diff `r2 -> r3` is empty, but November's in-force price changes from 12 to 15. Section 8.3a detects this by comparing the effective timeline before and after the delivery and emits change spans for every interval whose in-force content changed (AS-24).
- **Granularity**: `effective_from` belongs to a whole document version. A version that mixes facts already in force with an announcement for a later date cannot be represented by one interval. Until passage-level applicability exists (M9), dataset adapters MUST flag documents whose versions contain dated future announcements (`MIXED_EFFECTIVE`), exclude them from the temporal track, and report how many were excluded (REQ-SEM-016). Fixture documents are constructed with uniform effective dates. In M9, `PassageVersion.effective_from_override` makes a passage inapplicable before its own date, and the passage's lineage predecessor in the previously effective version is applicable instead (EVIDENCE-GATED, U-024).
- **Future-effective content and rechecks**: every *selected* `ROLLING_CURRENT` candidate affected by a change span with `effective_from > as_of` receives a `ScheduledRecheck` due at that time (REQ-SEM-013). The system cannot know the full set of answers that future content will affect, so it schedules only discovered candidates and reports misses with the future-effective miss metric (13.2).
- **Expired verdicts**: a verdict is never edited. When an update selects an answer, the old verdict stays in `answer_verdicts` with its `valid_for_snapshot_id`; the current-state pointer moves to the new job. When an update does not select an answer, the old verdict remains the current pointer with `verification_basis = CARRIED_FORWARD` and `as_of_snapshot_id` advanced. A verdict whose snapshot is older than head is therefore always visibly older, never silently "re-validated".

### 5.8 Source authority and precedence

Configured per corpus by a versioned `SourcePolicy` YAML file (schema in Section 6.5). Default for the fixture corpus (`configs/policies/sp-tiny-1.yaml`, planned):

```yaml
policy_version: sp-tiny-1
tiers:                         # lower number = higher authority
  - tier: 1
    source_types: [release_note, legal_notice]
  - tier: 2
    source_types: [product_doc]
default_tier: 3
same_document_supersession: true      # within one document, only the effective version (5.7) is applicable
cross_document_same_tier: CONFLICT    # CONFLICT | NEWER_EFFECTIVE_WINS
group_tier_rule: WEAKEST_MEMBER       # a support group's tier is its numerically largest member tier
```

Resolution for one claim, after the verifier returns stances for applicable evidence groups (deterministic code, shared by all verifiers, REQ-SEM-009):

```
S = applicable groups judged SUPPORTS;  X = applicable groups judged CONTRADICTS
ts = min tier over S (None if S empty); tx = min tier over X (None if X empty)
if S empty and X empty:        INSUFFICIENT_SUPPORT   rule=NO_SUPPORT_FOUND
elif X empty:                  SUPPORTED              rule=SUPPORT_ONLY
elif S empty:                  CONTRADICTED           rule=CONTRADICTION_ONLY
elif tx < ts:                  CONTRADICTED           rule=HIGHER_TIER_CONTRADICTION
elif ts < tx:                  SUPPORTED              rule=HIGHER_TIER_SUPPORT  (contradiction recorded as overridden)
elif policy.cross_document_same_tier == NEWER_EFFECTIVE_WINS and the newest effective_from differs:
                               status of the side with the newest effective_from, rule=SAME_TIER_NEWER_EFFECTIVE
else:                          UNRESOLVED_CONFLICT    rule=SAME_TIER_CONFLICT
```

The newest text does not win by default across documents (plan Section 5). Within a document, only the effective version applies (5.7); other known versions may appear in bundles as non-applicable context (`applicable = false`). Authority tiers come from each version's `metadata.source_type`.

### 5.9 Availability

Availability is derived, never written directly (REQ-SEM-014):

```
availability = AVAILABLE iff
    workflow_state == COMPLETED and semantic_status == SUPPORTED
    and verification_basis in {VERIFIED_AT_SNAPSHOT, CARRIED_FORWARD}
  or
    workflow_state in {QUEUED, IN_PROGRESS} and semantic_status == SUPPORTED
    and policy.withhold_while_queued == false
otherwise WITHHELD
```

`CONTRADICTED`, `INSUFFICIENT_SUPPORT` and `UNRESOLVED_CONFLICT` answers are withheld from serving. Withholding is a disposition, not a semantic claim: a withheld answer with `semantic_status = null` has **not** been judged false (REQ-BASE-008).

### 5.10 What the system can and cannot conclude outside the candidate set

For an answer `a` not in `C_M(u)`:

- The system **can** state: "`a` was not selected by method `M` under configuration `C` for update `u`; its last verdict was valid for snapshot `j` (`j <= k`) and is carried forward."
- The system **cannot** state that `a` is still supported at `k+1`, that `u` did not affect it, or that it was checked.
- The audit sample (Section 9.7) yields an estimate of the rate of **verifier-detected** changes among non-selected answers, with a sampling interval that does not include verifier error. Only on evaluation splits with human labels for the audited answers does it estimate the miss rate (REQ-EVAL-011). It does not certify any individual unsampled answer and does not guarantee complete detection.
- Reports MUST show the count of carried-forward answers separately from verified answers (REQ-SEM-006).

---

## 6. Data model and schemas

### 6.1 Conventions

- **Source of truth**: Pydantic v2 models in `aftermath.core.schemas` (planned). JSON Schema files are exported from them into `schemas/` by `aftermath export-schemas` (planned) and checked into the repository.
- **Serialization**: JSON objects, UTF-8. Bulk outputs are JSON Lines (`.jsonl`). Every record carries `"schema_version": "1.0"` and `"record_type"`.
- **Canonical JSON** (`cjson-v1`), used for every hash over structured data: `json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)` encoded as UTF-8. NaN and infinities are forbidden. Floats in hashed objects are discouraged; where present they are serialized by Python `repr`.
- **Hashes**: `"sha256:" + lowercase hex` of SHA-256 over UTF-8 bytes.
- **Timestamps**: UTC, RFC 3339, millisecond precision, `Z` suffix: `2026-04-01T00:00:00.000Z`. Naive datetimes raise `TimeZoneError` at model validation.
- **Enums**: upper snake case strings.
- **Nulls**: optional fields are present with `null`, not omitted, in serialized records.

### 6.2 Text, Unicode and offsets (`canon-v1`)

1. Source bytes are decoded as strict UTF-8. Undecodable input is rejected with `InvalidEncodingError` (REQ-ING-006). The original bytes are stored in the blob store keyed by `source_bytes_hash`.
2. A leading U+FEFF byte-order mark is removed.
3. Line endings `\r\n` and `\r` become `\n`.
4. The text is normalized to Unicode NFC.
5. The result is the **canonical text**, stored in `DocumentVersion.text`, hashed into `content_hash`.

Offsets:

- All offsets are **Unicode code point** indices into canonical text (Python `str` indices), half-open `[start, end)`.
- Passage offsets are document-version-level; passage-relative offsets are derived as `doc_offset - passage.start`.
- Citation, change-span, support-member and verifier-quote spans all use document-version-level offsets and name the `document_version_id` or `passage_version_id` they refer to.
- Matching views (`norm-v1`: NFKC, `casefold`, collapse all whitespace runs to one space, strip) are **derived only** and never stored as the offset base. When a quote is located through the normalized view, the locator maps back to canonical offsets with a deterministic offset map built during normalization (REQ-DATA-001).
- Traceability: `canonical_text[start:end]` reproduces every stored span exactly; `source_bytes_hash` plus `normalization_version` reproduces the canonical text from the original bytes. The API converts to UTF-16 offsets for the browser at the boundary only (Stage C).

### 6.3 Identifier grammar

Content entities use readable, deterministic composite IDs. Operational records use hashed IDs over a canonical identity tuple. All IDs are ASCII. `document_id`, `answer_id`, `question_id`, `corpus_id`, `delivery_id` and `source_revision_id` are externally supplied and must match `[a-z0-9][a-z0-9_.-]{0,63}`.

| Entity | ID pattern | Example |
|---|---|---|
| Document | `<document_id>` | `doc_plans` |
| DocumentVersion | `dv:<document_id>@<source_revision_id>` | `dv:doc_plans@r3` |
| PassageVersion | `pv:<document_id>@<rev>#p<4-digit ordinal>` | `pv:doc_plans@r3#p0002` |
| Lineage | `lin:<document_id>:<first_rev>:p<ordinal at first appearance>` | `lin:doc_plans:r1:p0002` |
| PassageLineageEdge | `le:<delivery_id>:<4-digit ordinal>` | `le:fx-0003:0002` |
| CorpusSnapshot | `snap:<6-digit seq>` | `snap:000003` |
| UpdateEvent | `upd:<delivery_id>` | `upd:fx-0003` |
| ChangeSpan | `cs:<delivery_id>:<4-digit ordinal>` | `cs:fx-0003:0001` |
| Question | `<question_id>` | `q_starter_price` |
| AnswerVersion | `av:<answer_id>@<version>` | `av:ans_starter_price@1` |
| Claim | `clm:<answer_id>@<version>#c<2-digit>` | `clm:ans_starter_price@1#c01` |
| Citation | `cit:<answer_id>@<version>#<2-digit>` | `cit:ans_starter_price@1#01` |
| EvidenceLink | `elink:<answer_id>@<version>#c<NN>.l<NN>` | `elink:ans_starter_price@1#c01.l01` |
| SupportGroup | `sg:<answer_id>@<version>#c<NN>.g<NN>` | `sg:ans_starter_price@1#c01.g01` |
| Operational records | `<prefix>_` + first 20 hex of SHA-256 over `cjson-v1` of the identity tuple | `vreq_...` |

Operational prefixes and identity tuples:

| Record | Prefix | Identity tuple |
|---|---|---|
| ExperimentConfig | `xcfg` | the resolved config object |
| ExperimentRun | `xexp` | `[config_id, code_git_sha]` |
| MethodRun | `mrun` | `[experiment_id, method_id, seed]` |
| EvidenceBundle | `bun` | `[answer_version_id, update_event_id, target_snapshot_id, evidence_mode, gatherer_config_hash, evidence_state_hash]` (no method-run id, so canonical bundles are shareable; selector-informed bundles add the `method_run_id` as a seventh element) |
| CandidateSelection | `csel` | `[method_run_id, update_event_id, answer_version_id]` |
| AssessmentJob | `job` | `[method_run_id, update_event_id, answer_version_id, target_snapshot_id]` |
| RoutingDecision | `route` | `[method_run_id, update_event_id, answer_version_id]` |
| VerificationRequest | `vreq` | `[method_run_id, update_event_id, answer_version_id, verifier_id, partition_index, attempt]` |
| VerificationResult | `vres` | `[request_id]` |
| AnswerVerdict | `verdict` | `[job_id]` |
| CostRecord | `cost` | `[method_run_id, stage, component, reference_id]` (reference = request, job, update or `"method_run"`) |
| ScheduledRecheck | `rchk` | `[method_run_id, answer_version_id, due_at, source_change_span_id]` |
| ReviewAnnotation | `rann` | `[item_id, annotator_id, round]` |

Initial-check jobs (Section 8.12) use `update_event_id = "upd:INITIAL"`. Experiment and method-run IDs are deterministic, so rerunning an identical configuration at the same code version produces the same IDs; the runner refuses to overwrite an existing experiment directory unless `--force` is given (planned). Every operational identity tuple starts with the method-run id (except shareable canonical bundles), so two methods assessing the same answer at the same update can never collide (REQ-REPRO-004).

### 6.4 Storage, append-only records and current-state pointers

Stores (REQ-DATA-008):

| Store | File | Contents | Readers |
|---|---|---|---|
| Serving store | `runs/<experiment_id>/methods/<method_run_id>/serving.db` (one per method run) | Corpus, archive, claims, links, updates, selections, jobs, routing, requests, results, verdicts, current state, costs | Pipeline, evaluator (read-only), API |
| Blob store | `runs/<experiment_id>/methods/<method_run_id>/blobs/` keyed by hash | Original source bytes, raw model responses | Pipeline, auditors |
| Response cache | `cache/responses/<verifier_id>/<request_hash>.json` | Recorded provider responses for replay | Verifier adapters |
| Gold store | `data/gold/<dataset>/annotation.db` or fixture `gold/labels.jsonl` | `ReviewAnnotation`, adjudicated gold labels and gold evidence | **Evaluator and annotation tools only** |

Method-run isolation (REQ-REPRO-004, D-033): every method run owns its serving store, blob directory, current-state rows, jobs, routing decisions, requests, results, verdicts and cost records. No mutable record is shared between method runs. Immutable, content-addressed inputs are shared: dataset files and the dataset manifest, the provider response cache under `cache/`, and canonical evidence bundles under `runs/<experiment_id>/shared/bundles/`. Each method run ingests the corpus and archive into its own store and records its own cold-start cost.

SQLite settings: `PRAGMA foreign_keys=ON`, `PRAGMA journal_mode=WAL`, `PRAGMA synchronous=FULL`. All writes go through repository classes in `aftermath.store`.

Append-only tables (INSERT only; `BEFORE UPDATE` and `BEFORE DELETE` triggers raise `RAISE(ABORT, 'append-only')`, REQ-DATA-003): `documents`, `document_versions`, `passage_versions`, `passage_lineage_edges`, `applicability_changes`, `snapshots`, `snapshot_changes`, `update_events`, `update_event_status_log`, `delivery_attempts`, `change_spans`, `questions`, `answer_versions`, `claims`, `citations`, `evidence_links`, `support_groups`, `support_group_members`, `candidate_selections`, `assessment_jobs`, `job_state_log`, `routing_decisions`, `verification_requests`, `verification_results`, `answer_verdicts`, `scheduled_rechecks`, `cost_records`.

Mutable pointer tables (the only UPDATEs allowed, REQ-DATA-004):

| Table | Key | Updated by | Concurrency rule |
|---|---|---|---|
| `corpus_head` | `corpus_id` | Update applier | `UPDATE ... SET head_seq = :new WHERE corpus_id = :c AND head_seq = :expected`; zero rows affected raises `StaleHeadError`. |
| `answer_current_state` | `(method_run_id, answer_version_id)` | Committer, selector enqueue | `UPDATE ... WHERE ... AND state_version = :expected`, incrementing `state_version`; commits that change status also require `active_job_id = :job_id` (Section 8.11). |

Every pointer change also appends a row to a log table (`update_event_status_log`, `job_state_log`) so the full history is reconstructible.

Snapshot membership is append-only: `snapshot_changes(snapshot_seq, document_id, document_version_id NULL)` where `NULL` means deleted. Membership at snapshot `k` = for each document, the row with the greatest `snapshot_seq <= k`, excluding `NULL`. `CorpusSnapshot.manifest_hash` = hash of `cjson-v1` of the sorted list of `[document_id, document_version_id]` pairs, and MUST be recomputed and compared on every snapshot read in tests (T-DATA-004).

### 6.5 Schemas

Types: `Id` = string per Section 6.3; `Hash` = `sha256:<64 hex>`; `Ts` = timestamp per 6.1; `Off` = non-negative int code-point offset. FK = foreign key. UQ = uniqueness constraint.

#### Document

| Field | Type | Req | Notes |
|---|---|---|---|
| `document_id` | Id | req | PK. |
| `corpus_id` | Id | req | |
| `source_type` | string | req | Initial source type. Authority is taken from each version's `metadata.source_type` (5.8); a change produces an `AUTHORITY_CHANGED` span. |
| `title` | string | opt | |
| `external_ref` | string | opt | Upstream identifier (URL, Wikipedia page id, repo path). |
| `created_at` | Ts | req | First observed. |

#### DocumentVersion

| Field | Type | Req | Notes |
|---|---|---|---|
| `document_version_id` | Id | req | PK. |
| `document_id` | Id | req | FK Document. |
| `source_revision_id` | Id | req | UQ with `document_id`. |
| `source_seq` | int | req | Monotonic per document; orders versions. UQ with `document_id`. |
| `is_deletion` | bool | req | `true` for a tombstone version (empty text). |
| `text` | string | req | Canonical text. |
| `char_length` | int | req | Code points. |
| `content_hash` | Hash | req | Over canonical text. |
| `source_bytes_hash` | Hash | req | Over original bytes. |
| `normalization_version` | string | req | `canon-v1`. |
| `segmentation_version` | string | req | `seg-v1`. |
| `source_timestamp` | Ts | req | Revision time claimed by the source. |
| `observed_at` | Ts | req | Transaction time. |
| `effective_from` | Ts | req | See 5.7. |
| `effective_from_source` | enum | req | `DECLARED_METADATA`, `EXTRACTED_TEXT`, `DEFAULT_SOURCE_TIMESTAMP`. |
| `effective_to` | Ts | opt | Derived, never stored: computed by `eff_k` for a named snapshot (5.7). Exports state that snapshot. |
| `delivery_id` | Id | req | FK UpdateEvent via `upd:<delivery_id>`. |
| `metadata` | object | req | Free-form; must include `source_type`, which sets this version's authority tier (5.8). |

Constraint: same `(document_id, source_revision_id)` with a different `content_hash` or declared `effective_from` raises `IdempotencyConflictError` (REQ-ING-001). A new `source_revision_id` always creates a new version, even when its text is unchanged (REQ-ING-009).

#### CorpusSnapshot

| Field | Type | Req | Notes |
|---|---|---|---|
| `snapshot_id` | Id | req | PK. |
| `snapshot_seq` | int | req | UQ per corpus. Starts at 1. |
| `corpus_id` | Id | req | |
| `parent_snapshot_id` | Id | opt | Null only for seq 1. |
| `created_by_update_event_id` | Id | req | FK UpdateEvent. |
| `manifest_hash` | Hash | req | |
| `document_count` | int | req | |
| `as_of` | Ts | req | Logical time of the update. |

#### PassageVersion

| Field | Type | Req | Notes |
|---|---|---|---|
| `passage_version_id` | Id | req | PK. |
| `document_version_id` | Id | req | FK. |
| `ordinal` | int | req | 1-based position. UQ with `document_version_id`. |
| `section_path` | list[string] | req | Heading path. |
| `start`, `end` | Off | req | Into the document version's canonical text. |
| `content_hash` | Hash | req | Over `text[start:end]`. |
| `norm_hash` | Hash | req | Over `norm-v1` of the passage. |
| `lineage_id` | Id | req | Assigned at first appearance, inherited through `IDENTICAL`, `REFORMATTED`, `MOVED`, `MODIFIED` edges; new lineage for `ADDED`, `SPLIT` outputs and `MERGED` outputs. |
| `segmentation_version` | string | req | |
| `effective_from_override` | Ts | opt | M9 only: passage-level effective date extracted from text, with source and confidence recorded in the passage metadata. Null before M9. |

#### PassageLineageEdge

| Field | Type | Req | Notes |
|---|---|---|---|
| `lineage_edge_id` | Id | req | PK. |
| `update_event_id` | Id | req | FK. |
| `from_passage_version_ids` | list[Id] | req | Empty for `ADDED`. |
| `to_passage_version_ids` | list[Id] | req | Empty for `DELETED`. |
| `relation` | enum | req | `IDENTICAL`, `REFORMATTED`, `MOVED`, `MODIFIED`, `SPLIT`, `MERGED`, `ADDED`, `DELETED`. |
| `alignment_score` | float | opt | In [0,1]. |
| `alignment_confidence` | enum | req | `HIGH`, `LOW`. |
| `alignment_method` | string | req | e.g. `diff-v1/token-seqmatch`. |

#### Question

| Field | Type | Req | Notes |
|---|---|---|---|
| `question_id` | Id | req | PK. |
| `text` | string | req | |
| `scope` | object | req | `{type: ROLLING_CURRENT|FIXED_TIME|FIXED_VERSION, time: Ts|null, document_version_id: Id|null}`; exactly the parameters required by the type are non-null. |
| `created_at` | Ts | req | |
| `origin` | enum | req | `IMPORTED`, `GENERATED`, `FIXTURE`, `ANNOTATOR`. |

#### AnswerVersion

| Field | Type | Req | Notes |
|---|---|---|---|
| `answer_version_id` | Id | req | PK. |
| `answer_id` | Id | req | UQ with `version`. |
| `question_id` | Id | req | FK. |
| `version` | int | req | 1-based. |
| `text` | string | req | Canonical text. |
| `content_hash` | Hash | req | |
| `answer_kind` | enum | req | `GROUNDED`, `DEFLECTION`. |
| `origin` | enum | req | `IMPORTED`, `GENERATED`, `FIXTURE`, `REPAIRED`. |
| `parent_answer_version_id` | Id | opt | Required when `origin = REPAIRED`. |
| `answered_at` | Ts | req | |
| `generated_against_snapshot_id` | Id | req | Snapshot visible to the answer generator. |
| `generator` | object | opt | `{model_id, prompt_version, config_hash}` when generated. |

#### Claim

| Field | Type | Req | Notes |
|---|---|---|---|
| `claim_id` | Id | req | PK. |
| `answer_version_id` | Id | req | FK. |
| `ordinal` | int | req | UQ with answer. |
| `text` | string | req | Normalized proposition (may differ from span text for decomposed claims). |
| `answer_start`, `answer_end` | Off | req | Span in the answer text that expresses the claim. |
| `kind` | enum | req | `ATOMIC`, `SENTENCE`, `ANSWER`. |
| `is_material` | bool | req | |
| `materiality_source` | enum | req | `FIXTURE`, `DECOMPOSER`, `DEFAULT_ALL_MATERIAL`. Gold materiality lives in the gold store only. |
| `decomposition_method` | string | req | `sentence-v1`, `decompose-v1`, ... |
| `decomposition_confidence` | float | opt | |
| `scope_override` | object | opt | Same shape as `Question.scope`. |
| `created_by` | object | opt | `{model_id, prompt_version, config_hash}` for model-derived claims. |

#### Citation

| Field | Type | Req | Notes |
|---|---|---|---|
| `citation_id` | Id | req | PK. |
| `answer_version_id` | Id | req | FK. |
| `ordinal` | int | req | |
| `document_id` | Id | req | As recorded. |
| `document_version_id` | Id | opt | Resolved against `generated_against_snapshot_id`. |
| `passage_version_id` | Id | opt | Resolved passage. |
| `quote` | string | opt | As recorded. |
| `start`, `end` | Off | opt | Located quote span. |
| `resolution` | enum | req | `QUOTE_EXACT`, `QUOTE_NORMALIZED`, `DOCUMENT_ONLY`, `UNRESOLVED`. |
| `origin` | enum | req | `RECORDED`. |

A citation is a **dependency hint**, never proof of support (REQ-ING-005).

#### EvidenceLink (inferred)

| Field | Type | Req | Notes |
|---|---|---|---|
| `evidence_link_id` | Id | req | PK. |
| `claim_id` | Id | req | FK. |
| `passage_version_id` | Id | req | FK. |
| `lineage_id` | Id | req | Copied for lineage lookup. |
| `start`, `end` | Off | opt | |
| `relation` | enum | req | `SUPPORTS`, `CONTRADICTS`, `RELATED`. |
| `origin` | enum | req | `CITATION_RESOLVED`, `INFERRED_RETRIEVAL`, `INFERRED_VERIFIER`. (`GOLD_ANNOTATION` exists only in the gold store.) |
| `confidence` | float | opt | |
| `established_at_snapshot_id` | Id | req | |
| `created_by` | object | req | `{component, model_id, prompt_version, config_hash}`. |

#### SupportGroup and SupportGroupMember

| Field | Type | Req | Notes |
|---|---|---|---|
| `support_group_id` | Id | req | PK. |
| `claim_id` | Id | req | FK. |
| `established_at_snapshot_id` | Id | req | |
| `origin` | enum | req | `CITATION_ASSUMED` (Stage A, unverified), `VERIFIED_SINGLETON`, `VERIFIED_JOINT`. |
| `verified` | bool | req | |
| `confidence` | float | opt | |
| `members` | list[Member] | req | 1 to `max_group_size` (default 2) members. |
| `created_by` | object | req | |

Member: `{passage_version_id: Id req, lineage_id: Id req, start: Off opt, end: Off opt}`. Stored in `support_group_members` with UQ `(support_group_id, passage_version_id)`. Semantics: members of one group are jointly required (AND); groups of one claim are alternatives (OR). Groups are estimated justifications, not proofs.

#### UpdateEvent

| Field | Type | Req | Notes |
|---|---|---|---|
| `update_event_id` | Id | req | PK. |
| `delivery_id` | Id | req | UQ. Idempotency key. |
| `corpus_id` | Id | req | |
| `payload_hash` | Hash | req | Over `cjson-v1` of the delivery payload. |
| `kind` | enum | req | `INITIAL_LOAD`, `CONTENT_UPDATE`, `DOCUMENT_ADD`, `DOCUMENT_DELETE`, `BATCH`, `CLOCK_TICK` (fires due scheduled rechecks). |
| `status` | enum | req | Processing outcome; the latest value is the last row in `update_event_status_log`: `APPLIED`, `NO_OP_UNCHANGED`, `PARKED_OUT_OF_ORDER`, `REJECTED`, `FAILED_APPLY`. Redeliveries are logged in `delivery_attempts` (8.1), not as statuses. |
| `received_at` | Ts | req | |
| `as_of` | Ts | req | Logical time used as `t_eval` for current scope. |
| `base_snapshot_id` | Id | opt | |
| `result_snapshot_id` | Id | opt | Null unless `APPLIED`. |
| `document_version_ids` | list[Id] | req | |
| `diff_version` | string | req | |
| `error` | object | opt | `{type, message}`. |

Delivery payload (input file, planned `fixtures/.../deliveries/*.json`): `{delivery_id, corpus_id, documents: [{document_id, source_type?, title?, source_revision_id, source_seq, source_timestamp, effective_from?, deleted, text_path | text}]}`. `payload_hash` is computed over the payload with each document's text replaced by its `content_hash`.

#### ChangeSpan

| Field | Type | Req | Notes |
|---|---|---|---|
| `change_span_id` | Id | req | PK. |
| `update_event_id` | Id | req | FK. |
| `document_id` | Id | req | |
| `old_document_version_id`, `new_document_version_id` | Id | opt | Null on the absent side for adds or deletes. |
| `old_passage_version_id`, `new_passage_version_id` | Id | opt | |
| `kind` | enum | req | `ADDED`, `DELETED`, `MODIFIED`, `MOVED`, `SPLIT`, `MERGED`, `REFORMATTED`, `DOCUMENT_ADDED`, `DOCUMENT_DELETED`, `EXPANDED_UNCERTAIN`, `AUTHORITY_CHANGED` (document-level, when `source_type` differs from the prior version). |
| `lineage_edge_id` | Id | opt | |
| `old_start`, `old_end`, `new_start`, `new_end` | Off | opt | Document-version offsets. |
| `old_text`, `new_text` | string | opt | Exact slices, stored for audit. |
| `features` | object | req | `{numeric_change, numbers_old, numbers_new, date_change, negation_change, qualifier_change}`. |
| `alignment_confidence` | enum | req | `HIGH`, `LOW`. |
| `effective_from` | Ts | req | From the new version, or from extraction (Stage B); for timeline spans, the start of the changed interval. |
| `effective_to` | Ts | opt | End of the changed interval for timeline spans; null when open-ended. |
| `applicability_change_id` | Id | opt | Set on spans produced or confirmed by the effective-timeline diff (8.3a). |

`MOVED` and `REFORMATTED` spans are recorded but are not semantic changes; selectors treat them according to configuration (B3 default ignores them).

#### ApplicabilityChange

| Field | Type | Req | Notes |
|---|---|---|---|
| `applicability_change_id` | Id | req | `ac:<delivery_id>:<4-digit ordinal>`. |
| `update_event_id` | Id | req | FK. |
| `document_id` | Id | req | |
| `interval_from` | Ts | req | Start of the interval whose in-force content changed. |
| `interval_to` | Ts | opt | End of that interval; null when open-ended. |
| `old_effective_version_id` | Id | opt | Version in force over the interval before the delivery; null if none. |
| `new_effective_version_id` | Id | opt | Version in force after the delivery; null if none (tombstone or no version). |
| `text_diff_reused` | bool | req | True when the pair equals the latest-observed pair already diffed, so no duplicate spans were emitted (8.3a). |
| `timeline_version` | string | req | `timeline-v1`. |

#### CandidateSelection

| Field | Type | Req | Notes |
|---|---|---|---|
| `selection_id` | Id | req | PK. UQ `(method_run_id, update_event_id, answer_version_id)`. |
| `method_run_id`, `update_event_id`, `answer_version_id` | Id | req | FKs. |
| `selector_id` | string | req | Composite selectors record the union selector id. |
| `rank` | int | req | 1-based after merge. |
| `is_audit_sample` | bool | req | |
| `reasons` | list[Reason] | req | Non-empty unless `is_audit_sample`. |
| `temporal_exclusion` | enum | opt | `TEMPORALLY_EXCLUDED` when recorded but not queued (FIXED_VERSION). |

Reason: `{path: PROVENANCE_CITATION|PROVENANCE_INFERRED|DOCUMENT_INDEX|PASSAGE_INDEX|SIMILARITY|DISCOVERY|EXHAUSTIVE|SCHEDULED_EFFECTIVE|AUDIT_SAMPLE, change_span_id: Id|null, via: Id|null (citation, link or claim), score: float|null}`.

#### AssessmentJob

| Field | Type | Req | Notes |
|---|---|---|---|
| `job_id` | Id | req | PK. |
| `method_run_id`, `update_event_id`, `answer_version_id` | Id | req | |
| `target_snapshot_id` | Id | req | The snapshot this job evaluates. |
| `evaluation_time` | Ts | req | |
| `created_at_logical` | Ts | req | |
| `state` | enum | req | Initial `QUEUED`; transitions in `job_state_log` (`QUEUED`, `IN_PROGRESS`, `COMPLETED`, `FAILED`, `WITHHELD`, `SUPERSEDED`). |

#### RoutingDecision

| Field | Type | Req | Notes |
|---|---|---|---|
| `routing_decision_id` | Id | req | PK. |
| `method_run_id`, `update_event_id`, `answer_version_id`, `job_id` | Id | req | |
| `policy_id` | string | req | `verify_all_selected-v1`, `risk_uncertainty_cost-v1`, `risk_only-v1`, `uncertainty_only-v1`, `uniform-v1`. |
| `action` | enum | req | `ESCALATE_STRONG`, `ACCEPT_CHEAP_VERDICT`, `WITHHOLD_BUDGET`, `WITHHOLD_POLICY`, `INVALIDATE_ONLY`. |
| `priority_score` | float | opt | |
| `prediction` | object | opt | `{model_id, claim_distributions, p_answer_supported, uncertainty}`; also stored as `provisional_prediction` when withheld. |
| `estimated_cost` | object | req | `{model_calls, input_tokens}`. |
| `budget_before`, `budget_after` | object | req | Same units as the configured budget; `null` values mean unbounded. |
| `thresholds` | object | opt | Values in force and the calibration split hash they were fit on. |

#### VerificationRequest

| Field | Type | Req | Notes |
|---|---|---|---|
| `request_id` | Id | req | PK. |
| `job_id`, `method_run_id`, `update_event_id`, `answer_version_id` | Id | req | |
| `claim_ids` | list[Id] | req | |
| `target_snapshot_id` | Id | req | Evidence is read only from this snapshot and history. |
| `evaluation_time` | Ts | req | |
| `verifier_id` | string | req | Configured name. |
| `verifier_tier` | enum | req | `MOCK`, `CHEAP`, `STRONG`. |
| `model_id` | string | opt | Exact provider model identifier as pinned. |
| `prompt_version` | string | opt | |
| `params` | object | req | `{temperature, max_output_tokens, timeout_s}` or model-specific. |
| `evidence_bundle` | object | req | An `EvidenceBundle` (below), restricted to this partition's items and coverage. |
| `partition` | object | req | `{index, count}`; `count = 1` unless the bundle was partitioned (9.5 step 9). |
| `attempt` | int | req | 1-based. |
| `replay_mode` | enum | req | `LIVE`, `RECORD`, `REPLAY`. |

#### EvidenceBundle

| Field | Type | Req | Notes |
|---|---|---|---|
| `bundle_id` | Id | req | Section 6.3. |
| `evidence_mode` | enum | req | `CANONICAL`, `SELECTOR_INFORMED` (9.5). |
| `gatherer_config_hash` | Hash | req | |
| `evidence_state_hash` | Hash | req | Hash of the evidence state the bundle was built from: the frozen state in `CANONICAL` mode, the method run's current state in `SELECTOR_INFORMED` mode (9.5). |
| `items` | list | req | `[{handle, passage_version_id, role, applicable, authority_tier, content_hash, group_ids, window, home_partition}]`. Roles: `MODIFIED_SUCCESSOR`, `NEW_EVIDENCE`, `CONTRADICTION_CANDIDATE`, `SURVIVING_SUPPORT`, `RETRIEVED`, `HISTORICAL`, `OLD_SUPPORT`. `window` is `{start, end}` or null. |
| `required_coverage` | list | req | `[{claim_id, handles, groups}]`: every applicable item and every configured group (size at least 2) whose members are all applicable, which the verifier must judge for that claim (9.8). |
| `bundle_hash` | Hash | req | Over `cjson-v1` of `items`. |
| `dropped` | list | req | `[{passage_version_id, role, reason}]`, reasons `OVER_ITEM_LIMIT`, `OVER_CHAR_LIMIT`, `WINDOWED`, `PARTITION_CAP`. |
| `dropped_by_role` | object | req | Counts per role, reported per update. |
| `incompleteness` | enum | req | `NONE`, `RETRIEVAL_DEGRADED`, `DISCOVERED_EVIDENCE_DROPPED` (9.5 step 10). |
| `char_count` | int | req | |

#### VerificationResult

| Field | Type | Req | Notes |
|---|---|---|---|
| `result_id` | Id | req | PK. UQ `request_id`. |
| `request_id` | Id | req | FK. |
| `status` | enum | req | `OK`, `MALFORMED_OUTPUT`, `INCOMPLETE_COVERAGE`, `TIMEOUT`, `PROVIDER_ERROR`, `REFUSED`. |
| `is_mock` | bool | req | |
| `judgments` | list | req | `[{claim_id, passage_version_ids, stance: SUPPORTS|CONTRADICTS|NEUTRAL, citations: [{passage_version_id, quote, start, end}]}]`. `passage_version_ids` is one item or one configured group. SUPPORTS and CONTRADICTS carry exactly one located citation per member passage; NEUTRAL carries none. |
| `coverage_complete` | bool | req | Every `required_coverage` entry of the request received exactly one valid judgment. |
| `missing_coverage` | list | req | `[{claim_id, handle_or_group}]`. |
| `verifier_claim_statuses` | list | opt | The verifier's own claim status and confidence, recorded for analysis only. |
| `raw_response_hash` | Hash | opt | Raw response stored in blob store. |
| `parse_errors` | list[string] | req | |
| `latency_ms`, `input_tokens`, `output_tokens` | int | opt | Measured. |

#### AnswerVerdict

| Field | Type | Req | Notes |
|---|---|---|---|
| `verdict_id` | Id | req | PK. UQ `job_id`. |
| `job_id`, `method_run_id`, `answer_version_id`, `update_event_id` | Id | req | |
| `valid_for_snapshot_id` | Id | req | |
| `evaluation_time` | Ts | req | |
| `semantic_status` | enum | req | Never null in a verdict. |
| `claim_statuses` | list | req | `[{claim_id, is_material, semantic_status, resolution: {rule, best_support_tier, best_contradiction_tier, supporting_groups, contradicting_groups}}]`. |
| `nonmaterial_issues` | list | req | |
| `assessor_tier` | enum | req | `RULE`, `MOCK`, `TRANSITION_MODEL`, `CHEAP_VERIFIER`, `STRONG_VERIFIER`, `HUMAN`. |
| `verification_result_ids` | list[Id] | req | |
| `source_policy_version` | string | req | |
| `evidence_incompleteness` | enum | req | Worst bundle `incompleteness` over the partitions used: `NONE` or `RETRIEVAL_DEGRADED`. A verdict can never be committed from a bundle marked `DISCOVERED_EVIDENCE_DROPPED`. |
| `reused_from_verdict_id` | Id | opt | Set when a verdict is reused for an identical bundle (Section 8.13). |
| `committed_at_logical` | Ts | req | |

#### AnswerCurrentState (mutable pointer)

| Field | Type | Req | Notes |
|---|---|---|---|
| `method_run_id`, `answer_version_id` | Id | req | PK. |
| `workflow_state` | enum | req | Section 5.3. |
| `semantic_status` | enum | opt | |
| `verdict_id` | Id | opt | Current verdict pointer. |
| `status_snapshot_id` | Id | opt | Snapshot the current status is valid for. |
| `as_of_snapshot_id` | Id | req | Head when the row was last updated. |
| `verification_basis` | enum | req | `VERIFIED_AT_SNAPSHOT`, `CARRIED_FORWARD`, `NONE`. |
| `availability` | enum | req | Derived per 5.9. |
| `active_job_id` | Id | opt | The only job allowed to change status. |
| `last_selected_update_event_id` | Id | opt | |
| `state_version` | int | req | CAS counter. |

#### ScheduledRecheck

`{recheck_id, method_run_id, answer_version_id, due_at: Ts, source_change_span_id, created_by_update_event_id, fired_by_update_event_id: Id|null}`. Fired by the next `CLOCK_TICK` or update whose `as_of >= due_at`; firing appends a new `ScheduledRecheck`-referencing `CandidateSelection` with reason `SCHEDULED_EFFECTIVE` (fired state is derived from that selection, keeping the table append-only).

#### ReviewAnnotation (gold store only)

| Field | Type | Req | Notes |
|---|---|---|---|
| `annotation_id` | Id | req | PK. |
| `item_id` | string | req | `<example_id>` plus claim or answer reference. |
| `item_level` | enum | req | `CLAIM`, `ANSWER`, `MATERIALITY`, `INITIAL_SUPPORT`. |
| `annotator_id` | string | req | Pseudonymous. |
| `round` | enum | req | `R1`, `R2`, `ADJUDICATION`. |
| `label` | enum | opt | Semantic status; null when `ambiguous`. |
| `is_material` | bool | opt | |
| `evidence_spans` | list | req | `[{document_version_id, start, end, stance}]`. |
| `ambiguous` | bool | req | |
| `ambiguity_reason` | enum | opt | `QUESTION_UNDERSPECIFIED`, `SCOPE_UNCLEAR`, `EVIDENCE_UNCLEAR`, `POLICY_UNCLEAR`, `OTHER`. |
| `confidence` | int | req | 1 to 3. |
| `saw_model_output` | bool | req | Must be `false` for test-split R1 and R2 (REQ-EVAL-006). |
| `rubric_version` | string | req | |
| `created_at` | Ts | req | |
| `notes` | string | opt | |

#### ExperimentConfig

Resolved from YAML (Section 13.8). Fields: `config_id`, `experiment`, `dataset {kind, path, manifest_hash, track_filter, split}`, `source_policy_path` + hash, `clock: logical`, `methods: [{method_id, selector, router, verifier_ref, mode: SELECT_VERIFY|INVALIDATE_ONLY, evidence_mode}]`, `verifiers {name: {type, model_id, prompt_version, params, is_mock}}`, `transition_model {checkpoint_hash}|null`, `budget {strong_calls_per_update, strong_tokens_per_update}`, `evidence {...}`, `selection {...}`, `audit {enabled, n_per_update, fraction}`, `seeds: [int]`, `replay_mode`, `report {...}`. `config_id` = `xcfg_` hash of the resolved object with all file references replaced by their content hashes.

#### ExperimentRun

One execution of one experiment configuration: `{experiment_id, config_id, code_git_sha, code_dirty: bool, started_at, finished_at, status: RUNNING|SUCCEEDED|FAILED|PARTIAL, environment {python, platform, lockfile_hash, cuda, gpu_name, cpu_model}, dataset_manifest_hash, method_run_ids: [Id], output_dir, contains_mock_results: bool}`. Wall-clock fields and `environment` are operational metadata and are excluded from the determinism digest (13.8).

#### MethodRun

One method with one seed inside an experiment: `{method_run_id, experiment_id, method_id, seed, mode: SELECT_VERIFY|INVALIDATE_ONLY, evidence_mode: CANONICAL|SELECTOR_INFORMED, verifier_profile_hash, status, store_path, corpus_snapshot_ids: [first, last], contains_mock_results: bool}`. Every operational record carries its `method_run_id` (REQ-REPRO-004).

#### CostRecord

| Field | Type | Req | Notes |
|---|---|---|---|
| `cost_record_id` | Id | req | PK. |
| `method_run_id` | Id | req | |
| `stage` | enum | req | `INGEST`, `SEGMENT`, `CLAIM_EXTRACTION`, `SUPPORT_INIT`, `INDEX_BUILD`, `INDEX_UPDATE`, `UPDATE_DETECT`, `CANDIDATE_RETRIEVAL`, `EVIDENCE_RETRIEVAL`, `TRANSITION_INFERENCE`, `ROUTING`, `VERIFICATION`, `RETRY`, `AUDIT`, `REPAIR`, `COMMIT`, `REPORT`, `TRAINING`. |
| `component` | string | req | |
| `update_event_id`, `answer_version_id`, `request_id` | Id | opt | |
| `phase` | enum | req | `COLD_START` (one-time preprocessing), `INCREMENTAL` (per update), `OFFLINE` (training, excluded from per-update totals but reported). |
| `model_calls`, `cached_calls`, `retries` | int | req | |
| `input_tokens`, `output_tokens` | int | req | 0 when not applicable. |
| `wall_ms`, `cpu_ms` | int | req | Measured. |
| `gpu_ms` | int | opt | |
| `bytes_written` | int | req | |
| `money_estimate` | float | opt | Computed only at report time from a price table. |
| `price_table_version` | string | opt | |

### 6.6 Worked example: one complete update event and its verdict

The fixture stream (Section 14.1) applies delivery `fx-0003`, which changes the Starter price in `doc_plans` from 12 to 15 USD (revision `r2` to `r3`, snapshot `snap:000002` to `snap:000003`). The method shown is B3b (passage-version selection with the shared strong verifier) running as one method run of experiment `m1_tiny_saas` with `CANONICAL` evidence. Records are listed in creation order, starting with the `MethodRun`.

Everything in this example was generated by a script implementing `canon-v1`, `seg-v1`, `cjson-v1` and the ID grammar, so hashes, offsets and IDs are mutually consistent. Fields marked measured (`latency_ms`, token counts, `wall_ms`, `cpu_ms`, `bytes_written`, `confidence`) are **illustrative values**, not measurements, and `PLACEHOLDER_STRONG_MODEL` is a placeholder until a model is pinned (U-010). Records not shown (claims and citations of other answers, unchanged passages, the r2 DocumentVersion, the Document row, the `ExperimentRun`) follow the same schemas.

**Integrity records and illustrative records.** The example has two kinds of content, and they are tested differently (D-048):

- *Integrity records* are computed from the fixture by the specified deterministic rules and are an exact M1 acceptance target (T-TEXT-003): `UpdateEvent`, `CorpusSnapshot`, `DocumentVersion`, `PassageVersion`, `PassageLineageEdge`, `ChangeSpan`, `Question`, `AnswerVersion`, `Citation`, `Claim`, `SupportGroup`, `CandidateSelection`, `RoutingDecision`, and the ids, status, claim resolution and current-state linkage of `AnswerVerdict` and `AnswerCurrentState`.
- *Illustrative records* show shape, not expected output: the evidence bundle inside `VerificationRequest`, every field derived from it (`bundle_id`, `bundle_hash`, `char_count`, `required_coverage`, the NEUTRAL judgments and `raw_response_hash`), and all measured or model-produced values. Its retrieved items were produced by a sketch that follows 9.2 and 9.5 step 3 on the fixture (the claim shares "per" with the export guide's second passage and "plan" with the storage FAQ), but the sketch is not a reference implementation, so M1 never compares bundles to it. Evidence gathering is tested against its rules instead (T-EVID-009).

```json
{{EXAMPLE_JSON}}
```

Checks a reader can make: `ChangeSpan.old_start..old_end` (69..71) slices `"12"` from `dv:doc_plans@r2` text and `new_start..new_end` slices `"15"` from `dv:doc_plans@r3` text; the verifier citation is located at its `start..end` in the r3 text; every required coverage handle (E1, E2, E3) received a judgment, and the non-applicable E4 is not required; `AnswerCurrentState.verdict_id` equals `AnswerVerdict.verdict_id`; the `RoutingDecision`, `VerificationRequest` and `AnswerVerdict` all reference the same `job_id`, and every operational record carries the same `method_run_id`; availability is `WITHHELD` because the status is `CONTRADICTED`.

---
