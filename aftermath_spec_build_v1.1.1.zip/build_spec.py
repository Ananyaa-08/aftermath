"""Build AFTERMATH_IMPLEMENTATION_SPEC (.md and .docx) from part1..part6 and run every mandatory audit.

Exit status: 0 only if every audit passes. Any failed audit, failed assertion or export mismatch
exits non-zero. Results are written to audit_results.json.

Fault injection for negative tests (tests/test_build_audits.py): set AFTERMATH_BUILD_INJECT to one of
  ids, example, docx
to corrupt the worked example's references, its offsets, or the exported DOCX respectively.
Markdown-level faults are injected by editing the part files in a temporary copy.
"""
import json, os, re, subprocess, sys, zipfile, shutil, tempfile
import gen_example as ge

INJECT = os.environ.get("AFTERMATH_BUILD_INJECT", "")
OUT_MD, OUT_DOCX = "AFTERMATH_IMPLEMENTATION_SPEC.md", "AFTERMATH_IMPLEMENTATION_SPEC.docx"
res = {}

def fail_fast(msg):
    print("BUILD ERROR:", msg); json.dump(res, open("audit_results.json", "w"), indent=1); sys.exit(2)

# ---------------- worked example ----------------
example = ge.main()
if INJECT == "ids":
    example[-3]["verification_result_ids"].append("vres_doesnotexist000000")
if INJECT == "example":
    for r in example:
        if r["record_type"] == "ChangeSpan": r["new_start"] += 1
ex_json = json.dumps(example, indent=2, ensure_ascii=False)
fx = ['doc_plans (product_doc, title "Plans"), r1:\n' + ge.PLANS["r1"]]
for d, (st, title, txt) in ge.OTHER_DOCS.items():
    fx.append(f'{d} ({st}, title "{title}"), r1:\n' + txt)
doc = "\n".join(open(f"part{i}.md").read() for i in range(1, 7))
doc = doc.replace("{{EXAMPLE_JSON}}", ex_json).replace("{{FIXTURE_TEXTS}}", "\n".join(fx).rstrip("\n"))

# ---------------- table rows: escape pipes inside code spans, record shapes ----------------
def split_cells(row):
    body = row.strip()
    if not (body.startswith("|") and body.endswith("|")): return None
    body, cells, cur, i, in_code = body[1:-1], [], "", 0, False
    while i < len(body):
        c = body[i]
        if c == "\\" and i + 1 < len(body): cur += body[i:i+2]; i += 2; continue
        if c == "`": in_code = not in_code
        if c == "|" and not in_code: cells.append(cur); cur = ""
        else: cur += c
        i += 1
    cells.append(cur)
    return cells

SEP = re.compile(r"\|(\s*:?-+:?\s*\|)+")
out, fence, shapes, cur = [], False, [], None
for line in doc.split("\n"):
    if line.startswith("```"): fence = not fence
    if not fence and line.startswith("|"):
        cells = split_cells(line)
        if cells is None: cells = [line]
        cells = [re.sub(r"(?<!\\)\|", r"\\|", c) for c in cells]
        line = "|" + "|".join(cells) + "|"
        if cur is None: cur = []; shapes.append(cur)
        if not SEP.fullmatch(line.strip()): cur.append(len(cells))
    else:
        cur = None
    out.append(line)
doc = "\n".join(out)
bad_shapes = [i for i, t in enumerate(shapes) if len(set(t)) != 1]
res["PIPES"] = f"Pass ({len(shapes)} tables, every row matches its header)" if not bad_shapes else f"FAIL tables {bad_shapes}"

# ---------------- content audits ----------------
body = doc.split("## 21. Consistency audit")[0]
defined = set(re.findall(r"^#### ([A-Za-z]+)", doc, re.M)) | {"SupportGroupMember", "AnswerCurrentState", "ScheduledRecheck", "AssessmentJob"}
required = {"Document","DocumentVersion","CorpusSnapshot","PassageVersion","PassageLineageEdge","Question","AnswerVersion",
 "Claim","Citation","EvidenceLink","SupportGroup","UpdateEvent","ChangeSpan","CandidateSelection","VerificationRequest",
 "VerificationResult","RoutingDecision","ReviewAnnotation","ExperimentConfig","ExperimentRun","MethodRun","CostRecord",
 "AnswerVerdict","EvidenceBundle","ApplicabilityChange"}
missing = ({r["record_type"] for r in example} | required) - defined
res["SCHEMAS"] = f"Pass ({len(required)} required record types defined)" if not missing else f"FAIL missing {sorted(missing)}"
bad = sorted(set(re.findall(r"\b(UNSUPPORTED|NOT_SUPPORTED|CONFLICT_UNRESOLVED|UNRESOLVED_SOURCE_CONFLICT|REFUTED)\b", body)))
res["STATUSES"] = "Pass" if not bad else f"FAIL {bad}"
badwf = sorted(set(re.findall(r"\b(PENDING|REVIEWED|RUNNING_JOB)\b", body)))
res["WORKFLOW"] = "Pass" if not badwf else f"FAIL {badwf}"

idpat = re.compile(r'^(dv|pv|le|cs|upd|snap|av|clm|cit|sg|lin):|^(mrun|xexp|xcfg|csel|job|route|vreq|vres|verdict|cost|bun)_')
pks = {"MethodRun":"method_run_id","UpdateEvent":"update_event_id","CorpusSnapshot":"snapshot_id","DocumentVersion":"document_version_id",
       "PassageVersion":"passage_version_id","PassageLineageEdge":"lineage_edge_id","ChangeSpan":"change_span_id",
       "Question":"question_id","AnswerVersion":"answer_version_id","Citation":"citation_id","Claim":"claim_id",
       "SupportGroup":"support_group_id","CandidateSelection":"selection_id","RoutingDecision":"routing_decision_id",
       "VerificationRequest":"request_id","VerificationResult":"result_id","AnswerVerdict":"verdict_id","CostRecord":"cost_record_id"}
defined_ids, refs = set(), set()
for r in example:
    if r["record_type"] in pks: defined_ids.add(r[pks[r["record_type"]]])
    if "job_id" in r: defined_ids.add(r["job_id"])
    if r["record_type"] == "VerificationRequest": defined_ids.add(r["evidence_bundle"]["bundle_id"])
    stack = [r]
    while stack:
        o = stack.pop()
        if isinstance(o, dict): stack.extend(o.values())
        elif isinstance(o, list): stack.extend(o)
        elif isinstance(o, str) and idpat.match(o): refs.add(o)
external_ok = {"snap:000001","snap:000002","snap:000004","dv:doc_plans@r1","dv:doc_plans@r2","pv:doc_plans@r1#p0002",
               "lin:doc_plans:r1:p0002"} | {f"pv:{d}@r1#p{i:04d}" for d in ge.OTHER_DOCS for i in range(1, 4)}
undef = sorted(x for x in refs - defined_ids - external_ok if not x.startswith("xexp_"))
res["IDS"] = "Pass" if not undef else f"FAIL undefined {undef}"

# integrity of the worked example (computed records only; the bundle is illustrative, 6.6)
problems = []
by = {}
for r in example: by.setdefault(r["record_type"], r)
t3 = by["DocumentVersion"]["text"]; cs = by["ChangeSpan"]
if t3[cs["new_start"]:cs["new_end"]] != cs["new_text"]: problems.append("change span new offsets")
t2 = ge.canon(ge.PLANS["r2"])
if t2[cs["old_start"]:cs["old_end"]] != cs["old_text"]: problems.append("change span old offsets")
for j in by["VerificationResult"]["judgments"]:
    for c in j["citations"]:
        if t3[c["start"]:c["end"]] != c["quote"]: problems.append("citation offsets")
for pv in [r for r in example if r["record_type"] == "PassageVersion"]:
    text = t3 if pv["document_version_id"].endswith("@r3") else t2
    if ge.sha(text[pv["start"]:pv["end"]]) != pv["content_hash"]: problems.append(f"passage hash {pv['passage_version_id']}")
if by["AnswerCurrentState"]["verdict_id"] != by["AnswerVerdict"]["verdict_id"]: problems.append("state->verdict")
if not (by["RoutingDecision"]["job_id"] == by["VerificationRequest"]["job_id"] == by["AnswerVerdict"]["job_id"]): problems.append("job ids")
bundle = by["VerificationRequest"]["evidence_bundle"]
if set(bundle["required_coverage"][0]["handles"]) != {i["handle"] for i in bundle["items"] if i["applicable"]}: problems.append("coverage")
if len({r["method_run_id"] for r in example if "method_run_id" in r}) != 1: problems.append("method_run_id")
res["EXAMPLE"] = "Pass (offsets, hashes, linkage and coverage of computed records)" if not problems else f"FAIL {problems}"

idt = doc.split("Operational prefixes and identity tuples:")[1].split("Initial-check jobs")[0]
rows = [l for l in idt.splitlines() if l.startswith("| ") and "`" in l and not l.startswith("| Record")]
exempt = ("ExperimentConfig", "ExperimentRun", "MethodRun", "EvidenceBundle", "VerificationResult", "AnswerVerdict", "ReviewAnnotation")
lack = [l.split("|")[1].strip() for l in rows if l.split("|")[1].strip() not in exempt and "method_run_id" not in l]
res["MRUN"] = f"Pass ({len(rows)} identity rows checked)" if not lack else f"FAIL {lack}"

req_def = set(re.findall(r"^\| (REQ-[A-Z]+-\d{3}) \| [MSY] \|", doc, re.M))
trace = doc.split("### 17.2 Traceability table")[1].split("## 18.")[0]
req_tr = set(re.findall(r"^\| (REQ-[A-Z]+-\d{3}) \|", trace, re.M))
req_ref = set(re.findall(r"REQ-[A-Z]+-\d{3}", doc))
d = []
if req_def != req_tr: d.append(f"defined vs traced {sorted(req_def ^ req_tr)}")
if req_ref - req_def: d.append(f"undefined refs {sorted(req_ref - req_def)}")
res["REQS"] = f"Pass ({len(req_def)} requirements, all traced)" if not d else "FAIL " + "; ".join(d)

cat = doc.split("### 17.1 Test catalog")[1].split("### 17.2")[0]
cat_ids = set()
for m in re.finditer(r"^\| (T-[A-Z]+-\d{3})(?:\.\.(\d{3}))?(?:, (\d{3}))?", cat, re.M):
    base = m.group(1); pre, n = base.rsplit("-", 1); cat_ids.add(base)
    if m.group(2): cat_ids |= {f"{pre}-{i:03d}" for i in range(int(n), int(m.group(2)) + 1)}
    if m.group(3): cat_ids.add(f"{pre}-{m.group(3)}")
used = set()
for m in re.finditer(r"T-([A-Z]+)-(\d{3})(?:\.\.(\d{3}))?", doc):
    a, s, e = m.group(1), int(m.group(2)), m.group(3)
    used |= {f"T-{a}-{i:03d}" for i in range(s, (int(e) if e else s) + 1)}
miss_t = sorted(used - cat_ids)
res["TESTS"] = f"Pass ({len(cat_ids)} catalogued tests)" if not miss_t else f"FAIL uncatalogued {miss_t}"

d_def = set(re.findall(r"^\| (D-\d{3}) \|", doc, re.M)); u_def = set(re.findall(r"^\| (U-\d{3}) \|", doc, re.M))
as_def = set(re.findall(r"^\| (AS-\d{2}) \|", doc, re.M))
probs = sorted((set(re.findall(r"\bD-\d{3}\b", doc)) - d_def) | (set(re.findall(r"\bU-\d{3}\b", doc)) - u_def)
               | (set(re.findall(r"\bAS-\d{2}\b", doc)) - as_def))
res["DU"] = f"Pass ({len(d_def)} decisions, {len(u_def)} uncertainties, {len(as_def)} scenarios)" if not probs else f"FAIL undefined {probs}"

nj, bad_json = 0, []
for blk in re.findall(r"```json\n(.*?)```", doc, re.S):
    nj += 1
    try: json.loads(blk)
    except Exception as ex: bad_json.append(str(ex)[:60])
res["JSON"] = f"Pass ({nj} blocks)" if not bad_json else f"FAIL {bad_json}"
lang = [m.group(0) for m in re.finditer(r"(?i)\b(we achieved|has achieved|was achieved|guarantees? (that|detection|reliability)|we show that)\b", body)
        if not re.search(r"(?i)\b(not|no|never|without)\b[^.]{0,30}$", body[max(0, m.start() - 40):m.start()])]
res["LANG"] = "Pass (no matches)" if not lang else f"FAIL {lang}"
prose = doc.split("```")[0::2]
dash = [l[:60] for blk in prose for l in blk.splitlines()
        if "—" in l or "–" in l or re.search(r"(?<![-<!\w|])--(?![->\w|])", l)]
res["STYLE"] = "Pass (no em, en or double dashes in prose)" if not dash else f"FAIL {dash[:3]}"

# ---------------- pandoc helpers ----------------
def pandoc_json(args, inp=None):
    p = subprocess.run(["pandoc", *args, "-t", "json"], input=inp, capture_output=True, text=True)
    if p.returncode: fail_fast(p.stderr[:300])
    return json.loads(p.stdout)

def text_of(x):
    """Exact text of an AST fragment: characters verbatim, code spans marked with backticks, raw HTML
    marked, spaces and soft breaks as one space; bold and italic markers ignored."""
    if isinstance(x, list): return "".join(text_of(i) for i in x)
    if isinstance(x, dict):
        t, c = x.get("t"), x.get("c")
        if t == "Str": return c
        if t in ("Space", "SoftBreak", "LineBreak"): return " "
        if t == "Code": return "`" + c[1] + "`"
        if t in ("RawInline", "RawBlock"): return "<<RAW:" + c[1] + ">>"
        if t in ("Link", "Image"): return text_of(c[1])
        if t == "Quoted": return '"' + text_of(c[1]) + '"'
        if t in ("Span", "Div"): return text_of(c[1])
        # Bold and italic are formatting, not text: the DOCX writer may re-nest them around code spans.
        return text_of(c) if c is not None else ""
    return ""

def walk_blocks(ast, kind):
    found, stack = [], [ast["blocks"]]
    while stack:
        o = stack.pop(0)
        if isinstance(o, dict):
            if o.get("t") == kind: found.append(o)
            else: stack[0:0] = [o.get("c")] if o.get("c") is not None else []
        elif isinstance(o, list):
            stack[0:0] = o
    return found

def tables(ast):
    out = []
    for t in walk_blocks(ast, "Table"):
        c = t["c"]; rows = [[text_of(cell[4]).strip() for cell in hr[1]] for hr in c[3][1]]
        for tb in c[4]: rows += [[text_of(cell[4]).strip() for cell in r[1]] for r in tb[3]]
        out.append(rows)
    return out

def raw_nodes(ast):
    found, stack = [], [ast]
    while stack:
        o = stack.pop()
        if isinstance(o, dict):
            if o.get("t") in ("RawInline", "RawBlock"): found.append(o["c"][1])
            stack.extend(o.values())
        elif isinstance(o, list): stack.extend(o)
    return found

# ---------------- export and validation ----------------
def raw_cells(md):
    tabs, cur, fence = [], None, False
    for line in md.split("\n"):
        if line.startswith("```"): fence = not fence
        if not fence and line.startswith("|"):
            if cur is None: cur = []; tabs.append(cur)
            if not SEP.fullmatch(line.strip()): cur.append(split_cells(line))
        else:
            cur = None
    return tabs

def validate(md):
    open(OUT_MD, "w").write(md)
    p = subprocess.run(["pandoc", OUT_MD, "-f", "gfm", "-o", OUT_DOCX, "--toc", "--toc-depth=2", "--reference-doc=ref.docx"],
                       capture_output=True, text=True)
    if p.returncode: fail_fast(p.stderr[:300])
    if INJECT == "docx":
        tmp = OUT_DOCX + ".tmp"
        with zipfile.ZipFile(OUT_DOCX) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                data = zin.read(item.filename)
                if item.filename == "word/document.xml":
                    data = data.decode().replace("protective_withholding_recall", "protective_withholding_recal", 1).encode()
                zout.writestr(item, data)
        shutil.move(tmp, OUT_DOCX)
    src = pandoc_json([OUT_MD, "-f", "gfm"])
    dst = pandoc_json([OUT_DOCX, "-f", "docx"])
    errs = []
    # (1) source cells: each raw Markdown cell, parsed on its own, must equal the table parser's cell exactly.
    ts, raw = tables(src), raw_cells(md)
    if len(ts) != len(raw): errs.append(f"table count md {len(raw)} vs parsed {len(ts)}")
    marker = "ZZCELLBOUNDARYZZ"
    flat = [c.replace("\\|", "|").strip() for t in raw for r in t for c in r]
    solo = pandoc_json(["-f", "gfm"], inp=f"\n\n{marker}\n\n".join(x if x else "EMPTYCELL" for x in flat))
    solo_texts, buf = [], []
    for b in solo["blocks"]:
        tx = text_of(b).strip()
        if tx == marker: solo_texts.append(" ".join(buf)); buf = []
        else: buf.append(tx)
    solo_texts.append(" ".join(buf))
    solo_texts = ["" if s == "EMPTYCELL" else s for s in solo_texts]
    parsed_flat = [c for t in ts for r in t for c in r]
    if len(solo_texts) != len(parsed_flat): errs.append(f"cell count raw {len(solo_texts)} vs parsed {len(parsed_flat)}")
    else:
        errs += [f"md cell parsed differently: {a[:40]!r} vs {b[:40]!r}" for a, b in zip(solo_texts, parsed_flat) if a != b][:5]
    # (2) no raw HTML anywhere: pandoc would drop it from the DOCX.
    rawh = raw_nodes(src)
    res["RAWHTML"] = "Pass (no raw HTML in the source)" if not rawh else f"FAIL {rawh[:5]}"
    # (3) DOCX tables: identical shape and identical cell text, in order.
    td = tables(dst)
    if len(ts) != len(td): errs.append(f"table count {len(ts)} vs docx {len(td)}")
    ncell = 0
    for k, (a, b) in enumerate(zip(ts, td)):
        if [len(r) for r in a] != [len(r) for r in b]: errs.append(f"table {k} shape differs"); continue
        for ra, rb in zip(a, b):
            for ca, cb in zip(ra, rb):
                ncell += 1
                if ca != cb: errs.append(f"table {k}: {ca[:40]!r} vs docx {cb[:40]!r}")
    # (4) code blocks: same number, same order, byte-identical text (whitespace and punctuation preserved).
    cs, cd = [b["c"][1] for b in walk_blocks(src, "CodeBlock")], [b["c"][1] for b in walk_blocks(dst, "CodeBlock")]
    if len(cs) != len(cd): errs.append(f"code blocks {len(cs)} vs docx {len(cd)}")
    errs += [f"code block {i} differs: {a[:40]!r}" for i, (a, b) in enumerate(zip(cs, cd)) if a != b][:5]
    return errs, len(ts), ncell, len(cs)

for k, v in res.items(): doc = doc.replace("{{AUDIT_" + k + "}}", v)
errs, nt, nc, nk = validate(doc.replace("{{AUDIT_DOCX}}", "PENDING").replace("{{AUDIT_RAWHTML}}", "PENDING"))
res["DOCX"] = (f"Pass (text content: {nt} tables, {nc} cells and {nk} code blocks identical after round trip; "
               f"visual layout is checked by rendering, not by this audit)") if not errs else f"FAIL {errs[:5]}"
doc = doc.replace("{{AUDIT_DOCX}}", res["DOCX"]).replace("{{AUDIT_RAWHTML}}", res["RAWHTML"])
errs2, *_ = validate(doc)
if errs2 != errs: res["DOCX"] = f"FAIL unstable validation {errs2[:3]}"
left = re.findall(r"\{\{[A-Z_]+\}\}", doc)
res["PLACEHOLDERS"] = "Pass" if not left else f"FAIL {left}"

json.dump(res, open("audit_results.json", "w"), indent=1)
failed = {k: v for k, v in res.items() if not v.startswith("Pass")}
print(json.dumps(res, indent=1))
print("words:", len(doc.split()))
if failed:
    print("BUILD FAILED:", ", ".join(sorted(failed))); sys.exit(1)
print("BUILD OK")
