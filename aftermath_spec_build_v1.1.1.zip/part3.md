## 7. Architecture, module boundaries and component contracts

### 7.1 Shape

One Python package (`aftermath`) run as a single process per experiment, plus a command-line runner. No services until Stage C, and then only a thin FastAPI app over the same package and a Next.js client. Retrieval indexes are in-process. SQLite is the only database.

### 7.2 Architecture diagram

The diagram groups modules, not services.

```mermaid
flowchart TD
  subgraph Inputs
    DL[Delivery files / dataset adapters]
    AR[Answer archive files]
  end
  subgraph Store["SQLite serving store (append-only + pointers)"]
    CS[(Corpus: documents, versions, passages, snapshots)]
    AS[(Archive: questions, answers, claims, citations, links, support groups)]
    WF[(Workflow: updates, selections, jobs, routing, requests, results, verdicts, current state)]
    CO[(Cost records)]
  end
  GOLD[(Gold store: annotations)]

  DL --> ING[corpus.ingest]
  ING --> CS
  ING --> DIFF[diff.align]
  DIFF --> CS
  AR --> AIN[archive.ingest + citation resolver]
  AIN --> AS
  AS --> IDX[retrieval: lexical + dense indexes]
  CS --> IDX
  DIFF --> SEL[selection: B1..B4, provenance, discovery, union, audit]
  AS --> SEL
  IDX --> SEL
  SEL --> EVG[evidence.gather + policy]
  IDX --> EVG
  EVG --> TM[transition model, Stage B]
  TM --> RT[routing]
  SEL --> RT
  RT --> VER[verify: adapters]
  VER --> COMMIT[pipeline.commit]
  RT --> COMMIT
  COMMIT --> WF
  WF --> EV[eval: metrics + report]
  GOLD --> EV
  CO --> EV
  WF -.read only.-> API[api: FastAPI, Stage C]
  API -.-> UI[web: Next.js, Stage C]
```

### 7.3 Repository layout (proposed)

```
aftermath/
  pyproject.toml                  # package metadata, tool config (ruff, mypy, pytest, import-linter)
  uv.lock                         # generated in M1 (D-025); not hand-written
  README.md
  AGENTS.md                       # short pointer to this spec and milestone status
  docs/AFTERMATH_IMPLEMENTATION_SPEC.md
  schemas/                        # exported JSON Schema, one file per record type
  configs/
    policies/sp-tiny-1.yaml
    experiments/m1_tiny_saas.yaml
    verifiers/                    # verifier profiles; model ids pinned here after U-010
    pricing/README.md             # price tables are user-supplied, dated, versioned
  fixtures/tiny_saas/
    deliveries/fx-0001.json ... fx-0004.json
    archive/questions.jsonl  archive/answers.jsonl  archive/claims.jsonl  archive/citations.jsonl
    scenarios/AS-01.yaml ... AS-20.yaml
    scripts/verifier_script.yaml  # ScriptedVerifier responses (mock)
    gold/labels.jsonl             # read only by aftermath.eval
  src/aftermath/
    core/        ids.py hashing.py cjson.py timeutil.py enums.py errors.py schemas/ config.py
    textproc/    canon.py segment.py sentences.py normalize.py offsets.py tokenize.py
    store/       db.py migrations/ repos/ triggers.sql blobs.py
    corpus/      ingest.py snapshots.py policy.py
    archive/     ingest.py citations.py claims.py support_init.py
    diff/        align.py features.py
    retrieval/   bm25.py dense.py hybrid.py rerank.py
    selection/   base.py exhaustive.py doc_invalidation.py passage_invalidation.py similarity.py
                 provenance.py discovery.py union.py audit.py temporal.py
    evidence/    gather.py bundle.py groups.py resolve.py temporal.py
    verify/      base.py scripted.py nli.py llm.py providers/ prompts/ parse.py replay.py
    transition/  model.py features.py serialize.py train.py calibrate.py
    routing/     policies.py budget.py
    pipeline/    process_update.py jobs.py commit.py scheduler.py report_update.py
    cost/        ledger.py pricing.py
    eval/        gold.py metrics.py bootstrap.py report.py curves.py
    datasets/    fixture.py vitaminc.py fruit.py hoh.py dynaquest.py garage.py construct.py splits.py
    annotation/  export.py import_.py agreement.py adjudicate.py
    experiments/ runner.py manifest.py cli.py
    api/         app.py routes/        # Stage C
  web/                                  # Stage C, Next.js
  tests/
    unit/  integration/  acceptance/  experiment/  conftest.py
  m0/                                   # M0 feasibility audit: sample, labels, report (not part of the package)
  runs/  cache/  data/                  # gitignored; runs/<experiment_id>/methods/<method_run_id>/ per method run
```

### 7.4 Dependency direction

Allowed imports (enforced by import-linter contracts in `pyproject.toml`, T-ARCH-001):

```
core <- textproc <- store <- corpus, archive, diff
corpus, archive, diff, retrieval <- selection, evidence
evidence <- verify (bundle types only), transition
selection, evidence, verify, transition, routing, cost <- pipeline
pipeline <- experiments, api
eval imports core, store (read-only views), cost; nothing imports eval except experiments
datasets imports core, textproc; annotation imports core, eval.gold
```

Hard rules:

- No module except `aftermath.eval` and `aftermath.annotation` may import `aftermath.eval.gold` or open the gold store (REQ-DATA-008, REQ-CAND-007).
- `verify` adapters never import `store`; they receive requests and bundles and return results.
- `core` imports nothing from the package.

### 7.5 Typed public interfaces

```python
# aftermath/core/types.py (planned, abbreviated)
from typing import Protocol, Sequence, Iterator
from dataclasses import dataclass

class SnapshotView(Protocol):
    snapshot_id: str
    seq: int
    as_of: str
    def documents(self) -> Iterator["DocumentVersion"]: ...            # latest observed versions (manifest)
    def latest_version(self, document_id: str) -> "DocumentVersion | None": ...
    def effective_version(self, document_id: str, t: str) -> "DocumentVersion | None": ...   # eff_k(d, t), 5.1
    def applicable_passages(self, scope: "Scope", t_eval: str) -> Iterator["PassageVersion"]: ...  # 5.7
    def passages(self, document_version_id: str) -> Sequence["PassageVersion"]: ...
    def passage(self, passage_version_id: str) -> "PassageVersion": ...
    def text(self, document_version_id: str) -> str: ...

class ArchiveView(Protocol):                 # read-only, never exposes gold
    def answers(self) -> Iterator["AnswerVersion"]: ...
    def claims(self, answer_version_id: str) -> Sequence["Claim"]: ...
    def citations(self, answer_version_id: str) -> Sequence["Citation"]: ...
    def links_by_lineage(self, lineage_id: str) -> Sequence["EvidenceLink"]: ...
    def citations_by_lineage(self, lineage_id: str) -> Sequence["Citation"]: ...
    def citations_by_document(self, document_id: str) -> Sequence["Citation"]: ...
    def support_groups(self, claim_id: str) -> Sequence["SupportGroup"]: ...

@dataclass(frozen=True)
class SelectionContext:
    method_run_id: str
    update_event: "UpdateEvent"
    change_spans: Sequence["ChangeSpan"]
    lineage_edges: Sequence["PassageLineageEdge"]
    base: SnapshotView
    target: SnapshotView
    archive: ArchiveView
    config: "SelectorConfig"

class Selector(Protocol):
    selector_id: str
    def select(self, ctx: SelectionContext) -> list["CandidateSelection"]: ...

class Retriever(Protocol):
    retriever_id: str
    def index(self, items: Sequence[tuple[str, str]]) -> None: ...      # (item_id, text)
    def add(self, items: Sequence[tuple[str, str]]) -> None: ...
    def search(self, query: str, k: int, allow: set[str] | None = None) -> list["Hit"]: ...

class Embedder(Protocol):
    model_id: str
    dim: int
    def embed(self, texts: Sequence[str]) -> "numpy.ndarray": ...      # L2-normalized float32

class EvidenceGatherer(Protocol):
    def gather(self, answer: "AnswerVersion", claims: Sequence["Claim"], update: "UpdateEvent",
               target: SnapshotView, scope: "Scope", t_eval: str, mode: "EvidenceMode",
               selection: "CandidateSelection | None") -> "EvidenceBundle": ...   # selection ignored in CANONICAL mode
    def partitions(self, bundle: "EvidenceBundle", limits: "CallLimits") -> list["EvidenceBundle"]: ...  # 9.5 step 9

class Verifier(Protocol):
    verifier_id: str
    tier: "VerifierTier"           # MOCK | CHEAP | STRONG
    is_mock: bool
    def verify(self, request: "VerificationRequest", bundle: "EvidenceBundle",
               claims: Sequence["Claim"], question: "Question") -> "VerificationResult": ...
    def estimate_cost(self, bundle: "EvidenceBundle", claims: Sequence["Claim"]) -> "CostEstimate": ...

class ChatProvider(Protocol):
    provider_id: str
    def complete(self, messages: list[dict], response_schema: dict, *, model_id: str,
                 temperature: float, max_output_tokens: int, timeout_s: float) -> "ProviderResponse": ...

class TransitionModel(Protocol):
    model_id: str
    def predict(self, items: Sequence["TransitionInput"]) -> Sequence["TransitionPrediction"]: ...

class Router(Protocol):
    policy_id: str
    def route(self, candidates: Sequence["CandidateSelection"],
              predictions: dict[str, "TransitionPrediction"] | None,
              estimates: dict[str, "CostEstimate"], budget: "Budget",
              rng_seed: int) -> list["RoutingDecision"]: ...

def resolve_claim_status(judgments: Sequence["Judgment"], bundle: "EvidenceBundle",
                         policy: "SourcePolicy") -> "ClaimResolution": ...   # evidence/resolve.py

class CostLedger:
    def measure(self, stage: str, component: str, **refs) -> "Measurement": ...  # context manager
```

### 7.6 Configuration loading

- YAML files validated into Pydantic config models (`aftermath.core.config`). Unknown keys raise `ConfigError`.
- Resolution order: built-in defaults < experiment YAML < CLI `--set key=value` overrides (planned). Environment variables are used **only** for secrets (`AFTERMATH_<PROVIDER>_API_KEY`) and never appear in resolved configs, logs or reports (REQ-SEC-001).
- The resolved config (with file references replaced by content hashes) is written to `runs/<experiment_id>/methods/<method_run_id>/manifest.resolved.json` and hashed into `config_id`.

### 7.7 Model and provider boundaries

- All model calls go through `Verifier`, `TransitionModel`, `Embedder` or the claim decomposer, each of which records `model_id`, `prompt_version` (where applicable) and `config_hash` on its outputs (REQ-DATA-009).
- Hosted LLMs are reached only through `ChatProvider` implementations in `verify/providers/` (planned: one module per provider, each an optional extra dependency). No provider SDK is imported outside that directory.
- Every provider call passes through `verify/replay.py`, which in `RECORD` mode stores the raw response keyed by request hash, in `REPLAY` mode serves only from cache and raises `ReplayMissError` on a miss, and in `LIVE` mode calls without recording (REQ-VER-004).
- Hosted model outputs are treated as non-deterministic even at temperature 0. Determinism claims apply only to `REPLAY` mode.

### 7.8 Error types

```
AftermathError
  ConfigError
  TimeZoneError
  InvalidEncodingError
  IngestError
    IdempotencyConflictError      # same id, different content or declared effective time
    OutOfOrderDeliveryError       # parked, not fatal
    UnknownDocumentError
    NoMaterialClaimsError
  StoreError
    AppendOnlyViolationError
    StaleHeadError                # CAS on corpus_head failed
    StaleStateError               # CAS on answer_current_state failed
    IllegalTransitionError
    IntegrityError
  AlignmentError
  RetrievalError
  VerifierError
    VerifierTimeoutError
    ProviderError
    MalformedOutputError
    IncompleteCoverageError       # required judgments missing (9.8)
    RefusalError
    ReplayMissError
  BudgetExhausted                 # control-flow signal, caught by the router
  LeakageError                    # gold access from method code, or split leakage detected
  MockResultReportingError        # attempt to emit empirical tables from a run with mock verifiers
```

### 7.9 Test locations

| Kind | Location | Runs in CI | Network | Notes |
|---|---|---|---|---|
| Unit | `tests/unit/<package>/test_*.py` | yes | no | Pure functions, schemas, offsets (property tests with Hypothesis), ID grammar. |
| Integration | `tests/integration/` | yes | no | SQLite store, triggers, pipeline over fixture with ScriptedVerifier. |
| Acceptance (software) | `tests/acceptance/test_as_<NN>_*.py` | yes | no | Section 14 scenarios with ScriptedVerifier; deterministic. |
| Acceptance (model quality) | `tests/experiment/probes/` | no (manual, `-m probe`) | yes or replay | Same scenarios with real verifiers; results logged, never pass/fail gates. |
| Experiment | `tests/experiment/` | smoke only | no | Runner end to end on fixture; determinism check. |

### 7.10 Component contracts

Each component below lists purpose, inputs and outputs, data ownership, algorithm, failure behavior, cost instrumentation, and acceptance checks. Algorithms that are long are given in Section 8 or 9 and referenced here.

#### C1 Corpus ingestor (`corpus.ingest`)
- **Purpose**: turn a delivery into immutable document versions, passages and a new snapshot.
- **In/Out**: delivery payload; `UpdateEvent`, `DocumentVersion`s, `PassageVersion`s, `CorpusSnapshot`, `snapshot_changes`.
- **Owns**: `documents`, `document_versions`, `passage_versions`, `snapshots`, `snapshot_changes`, `update_events`, `corpus_head`.
- **Algorithm**: Section 8.1 to 8.2.
- **Failure**: validation precedes mutation (8.1); redelivery follows the redelivery table in 8.1; a delivery containing any out-of-order document is parked whole with no version written (Stage A); any exception during apply rolls back the whole transaction and records `FAILED_APPLY`; head is unchanged in every outcome other than `APPLIED`.
- **Cost**: `INGEST`, `SEGMENT` records per delivery (`phase = COLD_START` for `INITIAL_LOAD`, else `INCREMENTAL`).
- **Checks**: T-ING-001..009, T-DATA-003, T-DATA-004.

#### C2 Segmenter (`textproc.segment`, `seg-v1`)
- **Purpose**: deterministic paragraph passages with offsets and section paths.
- **In/Out**: canonical text; list of `(start, end, section_path)`.
- **Owns**: nothing (pure).
- **Algorithm**: split on `\n`; a line matching `^(#{1,6})\s+(.*)$` is a heading that sets `section_path` at its level and is not a passage; blank lines end a paragraph; consecutive non-blank, non-heading lines form one paragraph whose span runs from the first line's start to the last line's end. A paragraph longer than 1200 code points is split at sentence boundaries (`sentences-v1`: split after `.`, `!` or `?` followed by whitespace and an uppercase letter, digit, or opening quote or bracket) into greedy chunks of at most 1200 code points; a single sentence longer than 1200 is kept whole.
- **Failure**: none expected; empty documents yield zero passages.
- **Cost**: included in `SEGMENT`.
- **Checks**: T-TEXT-001 (offsets reproduce text), T-TEXT-002 (property test: concatenated passages cover all non-blank, non-heading characters), T-TEXT-003 (fixture offsets match Section 6.6).

#### C3 Aligner and change detector (`diff.align`, `diff-v1`)
- **Purpose**: classify every passage of the prior and new version and produce change spans and lineage edges.
- **In/Out**: prior and new document version with passages; `PassageLineageEdge`s, `ChangeSpan`s.
- **Owns**: `passage_lineage_edges`, `change_spans`, `applicability_changes`.
- **Algorithm**: Section 8.3.
- **Failure**: `AlignmentError` (internal inconsistency) aborts the whole delivery apply (rolled back), never a partial snapshot.
- **Cost**: `UPDATE_DETECT`.
- **Checks**: T-UPD-001..008, T-SEM-017, AS-01, AS-02, AS-20, AS-24.

#### C4 Archive ingestor and citation resolver (`archive.ingest`, `archive.citations`)
- **Purpose**: load questions, answers, claims and recorded citations; resolve citations to passages without treating them as support.
- **In/Out**: archive files; `Question`, `AnswerVersion`, `Claim`, `Citation`.
- **Owns**: `questions`, `answer_versions`, `claims`, `citations`.
- **Algorithm**: for each citation, look up the document in `generated_against_snapshot_id`; if a quote is given, search for an exact match in canonical text, then via `norm-v1` mapping; set `resolution` accordingly; if no quote, `DOCUMENT_ONLY`; if the document is unknown, `UNRESOLVED`. Claims come from the archive file if present, else `sentence-v1` (Stage A) or `decompose-v1` (Stage B).
- **Failure**: `NoMaterialClaimsError` for grounded answers without material claims (answer stored with `ingest_error`, excluded); unresolved citations are kept with `UNRESOLVED`.
- **Cost**: `INGEST`, `CLAIM_EXTRACTION` (`COLD_START`).
- **Checks**: T-ING-004, T-ING-005, T-SEM-011.

#### C5 Support initializer (`archive.support_init`)
- **Purpose**: record what supports each claim at answer time.
- **In/Out**: claims, citations, answer-time snapshot; `SupportGroup`s, `EvidenceLink`s.
- **Owns**: `support_groups`, `support_group_members`, `evidence_links`.
- **Algorithm**: Stage A: one `CITATION_ASSUMED` singleton group per resolved passage citation (`verified = false`); for a sentence-level citation, the group members are the cited passage. Stage B: Section 9.6.
- **Failure**: verifier failures leave the claim with only `CITATION_ASSUMED` groups and set a flag `support_init_incomplete`.
- **Cost**: `SUPPORT_INIT` (`COLD_START`), including all verifier calls.
- **Checks**: T-EVID-003, T-EVID-006.

#### C6 Retrieval indexes (`retrieval`)
- **Purpose**: (a) claim index for discovery and similarity selection; (b) passage index for evidence gathering.
- **In/Out**: `(id, text)` pairs; ranked `Hit(id, score)` lists.
- **Owns**: in-memory indexes, persisted as `runs/<experiment_id>/methods/<method_run_id>/indexes/*` with a content hash of their inputs.
- **Algorithm**: Section 9.2 (BM25) and 9.3 (dense).
- **Failure**: index build failure aborts the run; query failure on one item raises `RetrievalError`, caught per candidate and recorded.
- **Cost**: `INDEX_BUILD` (`COLD_START`), `INDEX_UPDATE` and query time inside `CANDIDATE_RETRIEVAL` or `EVIDENCE_RETRIEVAL`.
- **Checks**: T-RET-001 (deterministic ranking and tie-breaks), T-RET-002 (incremental add equals rebuild).

#### C7 Selectors (`selection`)
- **Purpose**: produce candidates and reasons per method.
- **In/Out**: `SelectionContext`; `CandidateSelection`s.
- **Owns**: `candidate_selections`; creates `assessment_jobs` through the pipeline.
- **Algorithm**: Section 9.1, 9.4, 11.
- **Failure**: a selector exception fails the update's selection step for that method; the run records the error and continues with other methods (each method is a separate run).
- **Cost**: `CANDIDATE_RETRIEVAL`.
- **Checks**: T-CAND-001..007, AS-04, AS-07, AS-12.

#### C8 Evidence gatherer and policy resolver (`evidence`)
- **Purpose**: build bounded evidence bundles; map verifier judgments to statuses under the source policy.
- **In/Out**: answer, claims, update, target snapshot, scope; `EvidenceBundle`; judgments to `ClaimResolution`.
- **Owns**: nothing persisted directly (bundles are persisted inside `VerificationRequest`).
- **Algorithm**: Section 9.5 and 5.8.
- **Failure**: retrieval errors set `incompleteness = RETRIEVAL_DEGRADED` with a reason; must-keep evidence is never dropped silently (9.5 steps 8 to 10); `DISCOVERED_EVIDENCE_DROPPED` blocks cheap acceptance and any verdict.
- **Cost**: `EVIDENCE_RETRIEVAL`.
- **Checks**: T-EVID-001..008, T-SEM-009, T-SEM-015, T-BASE-012, AS-06, AS-08, AS-10, AS-22.

#### C9 Verifier adapters (`verify`)
- **Purpose**: judge claims against evidence through one interface.
- **In/Out**: `VerificationRequest`, bundle, claims, question; `VerificationResult`.
- **Owns**: response cache, raw responses in blob store.
- **Algorithm**: Section 9.8 (prompt and parsing). Adapters: `ScriptedVerifier` (mock), `NliVerifier` (cheap, cross-encoder), `LlmVerifier` (strong, via `ChatProvider`).
- **Failure**: maps provider exceptions to `TIMEOUT`, `PROVIDER_ERROR`, `REFUSED`; schema failures to `MALFORMED_OUTPUT`; missing required judgments to `INCOMPLETE_COVERAGE` (9.8). Never raises past the pipeline's retry wrapper.
- **Cost**: `VERIFICATION` or `RETRY` or `AUDIT` per call, with tokens, calls, latency.
- **Checks**: T-VER-001..008, AS-17, AS-21.

#### C10 Transition model (`transition`, Stage B)
- **Purpose**: cheap calibrated prediction of post-update claim status.
- **In/Out**: `TransitionInput`s; `TransitionPrediction(claim_id, probs[4], p_changed, input_incomplete)`.
- **Owns**: checkpoints under `runs/<train_run_id>/checkpoints/` with hashes.
- **Algorithm**: Section 12.
- **Failure**: inference failure on an item yields no prediction; router treats it as maximal uncertainty.
- **Cost**: `TRANSITION_INFERENCE` (`INCREMENTAL`), `TRAINING` (`OFFLINE`).
- **Checks**: T-TRAIN-001..006.

#### C11 Router (`routing`)
- **Purpose**: decide per candidate: escalate, accept cheap verdict, or withhold, within budget.
- **In/Out**: candidates, predictions, cost estimates, budget; `RoutingDecision`s.
- **Owns**: `routing_decisions`.
- **Algorithm**: Section 8.10.
- **Failure**: none expected; missing predictions are maximal uncertainty.
- **Cost**: `ROUTING`.
- **Checks**: T-ROUTE-001..004, AS-16.

#### C12 Pipeline and committer (`pipeline`)
- **Purpose**: orchestrate Sections 8.1 to 8.12 for one delivery; commit verdicts safely.
- **In/Out**: delivery; all workflow records; per-update report.
- **Owns**: `assessment_jobs`, `job_state_log`, `answer_verdicts`, `answer_current_state`, `scheduled_rechecks`.
- **Algorithm**: Section 8.
- **Failure**: per-answer isolation (REQ-PIPE-003); bounded retries; CAS failures leave stale verdicts as history only.
- **Cost**: `COMMIT`, `REPORT`; wraps all other stages.
- **Checks**: T-PIPE-001..008, AS-13 to AS-17.

#### C13 Cost ledger (`cost`)
- **Purpose**: one place to measure and record cost.
- **In/Out**: measurements; `CostRecord`s; money estimates at report time.
- **Owns**: `cost_records`; price tables are inputs.
- **Algorithm**: context manager records `time.perf_counter_ns` and `time.process_time_ns` deltas, CUDA event timing when a GPU is in use, token counts reported by adapters, bytes written by repositories.
- **Failure**: a ledger write failure is fatal for the run (cost data must not silently disappear).
- **Cost**: n/a.
- **Checks**: T-COST-001..004.

#### C14 Evaluator and reporter (`eval`)
- **Purpose**: compute metrics against gold, bootstrap CIs, write reports.
- **In/Out**: serving store (read-only), gold store, cost records; `metrics.json`, `report.md`, curves.
- **Owns**: run output files.
- **Algorithm**: Section 13.
- **Failure**: refuses to emit empirical tables when `contains_mock_results` is true (`MockResultReportingError`), and instead writes a software-test report with a banner (REQ-VER-005).
- **Cost**: `REPORT`.
- **Checks**: T-EVAL-001..008.

#### C15 Experiment runner (`experiments`)
- **Purpose**: load a config, create one method run per (method, seed), each with its own fresh serving store, replay the dataset stream into each, build or reuse canonical bundles, then call the evaluator and write cross-method comparisons only when the method runs are comparable (11.3).
- **In/Out**: experiment YAML; run directory.
- **Owns**: `runs/<experiment_id>/methods/<method_run_id>/`.
- **Algorithm**: Section 13.8.
- **Failure**: a failed method run is recorded `FAILED` with traceback; other runs continue.
- **Cost**: aggregates.
- **Checks**: T-REPRO-001..003, T-PIPE-007.

#### C16 API and UI (Stage C)
- **Purpose**: inspection and repair approval. Section 15, M11.
- **Checks**: T-API-001..003.

---

## 8. Update-processing algorithm

### 8.0 Top-level loop

Updates for a corpus are applied strictly sequentially by one writer (REQ-PIPE-001). Verification jobs may lag behind and may run concurrently in a worker pool inside the same process (default pool size 4 for hosted verifiers, 1 for local models).

```python
def process_delivery(delivery, run):                      # pipeline/process_update.py
    ev = ingest_and_apply(delivery)                       # 8.1 to 8.4, one transaction
    if ev.status != "APPLIED":
        return report_update(ev, run)                     # duplicate, no-op, parked, rejected
    fire_due_rechecks(ev, run)                            # 8.7 scheduled rechecks with as_of >= due_at
    cands = select_candidates(ev, run)                    # 8.5 to 8.7, single writer
    jobs = enqueue_jobs(cands, ev, run)                   # sets active_job_id, state QUEUED (CAS)
    bundles = {j.id: gather_evidence(j, run) for j in jobs}            # 8.8
    preds = predict_transitions(jobs, bundles, run) if run.transition_model else None  # 8.9
    decisions = route(jobs, preds, bundles, run.budget_for(ev))        # 8.10
    for j, d in zip(jobs, decisions):
        if d.action == "ESCALATE_STRONG":
            submit(verify_and_commit, j, bundles[j.id], run.strong)    # worker pool
        elif d.action == "ACCEPT_CHEAP_VERDICT":
            commit_verdict(j, cheap_verdict(preds, j), assessor="TRANSITION_MODEL")
        elif d.action == "INVALIDATE_ONLY":
            mark(j, "WITHHELD", reason="INVALIDATE_ONLY")
        else:                                              # WITHHOLD_BUDGET, WITHHOLD_POLICY
            mark(j, "WITHHELD", reason=d.action)
    wait_for_jobs_or_deadline(jobs, run.update_deadline)   # experiments: wait for all
    run_audit_sample(ev, cands, run)                       # 9.7
    return report_update(ev, run)                          # 8.12
```

### 8.1 Ingest an immutable source version

Ingestion has two phases. Phase 1 validates the whole delivery and writes nothing. Phase 2 applies it in one transaction whose only exits are commit or rollback (REQ-ING-007). Outcomes other than `APPLIED` are recorded afterwards in their own small transaction.

```python
def ingest_and_apply(delivery):
    payload_hash = hash_payload(delivery)
    prior = repo.update_event_by_delivery(delivery.delivery_id)     # latest status from update_event_status_log
    if prior is not None:
        action = redelivery_rule(prior.status, prior.payload_hash == payload_hash)   # table below
        repo.log_delivery_attempt(delivery.delivery_id, payload_hash, action)
        if action == "DUPLICATE":
            return prior
        if action == "CONFLICT_REJECTED":
            raise IdempotencyConflictError(delivery.delivery_id)   # nothing written beyond the attempt log
        # action is RETRY_APPLY (prior FAILED_APPLY) or REEVALUATE (prior PARKED_OUT_OF_ORDER): fall through

    # Phase 1: validate everything; no writes
    head = repo.head(delivery.corpus_id)
    plan, conflicts, out_of_order = [], [], []
    for d in delivery.documents:
        text = canon_v1(read_bytes(d))                              # InvalidEncodingError: whole delivery REJECTED
        eff_from = resolve_effective_from(d)
        known = repo.version_by_revision(d.document_id, d.source_revision_id)
        if known is not None:
            if known.content_hash != sha(text) or known.declared_effective_from != d.effective_from:
                conflicts.append(d)                                 # versions are immutable
            continue                                                # already ingested with identical content
        latest = head.latest_version(d.document_id)
        if latest is not None and d.source_seq <= latest.source_seq:
            out_of_order.append(d)
            continue
        plan.append(PlannedVersion(d, text, eff_from, prior=latest))
    if conflicts:
        return record_outcome(delivery, payload_hash, "REJECTED", conflicts)
    if out_of_order and not config.backfill_enabled:              # Stage A
        return record_outcome(delivery, payload_hash, "PARKED_OUT_OF_ORDER", out_of_order)
    if not plan and not out_of_order:
        return record_outcome(delivery, payload_hash, "NO_OP_UNCHANGED")

    # Phase 2: apply atomically; no early return inside the transaction
    try:
        with db.transaction(immediate=True):                       # BEGIN IMMEDIATE; COMMIT on exit, ROLLBACK on exception
            ev = repo.insert_or_get_update_event(delivery, payload_hash)
            for pv in plan:                                         # in-order documents become latest
                dv = repo.insert_document_version(pv)               # also when text equals the prior version's text
                repo.insert_passages(dv, segment_seg_v1(pv.text))
                align_and_record(ev, pv.prior, dv)                  # 8.2 to 8.3, including AUTHORITY_CHANGED
            for d in out_of_order:                                  # Stage B only (8.4.3)
                backfill_historical_version(ev, d)
            record_timeline_changes(ev, documents_touched(plan, out_of_order))   # 8.3a
            snap = repo.insert_snapshot(parent=head, versions=plan, event=ev)
            repo.cas_head(delivery.corpus_id, expected=head.seq, new=snap.seq)   # StaleHeadError: rollback
            repo.log_status(ev, "APPLIED")
        return ev
    except Exception as exc:
        record_outcome(delivery, payload_hash, "FAILED_APPLY", error=exc)   # after rollback, own transaction
        raise
```

`record_outcome` inserts the `UpdateEvent` row if it does not exist and appends one row to `update_event_status_log`. It never writes document versions.

**Redelivery table** (a delivery whose `delivery_id` has been seen; "status" is the latest logged status; REQ-ING-008):

| Latest status of the earlier delivery | Same payload hash | Different payload hash |
|---|---|---|
| `APPLIED` | `DUPLICATE`: attempt logged, nothing else changes | `CONFLICT_REJECTED`: `IdempotencyConflictError`, head unchanged |
| `NO_OP_UNCHANGED` | `DUPLICATE` | `CONFLICT_REJECTED` |
| `REJECTED` | `DUPLICATE` (stays rejected; a corrected payload needs a new `delivery_id`) | `CONFLICT_REJECTED` |
| `FAILED_APPLY` | `RETRY_APPLY`: phases 1 and 2 run again | `CONFLICT_REJECTED` |
| `PARKED_OUT_OF_ORDER` | `REEVALUATE`: phase 1 runs again against the current head and mode; Stage A parks again, Stage B applies with backfill | `CONFLICT_REJECTED` |

**Three cases kept apart** (REQ-ING-009):

- *Duplicate delivery*: same `delivery_id` and payload. Handled by the table; no new versions.
- *New revision with unchanged text*: a new `source_revision_id` whose canonical text equals the latest version's. A new `DocumentVersion` is written (fixed-version questions and provenance need the revision identity), passages get `IDENTICAL` lineage edges, a new snapshot is created, and the text diff produces no semantic change span. If the new revision also changes what is in force at some time, the effective-timeline diff (8.3a) emits spans and selection proceeds from them (AS-24); otherwise B3 and the method select nothing. B2 selects by definition (9.1). AS-23.
- *Metadata change*: a new revision whose `metadata.source_type` differs from the prior version's produces one document-level `AUTHORITY_CHANGED` span; selectors treat it as affecting every passage of the document. A new revision can change what is in force over some interval whether or not its text differs from the latest observed version; that is detected by the effective-timeline diff (8.3a), not by the text diff.

### 8.2 Choose the prior version to compare against

The comparison base is the **latest observed version of the same document in the head snapshot** (`prior` in 8.1), never simply the previous revision number seen. What is *in force* is decided later, at evidence time, by `eff_k` (5.7); change spans carry the new version's `effective_from`. For a deletion, the new side is a tombstone (`is_deletion = true`, empty text) and every passage of `prior` becomes `DELETED` with one `DOCUMENT_DELETED` span. For a new document, every passage is `ADDED` with one `DOCUMENT_ADDED` span. For a re-added document (deleted earlier), the base is the last non-deletion version, and spans are computed against it.

### 8.3 Align passages and detect changes (`diff-v1`)

Inputs: old passages `O` and new passages `N` (ordered). All thresholds are defaults in `configs` (D-006).

```python
def align(O, N):
    edges, used_o, used_n = [], set(), set()
    # 1. exact content: identical text
    by_hash = index(O, key=lambda p: p.content_hash)
    for n in N:
        o = pop_first_unused(by_hash.get(n.content_hash), used_o, prefer_same_ordinal=n.ordinal)
        if o: edges.append(edge("IDENTICAL" if same_position(o, n) else "MOVED", [o], [n], 1.0))
    # 2. normalized content: whitespace, case or NFKC-only differences
    for n in unused(N): match by norm_hash -> edge("REFORMATTED", [o], [n], 1.0)
    # 3. modified: similarity on remaining pairs
    pairs = [(sim(o, n), o, n) for o in unused(O) for n in unused(N)]
    #    sim = dice-v1: multiset Dice coefficient over tok-v1 tokens (order-insensitive):
    #          2 * |tokens(o) ∩ tokens(n)| / (|tokens(o)| + |tokens(n)|), multiset intersection
    for s, o, n in sorted(pairs, key=lambda x: (-x[0], x[1].ordinal, x[2].ordinal)):
        if o in used_o or n in used_n or s < TAU_MOD:     # TAU_MOD = 0.50
            continue
        runner_up = second_best(o, n, pairs)
        conf = "LOW" if s < TAU_HIGH or s - runner_up < MARGIN else "HIGH"   # TAU_HIGH = 0.70, MARGIN = 0.05
        edges.append(edge("MODIFIED", [o], [n], s, conf))
    # 4. merges and splits among consecutive leftovers
    for n in unused(N): try covering n by 2 or 3 consecutive unused O with containment >= 0.80 -> "MERGED"
    for o in unused(O): try covering o by 2 or 3 consecutive unused N with containment >= 0.80 -> "SPLIT"
    # 5. leftovers
    for o in unused(O): edges.append(edge("DELETED", [o], [], None))
    for n in unused(N): edges.append(edge("ADDED", [], [n], None))
    return edges
```

`dice-v1` is order-insensitive so that reordered or lightly paraphrased sentences still align (on the fixture, the AS-01 paraphrase scores 0.7143, the AS-03 price change 0.9375). `containment(A, B)` = number of `norm-v1` tokens of `B` appearing in the multiset of `A` divided by token count of `B`. `same_position` = same ordinal and same `section_path`.

**Change spans.** For each `MODIFIED` edge, run a token-level `difflib.SequenceMatcher` over `\S+` tokens of the two passages and emit one `ChangeSpan` per non-equal opcode, with document-version offsets spanning the affected tokens (`replace` gives both sides, `delete` an old side only, `insert` a new side only). `SPLIT` and `MERGED` edges emit one span covering the whole old and new passages. `ADDED`, `DELETED`, `MOVED`, `REFORMATTED` emit one span each.

**Features** (`diff/features.py`), computed per span on the old and new slices plus the containing sentence:

- `numeric_change`: the multiset of number tokens (`\d+(?:[.,]\d+)*%?`) differs; `numbers_old`, `numbers_new` list them.
- `date_change`: ISO dates, month names with a day or year, or years `19xx`/`20xx` differ.
- `negation_change`: the count of negators (`not`, `no`, `never`, `none`, `cannot`, `n't`, `no longer`) differs.
- `qualifier_change`: the set of qualifiers (`only`, `all`, `every`, `except`, `until`, `starting`, `effective`, `before`, `after`, `at least`, `at most`, `up to`) differs.

Features never decide a verdict; they feed selection priority and the transition model.

**Uncertain alignment** (REQ-UPD-003). If any edge in a section has `alignment_confidence = LOW`, or the section has an unmatched passage on both sides, every passage of that section in both versions receives an additional `EXPANDED_UNCERTAIN` change span. If more than 50% of the document's passages are unmatched or low-confidence, the expansion covers the whole document. Expansion never removes the original spans; it only adds more for selectors to consider.

### 8.3a Effective-timeline changes (`timeline-v1`)

The text diff of 8.3 compares latest observed versions. It cannot see a delivery that changes which version is in force without changing the latest text (5.7, AS-24). Inside the apply transaction, after the new versions are inserted, the pipeline also compares effective timelines (REQ-UPD-007):

```python
def record_timeline_changes(ev, documents):
    for d in documents:
        before = timeline(d, knowledge=K_k)         # [(start, end, version_id)] covering all time, from eff_k
        after = timeline(d, knowledge=K_k1)         # the same, including this delivery's versions
        for start, end, old_v, new_v in changed_intervals(before, after):
            # changed = the in-force content hash differs (versions with identical text count as equal)
            ac = repo.insert_applicability_change(ev, d, start, end, old_v, new_v)
            if (old_v, new_v) == latest_observed_pair(ev, d):
                attach(ac, text_diff_spans(ev, d))  # reuse; no duplicate spans (text_diff_reused = true)
            else:
                edges = align(passages(old_v), passages(new_v))        # same diff-v1 as 8.3
                emit_change_spans(ev, edges, applicability_change=ac,
                                  effective_from=start, effective_to=end)
```

Rules:

- `timeline(d, K)` splits the time axis at every `effective_from` known for `d` and labels each interval with `eff_K(d, t)`. A tombstone or the absence of a version is labelled `None`.
- Adjacent intervals with the same in-force content hash are merged before comparison, so a revision that repeats the text in force produces no change.
- Spans produced here carry old passages from `old_v`, so provenance lookups by lineage work exactly as for text-diff spans. Lineage ids are not changed; lineage edges remain those of the text diff.
- Selectors treat timeline spans like any other semantic span. Assessment still uses `eff_k` at `t_eval`, so a change whose interval does not contain `t_eval` normally leaves current answers unchanged and creates scheduled rechecks (8.7).
- Pending scheduled rechecks are never cancelled. If a later delivery cancels the scheduled change (5.7), the recheck still fires and assesses under whatever is in force at its due time.

### 8.4 Additions, removals, replacements, moves, and edge cases

#### 8.4.1 Summary of classes

| Class | Edge relation | Change span kind | Treated as semantic change by B3 |
|---|---|---|---|
| Addition | `ADDED` | `ADDED` / `DOCUMENT_ADDED` | yes |
| Removal | `DELETED` | `DELETED` / `DOCUMENT_DELETED` | yes |
| Replacement | `MODIFIED` | `MODIFIED` | yes |
| Move | `MOVED` | `MOVED` | no (default `treat_moves_as_changes = false`) |
| Formatting | `REFORMATTED` | `REFORMATTED` | no |
| Split | `SPLIT` | `SPLIT` | yes |
| Merge | `MERGED` | `MERGED` | yes |
| Uncertain | any with `LOW` | plus `EXPANDED_UNCERTAIN` | yes |

#### 8.4.2 Deleted documents

A deletion delivery creates a tombstone `DocumentVersion` and a `snapshot_changes` row with `document_version_id = NULL`. Prior versions stay in history and remain applicable to `FIXED_TIME` questions whose time falls in their effective interval, and to `FIXED_VERSION` questions. Once the tombstone is the effective version, the document contributes no evidence to `ROLLING_CURRENT` or later `FIXED_TIME` evaluation.

#### 8.4.3 Out-of-order updates

Ordering key: `source_seq` per document (Wikipedia revision id order, commit order, fixture integer). A document whose revision is unknown and whose `source_seq` is at most that document's latest observed `source_seq` is out of order. Out-of-order handling is decided per **delivery**, in phase 1, before anything is written:

- **Stage A** (default): the whole delivery is recorded `PARKED_OUT_OF_ORDER`. No document version from it is written, including in-order documents in the same delivery (REQ-ING-003, REQ-ING-007). The update report lists the parked delivery; redelivery follows the redelivery table.
- **Stage B** (`backfill-v1`): the whole delivery is applied in one transaction. In-order documents become latest versions as usual. Out-of-order documents are inserted as known but not latest versions; they never become `latest_k`. Because applicability uses `eff_k`, a backfilled version becomes evidence exactly at the times it is in force. Candidates: `FIXED_TIME` answers whose `scope.time` falls where `eff` changed, and `ROLLING_CURRENT` answers when `eff(d, as_of)` changed (reason `SCHEDULED_EFFECTIVE`, `via = "backfill"`).

#### 8.4.4 Splits and merges

Lineage: outputs of `SPLIT` and `MERGED` get new `lineage_id`s; the edge preserves the from/to lists. Provenance lookups follow edges from any member: an answer linked to an old passage that was split is linked to all outputs for evidence gathering.

### 8.5 Candidates through dependency lookup (provenance path)

```python
def provenance_candidates(ctx):
    out = {}
    affected_lineages = {lineage(o) for e in ctx.lineage_edges if e.relation not in IGNORED
                         for o in e.from_passage_version_ids}          # IGNORED = {IDENTICAL, REFORMATTED, MOVED}
    affected_lineages |= {lineage(s.old_passage_version_id) for s in ctx.change_spans
                          if s.kind == "EXPANDED_UNCERTAIN" and s.old_passage_version_id}
    for lin in affected_lineages:
        for cit in ctx.archive.citations_by_lineage(lin):
            add(out, cit.answer_version_id, Reason("PROVENANCE_CITATION", span_for(lin), cit.citation_id, 1.0))
        for link in ctx.archive.links_by_lineage(lin):                  # Stage B; includes low-confidence links
            add(out, answer_of(link.claim_id), Reason("PROVENANCE_INFERRED", span_for(lin), link.evidence_link_id,
                                                      link.confidence or 0.5))
    for doc in deleted_or_document_only_targets(ctx):                    # DOCUMENT_ONLY citations
        for cit in ctx.archive.citations_by_document(doc):
            if cit.resolution in ("DOCUMENT_ONLY", "UNRESOLVED"):
                add(out, cit.answer_version_id, Reason("PROVENANCE_CITATION", None, cit.citation_id, 0.5))
    return out
```

Citations resolved `DOCUMENT_ONLY` cannot be mapped to a lineage, so any non-trivial change to that document selects them (conservative).

### 8.6 Discovery through claim search (Stage B)

```python
def discovery_candidates(ctx, claim_index):
    out = {}
    for span in ctx.change_spans:
        if span.kind in ("MOVED", "REFORMATTED"):
            continue
        queries = build_queries(span, ctx)        # new sentence(s) around the span; old sentence(s) for deletions;
                                                  # entity strings and numbers from features
        for q in queries:
            for hit in claim_index.search(q.text, k=K_DISC, allow=active_claims(ctx)):   # K_DISC = 50
                if hit.score < TAU_DISC: break                                         # TAU_DISC tuned on validation
                a = answer_of(hit.id)
                add(out, a, Reason("DISCOVERY", span.change_span_id, hit.id, hit.score))
    return out
```

Queries use the **new** text for additions and replacements (to find claims the new content may contradict or newly support) and the **old** text for deletions and replacements (to find claims that relied on removed content without a recorded link).

### 8.7 Merge candidates and preserve reasons

```python
def select_candidates(ev, run):
    ctx = build_context(ev, run)
    parts = [sel.select(ctx) for sel in run.method.selectors]          # e.g. provenance + discovery
    merged = {}
    for cands in parts:
        for c in cands:
            merged.setdefault(c.answer_version_id, []).extend(c.reasons)   # keep every reason
    merged |= scheduled_recheck_candidates(ev, run)                      # reason SCHEDULED_EFFECTIVE
    rows = []
    for a, reasons in merged.items():
        if scope_of(a).type == "FIXED_VERSION":
            rows.append(selection(a, reasons, temporal_exclusion="TEMPORALLY_EXCLUDED")); continue
        rows.append(selection(a, dedupe(reasons)))
    rank(rows, key=lambda r: (-max_provenance_score(r), -max_score(r), r.answer_version_id))
    if run.selection.max_candidates: truncate_and_record_overflow(rows)   # default None
    return rows
```

`dedupe` removes reasons with identical `(path, change_span_id, via)`. Ranking puts provenance reasons first, then by score, then by `answer_version_id` ascending (deterministic tie-break, REQ-CAND-002). Overflow beyond `max_candidates` is recorded in the update report as "not selected due to candidate limit", never silently dropped.

**Scheduled rechecks and future-effective content.** When a change span's `effective_from > ev.as_of`, selection still runs. Each *selected* `ROLLING_CURRENT` candidate is assessed now under `eff_k(d, as_of)`, where the previous version is still in force, so the current-time verdict is explicit; it also receives a `ScheduledRecheck(due_at = effective_from)`. Selected `FIXED_TIME` candidates are assessed under `eff_k(d, scope.time)`. Only discovered candidates are scheduled, because the system does not know every answer that future content will affect; misses are measured by the future-effective miss metric (13.2).

### 8.8 Gather applicable current and historical evidence

See Section 9.5. Evidence is read **only** from the job's `target_snapshot_id` and history up to it, never from head (REQ-EVID-001). This makes bundles immutable even if head moves during verification.

### 8.9 Predict support transitions (Stage B)

For each candidate claim, build a `TransitionInput` (Section 12.1) from the bundle and call `TransitionModel.predict` in batches of 32. Output per claim: calibrated probabilities over the four statuses and `p_changed = 1 - p(prior status)`. Answer-level: `p_answer_supported = product over material claims of p_c(SUPPORTED)` (independence approximation, U-013); `uncertainty = 1 - max over answer-level outcomes`, where the answer-level distribution is computed by applying the aggregation rule to the product of claim distributions (exact enumeration when at most 6 material claims, Monte Carlo with 1000 seeded samples otherwise).

### 8.10 Route within a configured budget

Budget unit: strong-verifier `model_calls` and optionally `input_tokens` per update event (`budget.strong_calls_per_update`, `budget.strong_tokens_per_update`); `null` = unbounded.

```python
def route(jobs, preds, bundles, budget, policy, seed):
    est = {j.id: strong.estimate_cost(bundles[j.id], claims(j)) for j in jobs}
    if policy.id == "verify_all_selected-v1":                      # Stage A
        order = sorted(jobs, key=lambda j: (j.rank, j.answer_version_id))
        return spend(order, est, budget, on_exhausted="WITHHOLD_BUDGET")
    if policy.id == "invalidate_only-v1":                          # B2a, B3a
        return [decision(j, "INVALIDATE_ONLY") for j in jobs]
    decisions, escalate = [], []
    for j in jobs:
        p = preds.get(j.id)
        forced = (p is None or has_fallback_claims(j) or p.input_incomplete
                  or bundles[j.id].incompleteness != "NONE")          # REQ-ROUTE-005, REQ-EVID-007
        if not forced and p.p_answer_supported >= policy.tau_keep and not p.flags_applicable_contradiction:
            decisions.append(decision(j, "ACCEPT_CHEAP_VERDICT", prediction=p))
        else:
            escalate.append(j)
    score = {                                                      # priority, higher first
        "risk_uncertainty_cost-v1": lambda j: (W_RISK * risk(j) + W_UNC * unc(j)) / max(est[j.id].input_tokens, 1),
        "risk_only-v1":             lambda j: risk(j),
        "uncertainty_only-v1":      lambda j: unc(j),
        "uniform-v1":               lambda j: seeded_uniform(seed, j.id),
    }[policy.id]
    order = sorted(escalate, key=lambda j: (-score(j), j.answer_version_id))
    return decisions + spend(order, est, budget, on_exhausted="WITHHOLD_BUDGET")
```

`risk(j) = 1 - p_answer_supported` (1.0 when no prediction); `unc(j)` as in 8.9 (1.0 when no prediction). Defaults: `W_RISK = 1.0`, `W_UNC = 0.5`, `tau_keep` fit on the calibration split (Section 12.6). Cost estimates count every partition of a bundle (9.5 step 9). `spend` escalates in order while the estimated cost fits the remaining budget and marks the rest `WITHHOLD_BUDGET`, recording `budget_before` and `budget_after`; a withheld job keeps its prediction as `provisional_prediction`, which is never committed as a status (REQ-ROUTE-001). Actual cost above the estimate is allowed for the job already started and recorded as overrun in the report.

### 8.11 Commit verdicts and audit records

```python
def verify_and_commit(job, bundle, verifier):
    if bundle.incompleteness == "DISCOVERED_EVIDENCE_DROPPED":      # partition cap exceeded (9.5 step 10)
        return mark(job, "WITHHELD", reason="EVIDENCE_OVERFLOW")
    judgments = []
    for part in gatherer.partitions(bundle, verifier.limits):      # usually one partition
        res = call_with_retries(job, part, verifier)
        if res.status != "OK":
            return mark(job, "FAILED", reason=res.status)
        judgments += res.judgments
    if missing_required_coverage(bundle, judgments):               # union over partitions (9.8)
        return mark(job, "FAILED", reason="INCOMPLETE_COVERAGE")
    resolutions = {c.id: resolve_claim_status(for_claim(judgments, c), bundle, policy) for c in claims(job)}
    verdict = aggregate(job, resolutions)                          # 5.6
    commit_verdict(job, verdict, assessor=verifier.assessor_tier)

def call_with_retries(job, part, verifier):
    missing = []
    for attempt in range(1, MAX_ATTEMPTS + 1):                    # MAX_ATTEMPTS = 3
        req = build_request(job, part, verifier, attempt, remind=missing)   # prompt names missing entries
        repo.insert(req)
        res = verifier.verify(req, part, claims(job), question(job))      # adapter never raises
        repo.insert(res); ledger.record(res, stage="VERIFICATION" if attempt == 1 else "RETRY")
        if res.status in ("OK", "REFUSED"):
            return res
        missing = res.missing_coverage                            # empty unless INCOMPLETE_COVERAGE
        backoff(attempt)          # TIMEOUT, PROVIDER_ERROR, MALFORMED_OUTPUT, INCOMPLETE_COVERAGE: 1 s, then 4 s
    return res

def commit_verdict(job, verdict, assessor):
    with db.transaction(immediate=True):
        if not repo.verdict_exists(job.id):                       # idempotent: UQ(job_id)
            repo.insert_verdict(verdict)                          # always kept as history for job.target_snapshot
        st = repo.current_state(job.method_run_id, job.answer_version_id)
        if st.active_job_id != job.id:                            # a newer update re-selected this answer
            repo.log_job_state(job, "SUPERSEDED"); return
        head = repo.head_seq()
        repo.cas_state(st, expected_version=st.state_version, new=State(
            workflow_state="COMPLETED", semantic_status=verdict.semantic_status,
            verdict_id=verdict.verdict_id, status_snapshot_id=job.target_snapshot_id,
            as_of_snapshot_id=snapshot_id(head),
            verification_basis="VERIFIED_AT_SNAPSHOT" if head == seq(job.target_snapshot_id) else "CARRIED_FORWARD",
            availability=derive_availability(...), active_job_id=None))
        repo.log_job_state(job, "COMPLETED")
```

This is the corpus-version check (REQ-PIPE-002): a verdict is always recorded against the snapshot it evaluated; it becomes the current status only if no later update has re-selected the answer. If later updates did not select it, the status is current but its basis is `CARRIED_FORWARD` for the later snapshots.

`mark(job, "FAILED" | "WITHHELD")` follows the same CAS rule, sets `semantic_status = null`, and keeps the previous verdict only as history.

### 8.12 Produce a report

Per update event, `report_update` writes `runs/<experiment_id>/methods/<method_run_id>/updates/<update_event_id>.json` and appends to the run's `events.jsonl`: event status; snapshot ids; counts of change spans by kind; candidates by reason path; temporally excluded answers; overflow; routing actions; verdict counts by status and assessor tier; withheld and failed counts with reasons; carried-forward count; audit sample results; scheduled rechecks created and fired; cost by stage; and a list of answers whose availability changed. The run-level report (Section 13.8) aggregates these.

**Initial checks.** Before the first update, the runner may run an initial assessment of the archive at the answer-time snapshot (`update_event_id = "upd:INITIAL"`, all answers selected, `phase = COLD_START`). Stage A fixtures skip it and set initial state from fixture declarations (`verification_basis = NONE`, `semantic_status = SUPPORTED`, `assessor_tier = RULE`, marked `FIXTURE_DECLARED`), which is allowed only for the `FIXTURE` track.

### 8.13 Required behaviors (summary)

| Situation | Behavior | Test |
|---|---|---|
| Redelivery of a known `delivery_id` | Redelivery table of 8.1; attempts logged in `delivery_attempts`; no new snapshot, jobs or verdicts unless `RETRY_APPLY` or `REEVALUATE` applies it | AS-14 |
| Duplicate delivery id, different payload | `REJECTED`, `IdempotencyConflictError`; head unchanged | AS-14 |
| Same document revision id, different content | `IdempotencyConflictError` | T-ING-001 |
| Retried job | New `VerificationRequest` with `attempt + 1`; verdict unique per `job_id`; replay cache keyed by request hash minus attempt | T-PIPE-002 |
| Out-of-order delivery, including a delivery that mixes in-order and out-of-order documents | Whole delivery parked in phase 1 with nothing written (Stage A); applied with backfill in one transaction (Stage B) | AS-19 |
| New revision with unchanged text | New version and snapshot, `IDENTICAL` edges, no text-diff spans; timeline spans only if what is in force changes | AS-23 |
| Effective-date-only change (what is in force changes, latest text does not) | `ApplicabilityChange` and timeline change spans (8.3a); selection proceeds from them | AS-24 |
| Partial failure | Per-answer isolation; other jobs commit; update report lists failures; apply failures roll back fully | T-PIPE-003 |
| Second update during verification | Newer selection takes `active_job_id`; older job's verdict stored as history, state not changed; if not re-selected, older verdict commits with basis per 8.11; tested with enumerated interleavings (T-PIPE-008) | AS-15 |
| Deleted document | Tombstone, `DOCUMENT_DELETED`, history retained | AS-18 |
| Passage splits and merges | `SPLIT`/`MERGED` edges, new lineages, provenance follows all members | AS-20 |
| Uncertain alignment | Section or document expansion via `EXPANDED_UNCERTAIN` spans | AS-20 |
| Empty candidate set | Event completes, zero jobs, all answers carried forward, audit sample still runs if enabled | AS-04 |
| Budget exhaustion | Remaining escalations `WITHHOLD_BUDGET`, `semantic_status = null`, `availability = WITHHELD` | AS-16 |
| Malformed model output | Retry up to 3 attempts; then `FAILED`, no status | AS-17 |
| Verifier omits a required judgment | `INCOMPLETE_COVERAGE`, retried with the missing entries named; then `FAILED`, no status | AS-21 |
| Must-keep evidence exceeds one call | Partitioned into up to `max_partitions` calls; beyond that `WITHHELD` (`EVIDENCE_OVERFLOW`), no status | AS-22 |
| Provider timeout | Per-call timeout (default 60 s), backoff, counts as attempt, cost recorded under `RETRY` | AS-17 |
| Identical evidence bundle as an earlier verified job | MAY reuse the earlier verdict for the same claim set, verifier, prompt and policy version (`reused_from_verdict_id`); cost recorded as a cache hit | AS-13 |

**Untrusted content.** Documents, passages, answers and retrieved text are data. They are passed to verifiers only inside delimited evidence blocks (Section 9.8), never concatenated into instructions, and nothing in them can change control flow: the pipeline acts only on parsed enum fields and located quotes from verifier output (REQ-SEC-002).

---
