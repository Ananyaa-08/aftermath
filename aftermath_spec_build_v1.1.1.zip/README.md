# AFTERMATH spec build (v1.1.1)

Requirements: Python 3.10+, pandoc 3.x on PATH.

    python3 build_spec.py                  # builds .md and .docx, runs every audit
    python3 tests/test_build_audits.py     # negative tests, about 3 minutes

`build_spec.py` exits 0 only if every audit passes; any FAIL, failed check or export mismatch exits
non-zero, and results are written to `audit_results.json`.

Audits: table shapes (pipes), schemas defined, status and workflow names, worked-example ids and
integrity (computed records only; the evidence bundle is illustrative, spec 6.6), method-run ids in
identity tuples, requirement traceability, test catalogue, decision/uncertainty/scenario ids, JSON
blocks, report language, prose dashes, raw HTML, DOCX text content, leftover placeholders.

DOCX text-content validation is exact: each raw Markdown cell parsed on its own must equal its table
cell; DOCX tables must match in shape and cell text; code blocks must be byte-identical and in order.
Bold and italic nesting is ignored (formatting, not text). Visual layout is NOT covered; check it by
rendering pages.

`tests/test_build_audits.py` injects one fault per audit category into a temporary copy and requires
a non-zero exit with that category reported as FAIL; a clean copy must exit 0.
